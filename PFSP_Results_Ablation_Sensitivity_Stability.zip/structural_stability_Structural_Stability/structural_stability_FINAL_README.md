# PFSP Applied Sciences Revision — structural-stability analysis FINAL

## Status
**MASTER QA: GREEN**

structural-stability analysis evaluates five-pool structural stability under the frozen manuscript protocol. It is descriptive robustness evidence and does not tune or change any parameter.

## Coverage and QA
- 140/140 benchmark problems.
- 700/700 problem × pool replications.
- 7000/7000 historical ablation analysis P+R regression cells: exact Cmax and final-permutation PASS.
- 2800/2800 structural pool-pair comparisons (140 problems × 2 mining modes × 10 pool pairs).
- 1400/1400 guided-output variability cells (140 problems × 2 mining modes × 5 families).
- 700/700 saved structural NPZ objects physically archived.
- Saved-object QA: seed, dimensions, finiteness, top-3n support size and signs all PASS.
- All 2800 structural metrics were independently recomputed from the 700 saved NPZ objects and matched the master table to numerical precision (maximum absolute discrepancy about 1.11e-16).

## Main descriptive findings
Across 1400 pool-pair comparisons per mining mode:

| Mining | Mean P Jaccard | Median P Jaccard | Mean P Pearson | Mean P Spearman | Mean R Pearson | Mean R Spearman | Mean R MAE | Mean preferred-region agreement |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Contrast | 0.920785 | 0.918466 | 0.998795 | 0.998568 | 0.998162 | 0.997049 | 0.003482 | 0.960193 |
| Elite-only | 0.887520 | 0.886792 | 0.997619 | 0.997240 | 0.996140 | 0.993902 | 0.002836 | 0.940589 |

For every overlapping retained P rule, directional agreement was 1.000 in both mining modes; therefore signed-rule Jaccard equals support Jaccard in this experiment. Contrast shows the higher retained-support overlap and higher full-score correlations/preferred-region agreement. The slightly larger R-score MAE for Contrast should be read together with its larger contrast-score scale; correlation and preferred-region agreement remain extremely high.

Guided P+R output variability across the five historical pools was also small relative to Cmax:

| Mining | Mean CV (%) | Median CV (%) | Mean relative range (%) | Median relative range (%) | Mean distinct Cmax | Mean distinct permutations | Zero-SD cells |
|---|---:|---:|---:|---:|---:|---:|---:|
| Contrast | 0.229830 | 0.194175 | 0.536182 | 0.442236 | 2.881429 | 3.357143 | 210/700 |
| Elite-only | 0.263376 | 0.206702 | 0.613540 | 0.491701 | 3.030000 | 3.497143 | 178/700 |

These results support the descriptive conclusion that the mined P/R information and the resulting guided outputs are stable across the five independently seeded random pools. They do **not** establish a statistical equivalence threshold or replace analysis phase 9 inferential analysis.

## Files
- `structural_stability_MASTER_QA.json`: final QA gate.
- `structural_stability_structural_pairwise_MASTER.csv`: all 2800 structural comparisons.
- `structural_stability_structural_stability_summary.csv`: overall and group summaries.
- `structural_stability_structural_stability_overall.csv`: compact overall summary.
- `structural_stability_guided_output_variability.csv`: 1400 problem × mining × family variability cells.
- `structural_stability_guided_output_variability_summary.csv`: overall/group/family summaries.
- `structural_stability_ablation_regression_audit_MASTER.csv`: 7000 exact ablation analysis regression checks.
- `structural_stability_replication_audit_MASTER.csv`: 700 replication-level historical regression checks.
- `structural_stability_structure_regeneration_audit_MASTER.csv`: structural regeneration audit.
- `structural_stability_structure_archive_object_QA.csv`: QA of the 700 saved structural objects.
- `structural_stability_structural_pairwise_RECOMPUTED_FROM_ARCHIVE.csv`: independent recomputation from saved objects.
- `PFSP_structural_stability_Structures_700.zip`: complete saved P/R structural object archive.
- `PFSP_structural_stability_FROZEN_PROTOCOL.md`: frozen protocol.
