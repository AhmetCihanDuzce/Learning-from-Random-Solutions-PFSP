# weight-sensitivity analysis — P/R Weight Sensitivity Final QA and Descriptive Summary

**QA status:** GREEN

- 28 pre-specified problems × 5 pools = 140 replications.
- 6 weight pairs × 2 mining modes × 5 families = 8400 raw results.
- Historical 0.65/0.35 regression: 1400/1400 exact PASS.
- Cross-check against ablation analysis for R-only, 0.65/0.35, and P-only: 4200 rows; Cmax mismatches=0; sequence mismatches=0.
- Invalid permutations=0; independent Cmax mismatches=0.

Positive Δ means the alternative weight has a lower Mean-of-Five Cmax than the 0.65/0.35 baseline within the same problem×mining×family cell.

| Weight (P/R) | Mean Δ vs 0.65/0.35 (%) | Median Δ (%) | W/T/L | Mean rank | Tied-best cells |
|---|---:|---:|---:|---:|---:|
| 0.00/1.00 | -0.0369 | +0.0000 | 97/63/120 | 3.652 | 95 |
| 0.25/0.75 | +0.0017 | +0.0000 | 73/130/77 | 3.395 | 108 |
| 0.50/0.50 | -0.0014 | +0.0000 | 59/161/60 | 3.350 | 98 |
| 0.65/0.35 | +0.0000 | +0.0000 | 0/280/0 | 3.375 | 100 |
| 0.75/0.25 | +0.0029 | +0.0000 | 56/178/46 | 3.334 | 96 |
| 1.00/0.00 | -0.1097 | -0.0464 | 99/30/151 | 3.895 | 97 |

## Scientific interpretation

The three interior mixed-weight alternatives (0.25/0.75, 0.50/0.50, and 0.75/0.25) are essentially indistinguishable from the fixed 0.65/0.35 main-study choice at the aggregate level. Their mean relative differences are all within ±0.003 percentage points, and exact ties are common. The 0.65/0.35 setting therefore should not be described as uniquely optimal; the evidence supports it as a representative fixed choice within a broad stable interior range.

Both pure-information endpoints are less stable. R-only is closer to the mixed-weight solutions, whereas P-only has the largest aggregate deterioration relative to 0.65/0.35. This is consistent with the ablation analysis ablation pattern in which the combined P+R arm had the best overall average gain, while neither single component dominated uniformly.

These results are descriptive robustness evidence from the pre-specified 28-problem sensitivity panel and should not be used to select a new tuned weight.