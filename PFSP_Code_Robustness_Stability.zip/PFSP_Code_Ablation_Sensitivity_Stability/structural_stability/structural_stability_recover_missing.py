import sys, importlib.util, pandas as pd
from pathlib import Path
spec=importlib.util.spec_from_file_location('m','/mnt/data/structural_stability_metrics_runner.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.PAIR=Path('/mnt/data/PFSP_structural_stability_Structural_Metrics/structural_stability_pair_recovery.csv')
m.REP=Path('/mnt/data/PFSP_structural_stability_Structural_Metrics/structural_stability_rep_recovery.csv')
done=set()
if m.PAIR.exists():
    try: done=set(pd.read_csv(m.PAIR,usecols=['ProblemID']).ProblemID.unique())
    except: pass
pids=[p for p in sys.argv[1:] if p not in done]
print('RECOVER',len(pids),pids,flush=True)
for i,pid in enumerate(pids,1):
    m.process(pid,None)
    print('PASS',i,len(pids),pid,flush=True)
