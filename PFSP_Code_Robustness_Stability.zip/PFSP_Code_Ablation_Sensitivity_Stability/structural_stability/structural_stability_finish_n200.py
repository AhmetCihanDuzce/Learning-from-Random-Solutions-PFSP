#!/usr/bin/env python3
from pathlib import Path
import sys,time,csv,gc,shutil,glob,os
import numpy as np, pandas as pd
from scipy.stats import rankdata
import concurrent.futures
ROOT=Path('/mnt/data/pfsp_code/PFSP_Code_Ablation_Sensitivity_OFAT/core'); sys.path.insert(0,str(ROOT))
import ablation_ablation_runner_HISTCOMPAT as s3
import run_pfsp_single as core
OUT=Path('/mnt/data/PFSP_structural_stability_N200_REMAINDER'); STRUCT=OUT/'structures'; OUT.mkdir(exist_ok=True);STRUCT.mkdir(exist_ok=True)
PAIR=OUT/'structural_stability_n200_pairwise.csv'; REP=OUT/'structural_stability_n200_structure_audit.csv'
S3POOL=pd.read_csv('/mnt/data/PFSP_ablation_Ablation_MASTER/ablation_pool_audit_MASTER.csv')
poolkey={(r.ProblemID,int(r.Replication)):r for r in S3POOL.itertuples(index=False)}
PARTIAL=Path('/mnt/data/PFSP_structural_stability_Structural_Stability_CONTINUATION/structures')

def append(path,rows):
    if not rows:return
    new=not path.exists()
    with path.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        if new:w.writeheader()
        w.writerows(rows)

def corr(a,b):
    a=np.asarray(a,float);b=np.asarray(b,float);sa=a.std();sb=b.std()
    return np.nan if sa==0 or sb==0 else float(np.corrcoef(a,b)[0,1])
def spear(a,b): return corr(rankdata(a,method='average'),rankdata(b,method='average'))

def numpy_group_stats_u8(seqs,n,regions=4):
    G=seqs.shape[0]
    # n=200 only: positions 0..199 are exactly representable as uint8.
    pos=np.empty((G,n),dtype=np.uint8)
    rows=np.arange(G,dtype=np.int64)[:,None]
    pos[rows,seqs.astype(np.intp,copy=False)]=np.arange(n,dtype=np.uint8)
    P=np.zeros((n,n),dtype=np.float64)
    for i in range(n-1):
        cnt=np.count_nonzero(pos[:,i,None] < pos[:,i+1:],axis=0)
        v=cnt/G; P[i,i+1:]=v; P[i+1:,i]=1.0-v
    R=np.zeros((n,regions),dtype=np.float64)
    # int16 prevents uint8 overflow in *regions
    for job in range(n):
        rg=(pos[:,job].astype(np.int16)*regions)//n
        R[job,:]=np.bincount(rg,minlength=regions)/G
    return P,R

def gen_pool_u8(seed,pool_size,n,batch_size=100000,workers=5):
    rng=np.random.default_rng(seed); pool=np.empty((pool_size,n),dtype=np.uint8)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        done=0
        while done<pool_size:
            b=min(batch_size,pool_size-done)
            keys=rng.random((b,n),dtype=np.float64)
            bounds=np.linspace(0,b,min(workers,b)+1,dtype=int)
            fut=[ex.submit(np.argsort,keys[bounds[k]:bounds[k+1]],1,'quicksort') for k in range(len(bounds)-1)]
            off=done
            for fu in fut:
                arr=fu.result().astype(np.uint8,copy=False); pool[off:off+len(arr)]=arr; off+=len(arr)
            done+=b
    return pool

def load_npz(path):
    z=np.load(path)
    return {'elite':(z['p_upper_elite'],z['r_elite'],z['top_support_elite'],z['top_sign_elite']),
            'contrast':(z['p_upper_contrast'],z['r_contrast'],z['top_support_contrast'],z['top_sign_contrast'])}

def one(pid,rep):
    target=STRUCT/f'{pid}__rep{rep}.npz'
    # Reuse a structural object already produced in this recovery run, or an
    # earlier exact-regression-validated structural-stability analysis object.
    src = target if target.exists() else (PARTIAL/target.name)
    if src.exists():
        if src != target: shutil.copy2(src,target)
        z=np.load(target)
        row=core.load_manifest_row(ROOT,pid); pr=poolkey[(pid,rep)]
        rr=dict(ProblemID=pid,Group=row['Group'],n=int(z['n']),m=int(z['m']),Replication=rep,Seed=int(z['Seed']),PoolSize=10000*int(z['n']),PoolStatsPass=True,TopPElite=len(z['top_support_elite']),TopPContrast=len(z['top_support_contrast']),FinitePass=True,ReusedValidatedObject=True,ElapsedSec=0.0)
        return load_npz(target),rr
    row=core.load_manifest_row(ROOT,pid);p,_=core.load_instance(ROOT,row);n,m=p.shape
    assert n==200
    seed=int(core.load_seed_rows(ROOT,pid)[rep-1]['Seed']);S=10000*n;en=round(.05*S);pn=round(.10*S);k=3*n
    t=time.perf_counter();pool=gen_pool_u8(seed,S,n,100000,5);cs=s3.cmax_memmap_parallel(pool,p,250000,5)
    ei,bi=core.selection_indices(cs,en,pn,s3.tie_mode_for(pid));elite=np.asarray(pool[ei],np.uint8);poor=np.asarray(pool[bi],np.uint8)
    ep,er=numpy_group_stats_u8(elite,n,4);bp,br=numpy_group_stats_u8(poor,n,4)
    E=ep-.5;C=ep-bp;RE=er-.25;RC=er-br;iu=np.triu_indices(n,1)
    ev=E[iu].copy();cv=C[iu].copy();PE=s3.historical_filter_precedence(E,k);PC=s3.historical_filter_precedence(C,k)
    es=np.flatnonzero(PE[iu]!=0).astype(np.int32);csup=np.flatnonzero(PC[iu]!=0).astype(np.int32)
    esg=np.sign(PE[iu][es]).astype(np.int8);csg=np.sign(PC[iu][csup]).astype(np.int8)
    pr=poolkey[(pid,rep)]
    ok=int(cs.min())==int(pr.PoolBest) and int(cs.max())==int(pr.PoolWorst) and abs(float(cs.mean())-float(pr.PoolMean))<1e-9 and abs(float(cs.std(ddof=1))-float(pr.PoolSD))<1e-9
    if not ok: raise RuntimeError(('pool mismatch',pid,rep))
    if len(es)!=k or len(csup)!=k: raise RuntimeError(('support',pid,rep,len(es),len(csup)))
    if not (np.isfinite(ev).all() and np.isfinite(cv).all() and np.isfinite(RE).all() and np.isfinite(RC).all()): raise RuntimeError(('finite',pid,rep))
    np.savez_compressed(target,ProblemID=np.array(pid),Group=np.array(row['Group']),n=np.int32(n),m=np.int32(m),Replication=np.int16(rep),Seed=np.int64(seed),p_upper_elite=ev,p_upper_contrast=cv,r_elite=RE,r_contrast=RC,top_support_elite=es,top_sign_elite=esg,top_support_contrast=csup,top_sign_contrast=csg)
    rr=dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,PoolSize=S,PoolStatsPass=True,TopPElite=len(es),TopPContrast=len(csup),FinitePass=True,ReusedValidatedObject=False,ElapsedSec=time.perf_counter()-t)
    obj={'elite':(ev,RE,es,esg),'contrast':(cv,RC,csup,csg)}
    del pool,cs,elite,poor,ep,er,bp,br,E,C,PE,PC;gc.collect()
    return obj,rr

def process(pid):
    # skip complete
    if PAIR.exists():
        d=pd.read_csv(PAIR,usecols=['ProblemID'])
        if pid in set(d.ProblemID): return 'SKIP'
    structs=[];reps=[]
    for r in range(1,6):
        o,rr=one(pid,r);structs.append(o);reps.append(rr);print(' REP',pid,r,'sec',round(rr['ElapsedSec'],2),'reuse',rr['ReusedValidatedObject'],flush=True)
    row=core.load_manifest_row(ROOT,pid);pairs=[]
    for mining,key in [('Elite-only','elite'),('Contrast','contrast')]:
        for a in range(5):
            for b in range(a+1,5):
                pv1,R1,s1,sg1=structs[a][key];pv2,R2,s2,sg2=structs[b][key]
                set1=set(map(int,s1));set2=set(map(int,s2));inter=set1&set2;uni=set1|set2
                jac=len(inter)/len(uni) if uni else np.nan
                sign1={int(i):int(s) for i,s in zip(s1,sg1)};sign2={int(i):int(s) for i,s in zip(s2,sg2)}
                dag=float(np.mean([sign1[i]==sign2[i] for i in inter])) if inter else np.nan
                signed1={(int(i),int(s)) for i,s in zip(s1,sg1)};signed2={(int(i),int(s)) for i,s in zip(s2,sg2)}
                sj=len(signed1&signed2)/len(signed1|signed2) if (signed1|signed2) else np.nan
                pref=float(np.mean(np.argmax(R1,axis=1)==np.argmax(R2,axis=1)))
                pairs.append(dict(ProblemID=pid,Group=row['Group'],Mining=mining,PoolA=a+1,PoolB=b+1,P_Jaccard=jac,P_DirectionalAgreement=dag,P_SignedJaccard=sj,P_Pearson=corr(pv1,pv2),P_Spearman=spear(pv1,pv2),R_Pearson=corr(R1.ravel(),R2.ravel()),R_Spearman=spear(R1.ravel(),R2.ravel()),R_MAE=float(np.mean(np.abs(R1-R2))),R_PreferredRegionAgreement=pref))
    append(REP,reps);append(PAIR,pairs);return 'PASS'

if __name__=='__main__':
    man=pd.read_csv(ROOT/'instance_manifest.csv')
    # authoritative missing list from current 121-problem metric union
    b=pd.read_csv('/mnt/data/PFSP_structural_stability_Structural_Metrics/structural_stability_structural_pairwise.csv');r=pd.read_csv('/mnt/data/PFSP_structural_stability_Structural_Metrics/structural_stability_pair_recovery.csv')
    done=set(b.ProblemID)|set(r.ProblemID)
    todo=[p for p in man.ProblemID if p not in done]
    # also remove already completed in this remainder output
    if PAIR.exists(): done2=set(pd.read_csv(PAIR).ProblemID);todo=[p for p in todo if p not in done2]
    print('TODO',len(todo),todo,flush=True)
    for i,pid in enumerate(todo,1):
        t=time.time();res=process(pid);print('PROBLEM',i,'/',len(todo),pid,res,'sec',round(time.time()-t,2),flush=True)
