# structural-stability analysis code notes (archived)

This folder preserves the exact scripts used to generate, recover, finalize, and independently audit the structural-stability analysis five-pool structural-stability analysis. structural-stability analysis is descriptive stability evidence; it does not tune parameters.

Core outputs expected from the results package:
- 700 problem x pool structural objects
- 2,800 pairwise structural comparisons
- 1,400 guided-output-variability cells
- 7,000 exact ablation analysis P+R regression checks

The workflow evolved through checkpoint/recovery steps because of runtime interruptions. The final scientific tables are defined by `structural_stability_finalize_master.py` and then independently checked from the saved objects by `structural_stability_archive_independent_qa.py`. These scripts retain the original absolute `/mnt/data` paths for archival fidelity. The final public release will convert this development archive into a single portable runner after analyses 7-9 are frozen.
