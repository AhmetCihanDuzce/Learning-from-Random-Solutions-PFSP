from pathlib import Path
import pandas as pd, numpy as np, json, shutil, hashlib, os
BASE=Path('/mnt/data')
OUT=BASE/'PFSP_structural_stability_Structural_Stability_FINAL_PACKAGE'; OUT.mkdir(exist_ok=True)
# Inputs
pair_files=[BASE/'PFSP_structural_stability_Structural_Metrics/structural_stability_structural_pairwise.csv',BASE/'PFSP_structural_stability_Structural_Metrics/structural_stability_pair_recovery.csv',BASE/'PFSP_structural_stability_N200_REMAINDER/structural_stability_n200_pairwise.csv']
rep_files=[BASE/'PFSP_structural_stability_Structural_Metrics/structural_stability_structure_regeneration_audit.csv',BASE/'PFSP_structural_stability_Structural_Metrics/structural_stability_rep_recovery.csv',BASE/'PFSP_structural_stability_N200_REMAINDER/structural_stability_n200_structure_audit.csv']
pair=pd.concat([pd.read_csv(p) for p in pair_files],ignore_index=True)
rep=pd.concat([pd.read_csv(p) for p in rep_files],ignore_index=True,sort=False)
# Normalize
pair=pair.sort_values(['ProblemID','Mining','PoolA','PoolB']).reset_index(drop=True)
rep=rep.sort_values(['ProblemID','Replication']).reset_index(drop=True)
pair.to_csv(OUT/'structural_stability_structural_pairwise_MASTER.csv',index=False)
rep.to_csv(OUT/'structural_stability_structure_regeneration_audit_MASTER.csv',index=False)
# authoritative structural_stability upstreams
for srcname in ['structural_stability_guided_output_variability.csv','structural_stability_guided_output_variability_summary.csv','structural_stability_ablation_regression_audit_MASTER.csv','structural_stability_replication_audit_MASTER.csv']:
    shutil.copy2(BASE/'PFSP_structural_stability_Structural_Stability_MASTER'/srcname, OUT/srcname)
shutil.copy2(BASE/'PFSP_structural_stability_FROZEN_PROTOCOL.md',OUT/'PFSP_structural_stability_FROZEN_PROTOCOL.md')
# manifests / ablation
root=BASE/'pfsp_code/PFSP_Code_Ablation_Sensitivity_OFAT/core'
man=pd.read_csv(root/'instance_manifest.csv')
expected_pids=list(man.ProblemID)
exp_pair={(p,m,a,b) for p in expected_pids for m in ['Elite-only','Contrast'] for a in range(1,6) for b in range(a+1,6)}
obs_pair=set(map(tuple,pair[['ProblemID','Mining','PoolA','PoolB']].itertuples(index=False,name=None)))
exp_rep={(p,r) for p in expected_pids for r in range(1,6)}
obs_rep=set(map(tuple,rep[['ProblemID','Replication']].itertuples(index=False,name=None)))
# structural summary long
metrics=['P_Jaccard','P_DirectionalAgreement','P_SignedJaccard','P_Pearson','P_Spearman','R_Pearson','R_Spearman','R_MAE','R_PreferredRegionAgreement']
rows=[]
for scope,gbcols in [('Overall',['Mining']),('ByGroup',['Group','Mining'])]:
    for keys,g in pair.groupby(gbcols):
        if not isinstance(keys,tuple):keys=(keys,)
        meta=dict(Scope=scope)
        for c,v in zip(gbcols,keys):meta[c]=v
        for met in metrics:
            x=pd.to_numeric(g[met],errors='coerce').dropna().to_numpy(float)
            rows.append({**meta,'Metric':met,'N':len(x),'Mean':float(np.mean(x)),'Median':float(np.median(x)),'Q1':float(np.quantile(x,.25)),'Q3':float(np.quantile(x,.75)),'IQR':float(np.quantile(x,.75)-np.quantile(x,.25)),'Min':float(np.min(x)),'Max':float(np.max(x))})
sumdf=pd.DataFrame(rows)
sumdf.to_csv(OUT/'structural_stability_structural_stability_summary.csv',index=False)
# wide overall publication-friendly
wide=[]
for mining,g in pair.groupby('Mining'):
    r={'Mining':mining,'N_pool_pairs':len(g)}
    for met in metrics:
        x=pd.to_numeric(g[met],errors='coerce').dropna().to_numpy(float)
        r[met+'_Mean']=float(np.mean(x));r[met+'_Median']=float(np.median(x));r[met+'_IQR']=float(np.quantile(x,.75)-np.quantile(x,.25))
    wide.append(r)
pd.DataFrame(wide).to_csv(OUT/'structural_stability_structural_stability_overall.csv',index=False)
# independent guided variability recomputation from ablation P+R
s3=pd.read_csv(BASE/'PFSP_ablation_Ablation_MASTER/ablation_ablation_raw_MASTER.csv')
p=s3[s3.Mode.eq('P+R')].copy()
calc=[]
for (pid,grp,mining,fam),g in p.groupby(['ProblemID','Group','Mining','Family'],sort=False):
    c=g.Cmax.to_numpy(float); seq=g.Sequence.astype(str)
    calc.append(dict(ProblemID=pid,Group=grp,Mining=mining,Family=fam,MeanCmax=float(c.mean()),SDCmax=float(c.std(ddof=1)),CV_pct=float(100*c.std(ddof=1)/c.mean()),RangeCmax=float(c.max()-c.min()),RelativeRange_pct=float(100*(c.max()-c.min())/c.mean()),DistinctCmax=int(pd.Series(c).nunique()),DistinctPermutations=int(seq.nunique())))
calc=pd.DataFrame(calc).sort_values(['ProblemID','Mining','Family']).reset_index(drop=True)
guided=pd.read_csv(OUT/'structural_stability_guided_output_variability.csv').sort_values(['ProblemID','Mining','Family']).reset_index(drop=True)
numcols=['MeanCmax','SDCmax','CV_pct','RangeCmax','RelativeRange_pct']
guided_match=(len(calc)==len(guided) and calc[['ProblemID','Group','Mining','Family','DistinctCmax','DistinctPermutations']].equals(guided[['ProblemID','Group','Mining','Family','DistinctCmax','DistinctPermutations']]) and all(np.allclose(calc[c],guided[c],rtol=0,atol=1e-12,equal_nan=True) for c in numcols))
# regression checks
reg=pd.read_csv(OUT/'structural_stability_ablation_regression_audit_MASTER.csv')
rep700=pd.read_csv(OUT/'structural_stability_replication_audit_MASTER.csv')
# independent ablation Cmax join
s3pr=p[['ProblemID','Replication','Seed','Mining','Family','Cmax','Sequence']].copy()
rj=reg.merge(s3pr,on=['ProblemID','Replication','Seed','Mining','Family'],how='outer',indicator=True,suffixes=('_reg','_s3'))
reg_cmax_join=(len(rj)==7000 and (rj._merge=='both').all() and (rj.GotCmax==rj.Cmax).all() and (rj.ExpectedCmax==rj.Cmax).all())
# structural audit compared to master replication seeds/dims/pool sizes
cmp=rep.merge(rep700[['ProblemID','Replication','Group','n','m','Seed','PoolSize']],on=['ProblemID','Replication'],how='outer',indicator=True,suffixes=('_struct','_master'))
struct_manifest_match=(len(cmp)==700 and (cmp._merge=='both').all() and (cmp.Group_struct==cmp.Group_master).all() and (cmp.n_struct==cmp.n_master).all() and (cmp.m_struct==cmp.m_master).all() and (cmp.Seed_struct==cmp.Seed_master).all() and (cmp.PoolSize_struct==cmp.PoolSize_master).all())
# ranges and finite
metric_finite=bool(np.isfinite(pair[metrics].to_numpy(float)).all())
unit_range=['P_Jaccard','P_DirectionalAgreement','P_SignedJaccard','P_Pearson','P_Spearman','R_Pearson','R_Spearman','R_PreferredRegionAgreement']
range_ok=True
for c in unit_range:
    if c in ['P_Pearson','P_Spearman','R_Pearson','R_Spearman']:
        range_ok &= bool(((pair[c]>=-1-1e-12)&(pair[c]<=1+1e-12)).all())
    else: range_ok &= bool(((pair[c]>=-1e-12)&(pair[c]<=1+1e-12)).all())
range_ok &= bool((pair.R_MAE>=-1e-15).all())
# top-P expected
rep['ExpectedTopP']=np.minimum(3*rep['n'].astype(int), rep['n'].astype(int)*(rep['n'].astype(int)-1)//2)
toppass=bool((rep.TopPElite==rep.ExpectedTopP).all() and (rep.TopPContrast==rep.ExpectedTopP).all())
qa={
 'analysis_phase':'structural-stability analysis Structural Stability',
 'status_metrics':'GREEN' if all([len(pair)==2800,len(obs_pair)==2800,obs_pair==exp_pair,len(rep)==700,len(obs_rep)==700,obs_rep==exp_rep,metric_finite,range_ok,toppass,struct_manifest_match,guided_match,len(guided)==1400,len(reg)==7000,bool(reg.Pass.all()),bool(reg.CmaxPass.all()),bool(reg.SequencePass.all()),reg_cmax_join,len(rep700)==700,bool(rep700.ablationRegressionPass.all()),bool(rep.PoolStatsPass.all()),bool(rep.FinitePass.all())]) else 'RED',
 'counts':{'problems_expected':140,'structural_pairwise_rows':len(pair),'structural_pairwise_unique_keys':len(obs_pair),'structural_replication_rows':len(rep),'structural_replication_unique_keys':len(obs_rep),'guided_variability_rows':len(guided),'ablation_regression_rows':len(reg),'structural_stability_replication_master_rows':len(rep700)},
 'checks':{
   'all_140_problems_in_pairwise':pair.ProblemID.nunique()==140,
   'pairwise_expected_keys_exact':obs_pair==exp_pair,
   'pairwise_no_duplicates':not pair.duplicated(['ProblemID','Mining','PoolA','PoolB']).any(),
   'structural_rep_expected_keys_exact':obs_rep==exp_rep,
   'structural_rep_no_duplicates':not rep.duplicated(['ProblemID','Replication']).any(),
   'structural_seed_dim_pool_manifest_match':struct_manifest_match,
   'pool_stats_pass_700_of_700':bool(rep.PoolStatsPass.all()),
   'finite_structural_arrays_audit_700_of_700':bool(rep.FinitePass.all()),
   'topP_support_exact_700_of_700':toppass,
   'pairwise_metrics_all_finite':metric_finite,
   'pairwise_metric_ranges_valid':range_ok,
   'guided_variability_independent_recompute_exact':guided_match,
   'guided_variability_1400_rows':len(guided)==1400,
   'ablation_regression_7000_rows':len(reg)==7000,
   'ablation_regression_all_pass':bool(reg.Pass.all() and reg.CmaxPass.all() and reg.SequencePass.all()),
   'ablation_Cmax_independent_join_exact':reg_cmax_join,
   'replication_master_700_rows':len(rep700)==700,
   'replication_master_ablation_pass_all':bool(rep700.ablationRegressionPass.all())
 },
 'artifact_completeness':{'required_structural_npz':700,'current_archive_npz':None,'archive_complete':None}
}
(OUT/'structural_stability_MASTER_QA.json').write_text(json.dumps(qa,indent=2,default=lambda o: bool(o) if isinstance(o,np.bool_) else (int(o) if isinstance(o,np.integer) else float(o))),encoding='utf-8')
print(json.dumps(qa,indent=2,default=lambda o: bool(o) if isinstance(o,np.bool_) else (int(o) if isinstance(o,np.integer) else float(o))))
print('\nOVERALL')
print(pd.DataFrame(wide).to_string(index=False))
