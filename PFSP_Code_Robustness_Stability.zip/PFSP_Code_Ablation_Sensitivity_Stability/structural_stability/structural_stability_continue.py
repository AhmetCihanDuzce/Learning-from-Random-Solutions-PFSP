#!/usr/bin/env python3
from pathlib import Path
import sys, time, hashlib, json, csv, gc, argparse
import numpy as np
import pandas as pd

ROOT=Path('/mnt/data/pfsp_code/PFSP_Code_Ablation_Sensitivity_OFAT/core')
sys.path.insert(0,str(ROOT))
import ablation_ablation_runner_HISTCOMPAT as s3
import run_pfsp_single as core
from numba import set_num_threads

S3RAW=Path('/mnt/data/PFSP_ablation_Ablation_MASTER/ablation_ablation_raw_MASTER.csv')
S3POOL=Path('/mnt/data/PFSP_ablation_Ablation_MASTER/ablation_pool_audit_MASTER.csv')
OUT=Path('/mnt/data/PFSP_structural_stability_Structural_Stability_CONTINUATION')
STRUCT=OUT/'structures'
OUT.mkdir(exist_ok=True); STRUCT.mkdir(exist_ok=True)

raw=pd.read_csv(S3RAW)
raw=raw[raw['Mode'].eq('P+R')].copy()
raw_key={(r.ProblemID,int(r.Replication),r.Mining,r.Family):(int(r.Cmax),str(r.Sequence)) for r in raw.itertuples(index=False)}
poolref=pd.read_csv(S3POOL)
pool_key={(r.ProblemID,int(r.Replication)):r for r in poolref.itertuples(index=False)}

FAMILIES=list(s3.FAMILIES)

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def append_rows(path, rows):
    if not rows:return
    new=not path.exists()
    with open(path,'a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
        if new:w.writeheader()
        w.writerows(rows)

def done_keys():
    p=OUT/'structural_stability_replication_audit_continuation.csv'
    if not p.exists(): return set()
    d=pd.read_csv(p)
    return set(zip(d.ProblemID,d.Replication.astype(int)))

def run_one(pid,rep,use_fast_stats=True):
    row=core.load_manifest_row(ROOT,pid); p,meta=core.load_instance(ROOT,row); n,m=p.shape
    seeds=core.load_seed_rows(ROOT,pid); seed=int(seeds[rep-1]['Seed']); pool_size=int(seeds[rep-1]['PoolSize'])
    assert pool_size==10000*n
    elite_n=round(.05*pool_size); poor_n=round(.10*pool_size); regions=4; top_p=3*n; q_info=4
    t0=time.perf_counter()
    pool=s3.generate_pool_array_parallel(seed,pool_size,n,100000,16)
    cs=s3.cmax_memmap_parallel(pool,p,250000,5)
    eidx,bidx=core.selection_indices(cs,elite_n,poor_n,s3.tie_mode_for(pid))
    elite=np.asarray(pool[eidx,:],dtype=np.uint16); poor=np.asarray(pool[bidx,:],dtype=np.uint16)
    if use_fast_stats:
        set_num_threads(5)
        ep,er=s3.fast_group_stats(elite,n,regions); bp,br=s3.fast_group_stats(poor,n,regions)
    else:
        ep,er=s3.thread_group_stats(elite,n,regions,4); bp,br=s3.thread_group_stats(poor,n,regions,4)
    scoreE=ep-0.5; scoreC=ep-bp
    RE=er-0.25; RC=er-br
    PE=s3.historical_filter_precedence(scoreE,top_p); PC=s3.historical_filter_precedence(scoreC,top_p)
    iu=np.triu_indices(n,1)
    ev=scoreE[iu].astype(np.float64,copy=False); cv=scoreC[iu].astype(np.float64,copy=False)
    e_support=np.flatnonzero(PE[iu]!=0).astype(np.int32); c_support=np.flatnonzero(PC[iu]!=0).astype(np.int32)
    e_sign=np.sign(PE[iu][e_support]).astype(np.int8); c_sign=np.sign(PC[iu][c_support]).astype(np.int8)
    assert len(e_support)==min(top_p,len(ev)) and len(c_support)==min(top_p,len(cv))
    # pool reference QA
    pr=pool_key[(pid,rep)]
    stats_pass=(int(cs.min())==int(pr.PoolBest) and int(cs.max())==int(pr.PoolWorst)
                and abs(float(cs.mean())-float(pr.PoolMean))<=1e-9
                and abs(float(cs.std(ddof=1))-float(pr.PoolSD))<=1e-9)
    if not stats_pass:
        raise RuntimeError(f'POOL QA FAIL {pid} r{rep}: got {(cs.min(),cs.mean(),cs.std(ddof=1),cs.max())} ref {(pr.PoolBest,pr.PoolMean,pr.PoolSD,pr.PoolWorst)}')
    # exact historical P+R regression incl sequence
    tpt=core.tpt_order(p); kk=core.kk2_style_order(p)
    audit=[]
    for mining,P,R in [('Elite-only',PE,RE),('Contrast',PC,RC)]:
        runs=[
          s3.construct_info_neh_w(tpt,p,P,R,0,.65,.35),
          s3.construct_info_neh_w(tpt,p,P,R,2,.65,.35),
          s3.construct_info_neh_w(kk,p,P,R,2,.65,.35),
          s3.construct_info_frb4_w(tpt,p,P,R,1,q_info,2,.65,.35),
          s3.construct_info_frb4_w(kk,p,P,R,1,q_info,2,.65,.35),
        ]
        for fam,(seq,c) in zip(FAMILIES,runs):
            core.validate_solution(seq,c,p,n)
            expc,exps=raw_key[(pid,rep,mining,fam)]
            gotseq=' '.join(str(x+1) for x in seq)
            cp=(int(c)==expc); sp=(gotseq==exps)
            audit.append(dict(ProblemID=pid,Replication=rep,Seed=seed,Mining=mining,Family=fam,GotCmax=int(c),ExpectedCmax=expc,CmaxPass=cp,SequencePass=sp,Pass=(cp and sp)))
    if not all(x['Pass'] for x in audit):
        raise RuntimeError(f'ablation REG FAIL {pid} r{rep}: {[x for x in audit if not x["Pass"]][:3]}')
    # save structure
    out=STRUCT/f'{pid}__rep{rep}.npz'
    np.savez_compressed(out,
        ProblemID=np.array(pid), Group=np.array(row['Group']), n=np.int32(n), m=np.int32(m), Replication=np.int16(rep), Seed=np.int64(seed),
        p_upper_elite=ev, p_upper_contrast=cv, r_elite=RE.astype(np.float64), r_contrast=RC.astype(np.float64),
        top_support_elite=e_support, top_sign_elite=e_sign, top_support_contrast=c_support, top_sign_contrast=c_sign)
    sh=sha256_file(out)
    elapsed=time.perf_counter()-t0
    repaudit=dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,PoolSize=pool_size,
        PoolBest=int(cs.min()),PoolMean=float(cs.mean()),PoolSD=float(cs.std(ddof=1)),PoolWorst=int(cs.max()),EliteN=elite_n,PoorN=poor_n,
        TieMode=s3.tie_mode_for(pid),TopP=top_p,ablationPoolStatsPass=True,ablationRegressionMatched=10,ablationRegressionChecked=10,ablationRegressionPass=True,
        StructureFile=out.name,StructureSHA256=sh,ElapsedSec=elapsed)
    del pool,cs,elite,poor,ep,er,bp,br,scoreE,scoreC,PE,PC,RE,RC
    gc.collect()
    return repaudit,audit

def all_missing_union():
    man=pd.read_csv(ROOT/'instance_manifest.csv')
    # union of every historical structural_stability audit currently available
    import glob, os
    U=set()
    for g in ['/mnt/data/PFSP_structural_stability_Structural_Stability/*.csv','/mnt/data/PFSP_structural_stability_Structural_Stability_FINAL/*.csv',str(OUT/'*.csv')]:
      for fp in glob.glob(g):
        try:d=pd.read_csv(fp)
        except:continue
        if {'ProblemID','Replication'}<=set(d.columns): U |= set(zip(d.ProblemID,d.Replication.astype(int)))
    return [(pid,r) for pid in man.ProblemID for r in range(1,6) if (pid,r) not in U]

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--limit',type=int,default=0); ap.add_argument('--pid'); ap.add_argument('--rep',type=int); ap.add_argument('--slow-stats',action='store_true')
    a=ap.parse_args()
    todo=[(a.pid,a.rep)] if a.pid else all_missing_union()
    done=done_keys(); todo=[x for x in todo if x not in done]
    if a.limit:todo=todo[:a.limit]
    print('TODO',len(todo),todo[:10],flush=True)
    for i,(pid,rep) in enumerate(todo,1):
        print(f'RUN {i}/{len(todo)} {pid} rep{rep}',flush=True)
        rr,aa=run_one(pid,rep,use_fast_stats=not a.slow_stats)
        append_rows(OUT/'structural_stability_replication_audit_continuation.csv',[rr])
        append_rows(OUT/'structural_stability_ablation_regression_audit_continuation.csv',aa)
        print('PASS',pid,rep,'sec',round(rr['ElapsedSec'],2),flush=True)
