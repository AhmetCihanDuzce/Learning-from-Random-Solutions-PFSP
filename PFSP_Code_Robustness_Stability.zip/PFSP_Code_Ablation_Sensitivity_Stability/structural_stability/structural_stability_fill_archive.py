#!/usr/bin/env python3
from pathlib import Path
import sys,importlib.util,pandas as pd,shutil,io,numpy as np,time
ARCH=Path('/mnt/data/PFSP_structural_stability_Structure_Archive_RECOVERED');ARCH.mkdir(exist_ok=True)
ROOT=Path('/mnt/data/pfsp_code/PFSP_Code_Ablation_Sensitivity_OFAT/core')
# modules
spec=importlib.util.spec_from_file_location('m','/mnt/data/structural_stability_metrics_runner.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
spec2=importlib.util.spec_from_file_location('n2','/mnt/data/structural_stability_finish_n200.py');n2=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(n2)
# copy any existing useful structures first
for d in [Path('/mnt/data/PFSP_structural_stability_Structural_Stability_CONTINUATION/structures'),Path('/mnt/data/PFSP_structural_stability_N200_REMAINDER/structures')]:
    if d.exists():
        for p in d.glob('*.npz'):
            t=ARCH/p.name
            if not t.exists():shutil.copy2(p,t)
man=pd.read_csv(ROOT/'instance_manifest.csv')
args=sys.argv[1:]
# arguments are group names or ALL
allowed=set(args)
count=0
for r in man.itertuples(index=False):
    if args and 'ALL' not in allowed and str(r.Group) not in allowed: continue
    pid=r.ProblemID
    for rep in range(1,6):
        t=ARCH/f'{pid}__rep{rep}.npz'
        if t.exists():continue
        st=time.time()
        if int(r.n)==200:
            obj,rr=n2.one(pid,rep)
            src=n2.STRUCT/f'{pid}__rep{rep}.npz'
            shutil.copy2(src,t)
        else:
            obj,rr,b=m.one_structure(pid,rep,save_bytes=True)
            t.write_bytes(b)
        # load validation
        z=np.load(t)
        for k in ['p_upper_elite','p_upper_contrast','r_elite','r_contrast','top_support_elite','top_support_contrast']:_=z[k]
        count+=1
        print('SAVED',count,pid,rep,'sec',round(time.time()-st,2),'total',len(list(ARCH.glob('*.npz'))),flush=True)
print('DONE new',count,'total',len(list(ARCH.glob('*.npz'))),flush=True)
