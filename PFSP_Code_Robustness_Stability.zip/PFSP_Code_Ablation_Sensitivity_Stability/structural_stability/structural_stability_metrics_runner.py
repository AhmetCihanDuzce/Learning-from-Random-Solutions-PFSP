#!/usr/bin/env python3
from pathlib import Path
import sys,time,hashlib,csv,gc,argparse,zipfile,io,glob
import numpy as np, pandas as pd
from scipy.stats import rankdata
ROOT=Path('/mnt/data/pfsp_code/PFSP_Code_Ablation_Sensitivity_OFAT/core'); sys.path.insert(0,str(ROOT))
import ablation_ablation_runner_HISTCOMPAT as s3
import run_pfsp_single as core
from numba import set_num_threads
OUT=Path('/mnt/data/PFSP_structural_stability_Structural_Metrics'); OUT.mkdir(exist_ok=True)
PAIR=OUT/'structural_stability_structural_pairwise.csv'; REP=OUT/'structural_stability_structure_regeneration_audit.csv'
S3POOL=pd.read_csv('/mnt/data/PFSP_ablation_Ablation_MASTER/ablation_pool_audit_MASTER.csv')
poolkey={(r.ProblemID,int(r.Replication)):r for r in S3POOL.itertuples(index=False)}

def app(path,rows):
 if not rows:return
 new=not path.exists()
 with path.open('a',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));
  if new:w.writeheader()
  w.writerows(rows)

def done_pids():
 if not PAIR.exists():return set()
 d=pd.read_csv(PAIR,usecols=['ProblemID']); return set(d.ProblemID.unique())

def corr(a,b):
 a=np.asarray(a,float); b=np.asarray(b,float)
 sa=a.std(); sb=b.std()
 if sa==0 or sb==0:return np.nan
 return float(np.corrcoef(a,b)[0,1])

def spear(a,b):
 return corr(rankdata(a,method='average'),rankdata(b,method='average'))

def one_structure(pid,rep,save_bytes=False):
 row=core.load_manifest_row(ROOT,pid); p,_=core.load_instance(ROOT,row); n,m=p.shape
 seed=int(core.load_seed_rows(ROOT,pid)[rep-1]['Seed']); S=10000*n; en=round(.05*S); pn=round(.10*S); k=3*n
 t=time.perf_counter()
 pool=s3.generate_pool_array_parallel(seed,S,n,100000,16); cs=s3.cmax_memmap_parallel(pool,p,250000,5)
 ei,bi=core.selection_indices(cs,en,pn,s3.tie_mode_for(pid)); elite=np.asarray(pool[ei],np.uint16); poor=np.asarray(pool[bi],np.uint16)
 set_num_threads(5); ep,er=s3.fast_group_stats(elite,n,4); bp,br=s3.fast_group_stats(poor,n,4)
 E=ep-.5; C=ep-bp; RE=er-.25; RC=er-br; iu=np.triu_indices(n,1)
 ev=E[iu].copy(); cv=C[iu].copy(); PE=s3.historical_filter_precedence(E,k); PC=s3.historical_filter_precedence(C,k)
 es=np.flatnonzero(PE[iu]!=0).astype(np.int32); csup=np.flatnonzero(PC[iu]!=0).astype(np.int32)
 esg=np.sign(PE[iu][es]).astype(np.int8); csg=np.sign(PC[iu][csup]).astype(np.int8)
 pr=poolkey[(pid,rep)]
 ok=int(cs.min())==int(pr.PoolBest) and int(cs.max())==int(pr.PoolWorst) and abs(float(cs.mean())-float(pr.PoolMean))<1e-9 and abs(float(cs.std(ddof=1))-float(pr.PoolSD))<1e-9
 if not ok:raise RuntimeError(('pool mismatch',pid,rep))
 if len(es)!=min(k,len(ev)) or len(csup)!=min(k,len(cv)):raise RuntimeError(('support',pid,rep,len(es),len(csup)))
 bts=None
 if save_bytes:
  bio=io.BytesIO(); np.savez_compressed(bio,ProblemID=np.array(pid),Replication=np.int16(rep),Seed=np.int64(seed),p_upper_elite=ev,p_upper_contrast=cv,r_elite=RE,r_contrast=RC,top_support_elite=es,top_sign_elite=esg,top_support_contrast=csup,top_sign_contrast=csg); bts=bio.getvalue()
 rr=dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,PoolSize=S,PoolStatsPass=True,TopPElite=len(es),TopPContrast=len(csup),FinitePass=bool(np.isfinite(ev).all() and np.isfinite(cv).all() and np.isfinite(RE).all() and np.isfinite(RC).all()),ElapsedSec=time.perf_counter()-t)
 obj={'elite':(ev,RE,es,esg),'contrast':(cv,RC,csup,csg)}
 del pool,cs,elite,poor,ep,er,bp,br,E,C,PE,PC; gc.collect()
 return obj,rr,bts

def process(pid,zip_path=None):
 row=core.load_manifest_row(ROOT,pid); structs=[]; reps=[]; zf=None
 if zip_path: zf=zipfile.ZipFile(zip_path,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6)
 try:
  for r in range(1,6):
   o,rr,b=one_structure(pid,r,save_bytes=bool(zf)); structs.append(o); reps.append(rr)
   if zf:zname=f'structures/{pid}__rep{r}.npz'; zf.writestr(zname,b)
 finally:
  if zf:zf.close()
 pairs=[]
 for mining,key in [('Elite-only','elite'),('Contrast','contrast')]:
  for a in range(5):
   for b in range(a+1,5):
    pv1,R1,s1,sg1=structs[a][key]; pv2,R2,s2,sg2=structs[b][key]
    set1=set(map(int,s1)); set2=set(map(int,s2)); inter=set1&set2; uni=set1|set2
    jac=len(inter)/len(uni) if uni else np.nan
    signmap1={int(i):int(s) for i,s in zip(s1,sg1)}; signmap2={int(i):int(s) for i,s in zip(s2,sg2)}
    dag=np.mean([signmap1[i]==signmap2[i] for i in inter]) if inter else np.nan
    signed1={(int(i),int(s)) for i,s in zip(s1,sg1)}; signed2={(int(i),int(s)) for i,s in zip(s2,sg2)}
    sj=len(signed1&signed2)/len(signed1|signed2) if (signed1|signed2) else np.nan
    pref=float(np.mean(np.argmax(R1,axis=1)==np.argmax(R2,axis=1)))
    pairs.append(dict(ProblemID=pid,Group=row['Group'],Mining=mining,PoolA=a+1,PoolB=b+1,P_Jaccard=jac,P_DirectionalAgreement=dag,P_SignedJaccard=sj,P_Pearson=corr(pv1,pv2),P_Spearman=spear(pv1,pv2),R_Pearson=corr(R1.ravel(),R2.ravel()),R_Spearman=spear(R1.ravel(),R2.ravel()),R_MAE=float(np.mean(np.abs(R1-R2))),R_PreferredRegionAgreement=pref))
 app(REP,reps); app(PAIR,pairs)
 return reps,pairs

if __name__=='__main__':
 ap=argparse.ArgumentParser(); ap.add_argument('--group-regex'); ap.add_argument('--limit',type=int,default=0); ap.add_argument('--zip'); args=ap.parse_args()
 man=pd.read_csv(ROOT/'instance_manifest.csv'); pids=list(man.ProblemID); done=done_pids(); pids=[p for p in pids if p not in done]
 if args.group_regex:
  import re; rg=re.compile(args.group_regex); pids=[p for p in pids if rg.search(str(man.loc[man.ProblemID.eq(p),'Group'].iloc[0]))]
 if args.limit:pids=pids[:args.limit]
 print('PIDS',len(pids),pids[:10],flush=True)
 for i,pid in enumerate(pids,1):
  t=time.time(); process(pid,args.zip); print('PASS',i,len(pids),pid,'sec',round(time.time()-t,2),flush=True)
