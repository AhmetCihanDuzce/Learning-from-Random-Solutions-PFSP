from pathlib import Path
import numpy as np,pandas as pd,json
from scipy.stats import rankdata
BASE=Path('/mnt/data')
ARCH=BASE/'PFSP_structural_stability_Structure_Archive_RECOVERED'
OUT=BASE/'PFSP_structural_stability_Structural_Stability_FINAL_PACKAGE'
master=pd.read_csv(OUT/'structural_stability_structural_pairwise_MASTER.csv').sort_values(['ProblemID','Mining','PoolA','PoolB']).reset_index(drop=True)
rep700=pd.read_csv(OUT/'structural_stability_replication_audit_MASTER.csv')
meta={(r.ProblemID,int(r.Replication)):r for r in rep700.itertuples(index=False)}

def corr(a,b):
    a=np.asarray(a,float);b=np.asarray(b,float);sa=a.std();sb=b.std()
    return np.nan if sa==0 or sb==0 else float(np.corrcoef(a,b)[0,1])
def spear(a,b): return corr(rankdata(a,method='average'),rankdata(b,method='average'))
files=sorted(ARCH.glob('*.npz'))
expected={(r.ProblemID,rep) for r in rep700.drop_duplicates('ProblemID').itertuples(index=False) for rep in range(1,6)}
observed=set()
object_checks=[]
by_problem={}
for p in files:
    z=np.load(p)
    pid=str(z['ProblemID'].item()); rep=int(z['Replication']); seed=int(z['Seed'])
    observed.add((pid,rep)); rr=meta[(pid,rep)]; n=int(rr.n)
    exp_len=n*(n-1)//2; expk=min(3*n,exp_len)
    finite=True; shape=True; support=True; sign=True
    for key in ['p_upper_elite','p_upper_contrast']:
        a=np.asarray(z[key]); shape &= (a.shape==(exp_len,)); finite &= bool(np.isfinite(a).all())
    for key in ['r_elite','r_contrast']:
        a=np.asarray(z[key]); shape &= (a.shape==(n,4)); finite &= bool(np.isfinite(a).all())
    for sk,sgk in [('top_support_elite','top_sign_elite'),('top_support_contrast','top_sign_contrast')]:
        s=np.asarray(z[sk]); sg=np.asarray(z[sgk]);
        support &= (len(s)==expk and len(np.unique(s))==expk and np.all((s>=0)&(s<exp_len)))
        sign &= (sg.shape==(expk,) and np.all(np.isin(sg,[-1,1])))
    object_checks.append(dict(ProblemID=pid,Replication=rep,SeedPass=(seed==int(rr.Seed)),ShapePass=shape,FinitePass=finite,SupportPass=support,SignPass=sign))
    by_problem.setdefault(pid,{})[rep]={k:np.asarray(z[k]) for k in ['p_upper_elite','p_upper_contrast','r_elite','r_contrast','top_support_elite','top_sign_elite','top_support_contrast','top_sign_contrast']}
obj=pd.DataFrame(object_checks).sort_values(['ProblemID','Replication']).reset_index(drop=True)
obj.to_csv(OUT/'structural_stability_structure_archive_object_QA.csv',index=False)
rows=[]
for pid,reps in sorted(by_problem.items()):
    grp=meta[(pid,1)].Group
    for mining,pk,rk,sk,sgk in [
        ('Elite-only','p_upper_elite','r_elite','top_support_elite','top_sign_elite'),
        ('Contrast','p_upper_contrast','r_contrast','top_support_contrast','top_sign_contrast')]:
        for a in range(1,6):
            for b in range(a+1,6):
                A=reps[a];B=reps[b]
                pv1,pv2=A[pk],B[pk];R1,R2=A[rk],B[rk];s1,s2=A[sk],B[sk];sg1,sg2=A[sgk],B[sgk]
                set1=set(map(int,s1));set2=set(map(int,s2));inter=set1&set2;uni=set1|set2
                jac=len(inter)/len(uni)
                sign1={int(i):int(s) for i,s in zip(s1,sg1)};sign2={int(i):int(s) for i,s in zip(s2,sg2)}
                dag=float(np.mean([sign1[i]==sign2[i] for i in inter])) if inter else np.nan
                signed1={(int(i),int(s)) for i,s in zip(s1,sg1)};signed2={(int(i),int(s)) for i,s in zip(s2,sg2)}
                sj=len(signed1&signed2)/len(signed1|signed2)
                pref=float(np.mean(np.argmax(R1,axis=1)==np.argmax(R2,axis=1)))
                rows.append(dict(ProblemID=pid,Group=grp,Mining=mining,PoolA=a,PoolB=b,P_Jaccard=jac,P_DirectionalAgreement=dag,P_SignedJaccard=sj,P_Pearson=corr(pv1,pv2),P_Spearman=spear(pv1,pv2),R_Pearson=corr(R1.ravel(),R2.ravel()),R_Spearman=spear(R1.ravel(),R2.ravel()),R_MAE=float(np.mean(np.abs(R1-R2))),R_PreferredRegionAgreement=pref))
recalc=pd.DataFrame(rows).sort_values(['ProblemID','Mining','PoolA','PoolB']).reset_index(drop=True)
recalc.to_csv(OUT/'structural_stability_structural_pairwise_RECOMPUTED_FROM_ARCHIVE.csv',index=False)
keys=['ProblemID','Group','Mining','PoolA','PoolB']
metric=[c for c in master.columns if c not in keys]
keymatch=recalc[keys].equals(master[keys])
maxdiff={c:float(np.nanmax(np.abs(recalc[c].to_numpy(float)-master[c].to_numpy(float)))) for c in metric}
metricmatch=all(v<=1e-12 for v in maxdiff.values())
qa_path=OUT/'structural_stability_MASTER_QA.json';qa=json.loads(qa_path.read_text())
qa['artifact_completeness']={'required_structural_npz':700,'current_archive_npz':len(files),'archive_complete':len(files)==700 and observed==expected,'object_seed_shape_finite_support_sign_all_pass':bool(obj[['SeedPass','ShapePass','FinitePass','SupportPass','SignPass']].all().all()),'pairwise_recomputed_from_saved_archive_exact':bool(keymatch and metricmatch),'pairwise_recompute_max_abs_diff':maxdiff}
qa['status']='GREEN' if qa.get('status_metrics')=='GREEN' and all([qa['artifact_completeness']['archive_complete'],qa['artifact_completeness']['object_seed_shape_finite_support_sign_all_pass'],qa['artifact_completeness']['pairwise_recomputed_from_saved_archive_exact']]) else 'RED'
qa_path.write_text(json.dumps(qa,indent=2),encoding='utf-8')
print(json.dumps(qa,indent=2))
