# PFSP Code Package - archived ablation, weight-sensitivity, and OFAT-robustness analyses

Date: 2026-09-11
Status: archived research code snapshot; a final cleaned repository will be prepared with the final manuscript.

## What this package reproduces

1. ablation analysis: full 140-instance P-only / R-only / P+R ablation.
2. weight-sensitivity analysis: six P/R weight settings on the frozen 28-instance panel.
3. OFAT-robustness analysis: OFAT robustness on top-P, R-region count, q, Elite fraction, and Poor fraction on the same 28-instance panel.

All three analyses retain exact historical P+R/baseline regression gates.

## Environment

Recommended frozen environment:

```text
Python 3.13.5
NumPy 2.3.5
Numba 0.65.1
```

Install:

```bash
python -m pip install -r requirements.txt
```

## Quick validation

Run:

```bash
python self_test.py
```

The self-test replays `Ta20_5_1`, replication 1, for analyses 3, 4 and 5 and requires all historical baseline regression cells to pass.

## ablation analysis

```bash
cd core
python ablation_ablation_runner_HISTCOMPAT.py --problem Ta20_5_1 --rep 1 --outdir ../results_ablation
```

Omit `--problem` and `--rep` only if you intentionally want the complete all-140 replay. That run is computationally expensive.

### Historical compatibility semantics

The accepted ablation analysis master data use:
- strongest-P support chosen with NumPy `argpartition` on absolute upper-triangle scores;
- deterministic cutoff membership for `Ta50_10_*` and all `VFR*` problems;
- NumPy quicksort cutoff ordering for other Taillard groups.

These details are part of the reproducibility contract because the historical P+R solution is checked exactly for every replication and family.

## weight-sensitivity analysis

The frozen panel is stored in `weight_sensitivity_selected_28.txt`. To run the entire frozen panel:

```bash
python run_weight_sensitivity_frozen_panel.py
```

For one problem/replication:

```bash
cd core
python weight_sensitivity_weight_sensitivity_runner.py --problem Ta20_5_1 --rep 1 --outdir ../results_weight_sensitivity
```

The six P/R settings are: 0/1, 0.25/0.75, 0.50/0.50, 0.65/0.35, 0.75/0.25 and 1/0.

## OFAT-robustness analysis

The portable OFAT-robustness analysis implementation is `core/ofat_robustness_ofat_runner_PORTABLE.py`. It is algorithmically equivalent to the exact runner used in the completed experiments but replaces working-container absolute paths with package-relative paths.

One replay:

```bash
cd core
PFSP_ofat_robustness_OUTDIR=../results_ofat_robustness python ofat_robustness_ofat_runner_PORTABLE.py Ta20_5_1:1
```

Full frozen panel:

```bash
cd core
PFSP_ofat_robustness_OUTDIR=../results_ofat_robustness python ofat_robustness_ofat_runner_PORTABLE.py
```

`archival_exact/` preserves the exact working scripts as used during the experiment. They contain the original container path assumptions and are retained for provenance, not convenience.

## Inputs

`core/data/` contains benchmark processing-time data. `core/instance_manifest.csv`, `core/seed_manifest.csv`, and `core/historical_reference.csv` are the machine-readable manifests used by the runners. Duplicate copies are also kept under `manifests/` for easier inspection.

## Important publication note

Elapsed times emitted by these scripts during local reconstruction are QA/engineering measurements only. They are not the publication-grade analysis phase-2 runtime evidence and should not be cited in the manuscript.
