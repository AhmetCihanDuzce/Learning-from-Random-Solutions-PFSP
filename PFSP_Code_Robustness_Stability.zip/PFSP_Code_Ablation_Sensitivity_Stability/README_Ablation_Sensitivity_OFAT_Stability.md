# PFSP Applied Sciences revision - archived code package (ablation, weight-sensitivity, OFAT-robustness, and structural-stability analyses)

Scope: reproducibility code frozen through structural-stability analysis. The original ablation, weight-sensitivity, and OFAT-robustness analyses package is retained, with structural-stability analysis scripts added under `structural_stability/`.

Status:
- ablation analysis P/R ablation: GREEN
- weight-sensitivity analysis P/R weight sensitivity: GREEN
- OFAT-robustness analysis OFAT robustness: GREEN
- structural-stability analysis five-pool structural/output stability: GREEN

This is an archived archive. The final public code release will be regenerated after runtime and analyses 7-9 so that code, tables, and manuscript text match one final evidence set.
