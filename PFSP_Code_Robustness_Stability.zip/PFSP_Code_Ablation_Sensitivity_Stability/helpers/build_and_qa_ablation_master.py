from __future__ import annotations
import os, sys, json, hashlib
from pathlib import Path
import pandas as pd, numpy as np

ROOT=Path('/mnt/data/pfsp_handoff/PFSP_AppliedSciences_Revision_Handoff_2026-09-10/03_reproducibility_core')
sys.path.insert(0,str(ROOT))
import run_pfsp_single as core

OUT=Path('/mnt/data/PFSP_ablation_Ablation_MASTER')
OUT.mkdir(parents=True,exist_ok=True)

group_dirs=[
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta20x5'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta20x10'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta20x20'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta50x5'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta50x10'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta50x20'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta100x5'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta100x10'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta100x20'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta200x10_full'),
 Path('/mnt/data/PFSP_ablation_HISTCOMPAT_TAILLARD_GROUPS/Ta200x20_full'),
 Path('/mnt/data/PFSP_ablation_Ablation_HISTCOMPAT_FULL'),
]

files=['ablation_ablation_raw.csv','ablation_pool_audit.csv','ablation_pr_regression_audit.csv']
frames={f:[] for f in files}
prov=[]
for d in group_dirs:
    for f in files:
        p=d/f
        if not p.exists():
            raise FileNotFoundError(p)
        x=pd.read_csv(p)
        x['_SourceDir']=d.name
        frames[f].append(x)
    pa=pd.read_csv(d/'ablation_pool_audit.csv')
    for _,r in pa.iterrows():
        prov.append(dict(ProblemID=r.ProblemID,Replication=int(r.Replication),SourceDir=d.name,TieMode=r.TieMode))

raw=pd.concat(frames['ablation_ablation_raw.csv'],ignore_index=True)
pool=pd.concat(frames['ablation_pool_audit.csv'],ignore_index=True)
aud=pd.concat(frames['ablation_pr_regression_audit.csv'],ignore_index=True)

# VFR HISTCOMPAT_FULL must contain VFR only in final master.
# Enforce unique keys rather than silently deduplicating.
raw_key=['ProblemID','Replication','Mining','Mode','Family']
pool_key=['ProblemID','Replication']
aud_key=['ProblemID','Replication','Mining','Family']
assert raw.duplicated(raw_key).sum()==0, f'raw duplicates {raw.duplicated(raw_key).sum()}'
assert pool.duplicated(pool_key).sum()==0, f'pool duplicates {pool.duplicated(pool_key).sum()}'
assert aud.duplicated(aud_key).sum()==0, f'audit duplicates {aud.duplicated(aud_key).sum()}'

# Expected protocol universe.
man=pd.read_csv(ROOT/'instance_manifest.csv')
seed=pd.read_csv(ROOT/'seed_manifest.csv')
hist=pd.read_csv(ROOT/'historical_reference.csv')
assert len(man)==140 and man.ProblemID.nunique()==140
assert len(seed)==700 and seed[['ProblemID','Replication']].drop_duplicates().shape[0]==700
assert len(hist)==7000 and hist[['ProblemID','Replication','Mining','Family']].drop_duplicates().shape[0]==7000

assert len(pool)==700, len(pool)
assert pool.ProblemID.nunique()==140
assert set(pool.ProblemID)==set(man.ProblemID)
assert (pool.groupby('ProblemID').size()==5).all()
assert len(raw)==21000, len(raw)
assert len(aud)==7000, len(aud)
assert set(raw.Mode)=={'P-only','R-only','P+R'}
assert set(raw.Mining)=={'Elite-only','Contrast'}
assert set(raw.Family)==set(core.FAMILIES)
assert (raw.groupby(['ProblemID','Replication']).size()==30).all()
assert (aud.groupby(['ProblemID','Replication']).size()==10).all()

# Protocol weights.
wm={'P-only':(1.0,0.0),'R-only':(0.0,1.0),'P+R':(0.65,0.35)}
for mode,(wp,wr) in wm.items():
    q=raw[raw.Mode==mode]
    assert np.allclose(q.PWeight.astype(float),wp)
    assert np.allclose(q.RWeight.astype(float),wr)

# Manifest and seed exactness.
pool2=pool.merge(man[['ProblemID','Group','n','m','PoolSize']],on='ProblemID',suffixes=('','_man'),validate='many_to_one')
for c in ['Group','n','m','PoolSize']:
    assert (pool2[c].astype(str)==pool2[c+'_man'].astype(str)).all(), f'manifest mismatch {c}'
pool3=pool.merge(seed[['ProblemID','Replication','Seed','PoolSize']],on=['ProblemID','Replication'],suffixes=('','_seed'),validate='one_to_one')
assert (pool3.Seed.astype(int)==pool3.Seed_seed.astype(int)).all()
assert (pool3.PoolSize.astype(int)==pool3.PoolSize_seed.astype(int)).all()
assert (pool.HistoricalPRAuditPass.astype(bool)).all()
assert (pool.HistoricalPRMatched.astype(int)==10).all()
assert (pool.HistoricalPRChecked.astype(int)==10).all()
assert (aud.Pass.astype(bool)).all()
assert (aud.Got.astype(int)==aud.Expected.astype(int)).all()

# Audit must equal historical reference exactly.
ah=aud.merge(hist[['ProblemID','Replication','Seed','Mining','Family','RawCmax']],on=['ProblemID','Replication','Mining','Family'],suffixes=('','_hist'),validate='one_to_one')
assert (ah.Seed.astype(int)==ah.Seed_hist.astype(int)).all()
assert (ah.Got.astype(int)==ah.RawCmax.astype(int)).all()

# P+R raw must equal historical reference exactly.
pr=raw[raw.Mode=='P+R'].copy()
ph=pr.merge(hist[['ProblemID','Replication','Seed','Mining','Family','RawCmax']],on=['ProblemID','Replication','Mining','Family'],suffixes=('','_hist'),validate='one_to_one')
assert len(ph)==7000
assert (ph.Seed.astype(int)==ph.Seed_hist.astype(int)).all()
assert (ph.Cmax.astype(int)==ph.RawCmax.astype(int)).all()

# Independent sequence/permutation/Cmax validation.
def cmax_independent(seq0,p):
    m=p.shape[1]
    c=[0]*m
    for jb in seq0:
        left=0
        for j in range(m):
            up=c[j]
            v=(up if up>left else left)+int(p[jb,j])
            c[j]=v; left=v
    return c[-1]

inst_cache={}
invalid_perm=0; cmax_mismatch=0
for pid,g in raw.groupby('ProblemID',sort=False):
    row=core.load_manifest_row(ROOT,pid)
    p,_=core.load_instance(ROOT,row)
    n=p.shape[0]
    for rr in g.itertuples(index=False):
        seq=[int(x)-1 for x in str(rr.Sequence).split()]
        if len(seq)!=n or len(set(seq))!=n or min(seq)!=0 or max(seq)!=n-1:
            invalid_perm+=1; continue
        cc=cmax_independent(seq,p)
        if cc!=int(rr.Cmax): cmax_mismatch+=1
assert invalid_perm==0, invalid_perm
assert cmax_mismatch==0, cmax_mismatch

# Save authoritative files without source helper column.
raw_out=raw.drop(columns=['_SourceDir'])
pool_out=pool.drop(columns=['_SourceDir'])
aud_out=aud.drop(columns=['_SourceDir'])
raw_out.to_csv(OUT/'ablation_ablation_raw_MASTER.csv',index=False)
pool_out.to_csv(OUT/'ablation_pool_audit_MASTER.csv',index=False)
aud_out.to_csv(OUT/'ablation_pr_regression_audit_MASTER.csv',index=False)
pd.DataFrame(prov).sort_values(['ProblemID','Replication']).to_csv(OUT/'ablation_source_provenance.csv',index=False)

# QA report and hashes.
report={
 'problems':int(pool.ProblemID.nunique()),
 'replications':int(len(pool)),
 'raw_rows':int(len(raw)),
 'raw_unique_keys':int(raw[raw_key].drop_duplicates().shape[0]),
 'P_only_rows':int((raw.Mode=='P-only').sum()),
 'R_only_rows':int((raw.Mode=='R-only').sum()),
 'P_plus_R_rows':int((raw.Mode=='P+R').sum()),
 'regression_cells':int(len(aud)),
 'regression_pass':int(aud.Pass.astype(bool).sum()),
 'regression_mismatch':int((~aud.Pass.astype(bool)).sum()),
 'invalid_permutations':int(invalid_perm),
 'independent_cmax_mismatches':int(cmax_mismatch),
 'seed_mismatches':0,
 'pool_size_mismatches':0,
 'duplicate_raw_keys':0,
 'duplicate_pool_keys':0,
 'duplicate_audit_keys':0,
 'qa_status':'GREEN'
}
with open(OUT/'ablation_MASTER_QA.json','w',encoding='utf-8') as f: json.dump(report,f,indent=2)

hashes={}
for p in sorted(OUT.iterdir()):
    if p.is_file(): hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
with open(OUT/'SHA256SUMS.txt','w',encoding='utf-8') as f:
    for name,h in hashes.items(): f.write(f'{h}  {name}\n')
print(json.dumps(report,indent=2))
print('OUTPUT',OUT)
