#!/usr/bin/env python3
from pathlib import Path
import csv, json, sys, hashlib, collections
import numpy as np
ROOT=Path('/mnt/data/pfsp_handoff/PFSP_AppliedSciences_Revision_Handoff_2026-09-10/03_reproducibility_core')
sys.path.insert(0,str(ROOT))
import run_pfsp_single as core
OUT=Path('/mnt/data/PFSP_ofat_robustness_OFAT_Robustness')
S3=Path('/mnt/data/PFSP_ablation_Ablation_MASTER/ablation_ablation_raw_MASTER.csv')
RAW=OUT/'ofat_robustness_ofat_raw.csv'; POOL=OUT/'ofat_robustness_pool_audit.csv'; AUD=OUT/'ofat_robustness_baseline_regression_audit.csv'
SELECTED=[
'Ta20_5_1','Ta20_5_10','Ta20_10_1','Ta20_10_10','Ta20_20_1','Ta20_20_10','Ta50_5_1','Ta50_5_10','Ta50_10_1','Ta50_10_10','Ta50_20_1','Ta50_20_10',
'Ta100_5_1','Ta100_5_10','Ta100_10_1','Ta100_10_10','Ta100_20_1','Ta100_20_10','VFR100_20_1','VFR100_20_10','VFR100_40_1','VFR100_40_10','VFR100_60_1','VFR100_60_10',
'Ta200_10_1','Ta200_10_10','Ta200_20_1','Ta200_20_10']
CFG={
'Baseline':('Baseline','final',.05,.10,3,4,4),
'PRules_2n':('TopP','2n',.05,.10,2,4,4),'PRules_4n':('TopP','4n',.05,.10,4,4,4),
'Regions_2':('Regions','2',.05,.10,3,2,4),'Regions_8':('Regions','8',.05,.10,3,8,4),
'q_2':('q','2',.05,.10,3,4,2),'q_6':('q','6',.05,.10,3,4,6),
'Elite_025':('EliteFrac','0.025',.025,.10,3,4,4),'Elite_10':('EliteFrac','0.10',.10,.10,3,4,4),
'Poor_05':('PoorFrac','0.05',.05,.05,3,4,4),'Poor_20':('PoorFrac','0.20',.05,.20,3,4,4)}
FAMS=['NEH','NEH-TBKK2','KK2-style-NEH','FRB4-p1','INEH-inspired']; MIN=['Elite-only','Contrast']
def rows(p):
 with open(p,newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
raw=rows(RAW); pool=rows(POOL); aud=rows(AUD)
qa={}
qa['counts']={'raw':len(raw),'pool':len(pool),'audit':len(aud),'expected_raw':15400,'expected_pool':140,'expected_audit':1400}
qa['count_pass']=len(raw)==15400 and len(pool)==140 and len(aud)==1400
# duplicates and coverage
rk=[(r['ProblemID'],int(r['Replication']),r['Config'],r['Mining'],r['Family']) for r in raw]
pk=[(r['ProblemID'],int(r['Replication'])) for r in pool]
ak=[(r['ProblemID'],int(r['Replication']),r['Mining'],r['Family']) for r in aud]
qa['duplicate_counts']={'raw':len(rk)-len(set(rk)),'pool':len(pk)-len(set(pk)),'audit':len(ak)-len(set(ak))}
exp_pk={(p,r) for p in SELECTED for r in range(1,6)}
qa['rep_coverage']={'missing':sorted(map(str,exp_pk-set(pk))),'unexpected':sorted(map(str,set(pk)-exp_pk))}
qa['problem_count']=len({r['ProblemID'] for r in pool})
# per rep and config counts
repraw=collections.Counter((r['ProblemID'],int(r['Replication'])) for r in raw)
cfgcnt=collections.Counter(r['Config'] for r in raw)
qa['bad_raw_rows_per_rep']=[str(k)+':'+str(v) for k,v in repraw.items() if v!=110]
qa['config_counts']=dict(cfgcnt)
qa['bad_config_counts']={k:v for k,v in cfgcnt.items() if v!=1400}
# metadata
badmeta=[]
for r in raw:
 if r['Config'] not in CFG: badmeta.append((r['ProblemID'],r['Config'],'unknown')); continue
 factor,level,ef,pf,pmult,regions,q=CFG[r['Config']]; n=int(r['n'])
 vals=(r['Factor'],r['Level'],float(r['EliteFrac']),float(r['PoorFrac']),int(r['TopP']),int(r['Regions']),int(r['q']),float(r['PWeight']),float(r['RWeight']))
 exp=(factor,level,ef,pf,pmult*n,regions,q,.65,.35)
 if vals!=exp: badmeta.append((r['ProblemID'],r['Replication'],r['Config'],vals,exp))
qa['metadata_mismatches']=len(badmeta); qa['metadata_examples']=list(map(str,badmeta[:10]))
# audit all pass + got expected
bad_aud=[r for r in aud if str(r['Pass']).lower()!='true' or int(r['Got'])!=int(r['Expected'])]
qa['baseline_regression']={'pass':len(aud)-len(bad_aud),'checked':len(aud),'mismatches':len(bad_aud)}
# seeds and pools against manifest
bad_seed=[]
for r in pool:
 sr=core.load_seed_rows(ROOT,r['ProblemID'])[int(r['Replication'])-1]
 if int(r['Seed'])!=int(sr['Seed']) or int(r['PoolSize'])!=int(sr['PoolSize']):bad_seed.append(r['ProblemID']+':'+r['Replication'])
qa['seed_pool_mismatches']=bad_seed
# ablation baseline exact cmax+sequence match
s3={}
for r in rows(S3):
 if r['ProblemID'] in set(SELECTED) and r['Mode']=='P+R':
  s3[(r['ProblemID'],int(r['Replication']),r['Mining'],r['Family'])]=(r['Cmax'],r['Sequence'])
base=[r for r in raw if r['Config']=='Baseline']
bm=[]
for r in base:
 k=(r['ProblemID'],int(r['Replication']),r['Mining'],r['Family']); a=(r['Cmax'],r['Sequence']); b=s3.get(k)
 if a!=b: bm.append((k,a[0],None if b is None else b[0],a[1]==(None if b is None else b[1])))
qa['ablation_baseline_crosscheck']={'checked':len(base),'matches':len(base)-len(bm),'mismatches':len(bm),'examples':list(map(str,bm[:10]))}
# Poor fraction changes should not affect Elite-only
lookup={(r['ProblemID'],int(r['Replication']),r['Config'],r['Mining'],r['Family']):(r['Cmax'],r['Sequence']) for r in raw}
pm=[]; checked=0
for pid,rep in exp_pk:
 for fam in FAMS:
  b=lookup[(pid,rep,'Baseline','Elite-only',fam)]
  for cfg in ['Poor_05','Poor_20']:
   checked+=1; a=lookup[(pid,rep,cfg,'Elite-only',fam)]
   if a!=b:pm.append((pid,rep,cfg,fam))
qa['poor_fraction_elite_invariance']={'checked':checked,'matches':checked-len(pm),'mismatches':len(pm),'examples':list(map(str,pm[:10]))}
# independent permutation + cmax check, using cached instance matrices
inst={}; badperm=[]; badc=[]
for i,r in enumerate(raw):
 pid=r['ProblemID']; n=int(r['n'])
 if pid not in inst:
  row=core.load_manifest_row(ROOT,pid); p,_=core.load_instance(ROOT,row); inst[pid]=p
 p=inst[pid]; seq=np.fromstring(r['Sequence'],sep=' ',dtype=np.int64)-1
 if len(seq)!=n or not np.array_equal(np.sort(seq),np.arange(n,dtype=np.int64)):
  badperm.append((pid,r['Replication'],r['Config'],r['Mining'],r['Family'])); continue
 c=int(core.cmax_of_sequence(seq,p)) if hasattr(core,'cmax_of_sequence') else None
 if c is None:
  comp=np.zeros(p.shape[1],dtype=np.int64)
  for jb in seq:
   for j in range(p.shape[1]):comp[j]=max(comp[j],comp[j-1] if j else 0)+int(p[jb,j])
  c=int(comp[-1])
 if c!=int(r['Cmax']):badc.append((pid,r['Replication'],r['Config'],r['Mining'],r['Family'],r['Cmax'],c))
qa['independent_solution_check']={'checked':len(raw),'invalid_permutations':len(badperm),'cmax_mismatches':len(badc),'perm_examples':list(map(str,badperm[:10])),'cmax_examples':list(map(str,badc[:10]))}
qa['hashes']={RAW.name:sha(RAW),POOL.name:sha(POOL),AUD.name:sha(AUD)}
qa['master_green']=all([
 qa['count_pass'], all(v==0 for v in qa['duplicate_counts'].values()), not qa['rep_coverage']['missing'], not qa['rep_coverage']['unexpected'],
 qa['problem_count']==28, not qa['bad_raw_rows_per_rep'], not qa['bad_config_counts'], qa['metadata_mismatches']==0,
 qa['baseline_regression']['mismatches']==0, not qa['seed_pool_mismatches'], qa['ablation_baseline_crosscheck']['mismatches']==0,
 qa['poor_fraction_elite_invariance']['mismatches']==0, qa['independent_solution_check']['invalid_permutations']==0, qa['independent_solution_check']['cmax_mismatches']==0])
with open(OUT/'ofat_robustness_MASTER_QA.json','w',encoding='utf-8') as f:json.dump(qa,f,indent=2,ensure_ascii=False)
print(json.dumps(qa,indent=2,ensure_ascii=False))
