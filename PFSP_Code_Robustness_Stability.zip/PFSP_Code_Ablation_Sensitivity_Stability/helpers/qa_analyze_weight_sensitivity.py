from pathlib import Path
import csv, json, math, statistics, hashlib
import numpy as np
import sys
ROOT=Path('/mnt/data/pfsp_handoff/PFSP_AppliedSciences_Revision_Handoff_2026-09-10/03_reproducibility_core')
sys.path.insert(0,str(ROOT))
import run_pfsp_single as core
S4=Path('/mnt/data/PFSP_weight_sensitivity_Weight_Sensitivity')
S3=Path('/mnt/data/PFSP_ablation_Ablation_MASTER')
rawp=S4/'ablation_ablation_raw.csv'; poolp=S4/'ablation_pool_audit.csv'; audp=S4/'ablation_pr_regression_audit.csv'
raw3p=S3/'ablation_ablation_raw_MASTER.csv'; pool3p=S3/'ablation_pool_audit_MASTER.csv'

selected=[
'Ta20_5_1','Ta20_5_10','Ta20_10_1','Ta20_10_10','Ta20_20_1','Ta20_20_10',
'Ta50_5_1','Ta50_5_10','Ta50_10_1','Ta50_10_10','Ta50_20_1','Ta50_20_10',
'Ta100_5_1','Ta100_5_10','Ta100_10_1','Ta100_10_10','Ta100_20_1','Ta100_20_10',
'VFR100_20_1','VFR100_20_10','VFR100_40_1','VFR100_40_10','VFR100_60_1','VFR100_60_10',
'Ta200_10_1','Ta200_10_10','Ta200_20_1','Ta200_20_10']
weights=[('R-only',0.0,1.0),('R-dominant',0.25,0.75),('Balanced',0.5,0.5),('P+R-baseline',0.65,0.35),('P-dominant',0.75,0.25),('P-only',1.0,0.0)]
minings=['Elite-only','Contrast']
families=['NEH','NEH-TBKK2','KK2-style-NEH','FRB4-p1','INEH-inspired']

def read(path):
    with open(path,newline='',encoding='utf-8') as f: return list(csv.DictReader(f))
def write(path, rows, fields):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
def sha(path):
    h=hashlib.sha256();
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def cmax_ind(seq1,p):
    comp=[0]*p.shape[1]
    for one in seq1:
        jb=one-1
        for j in range(p.shape[1]):
            left=comp[j-1] if j else 0
            up=comp[j]
            comp[j]=max(left,up)+int(p[jb,j])
    return comp[-1]

raw=read(rawp); pools=read(poolp); aud=read(audp); raw3=read(raw3p); pools3=read(pool3p)
qa={}
qa['raw_rows']=len(raw); qa['expected_raw_rows']=28*5*2*6*5
qa['pool_rows']=len(pools); qa['expected_pool_rows']=28*5
qa['audit_rows']=len(aud); qa['expected_audit_rows']=28*5*2*5
qa['problem_count']=len(set(r['ProblemID'] for r in raw)); qa['expected_problem_count']=28
qa['selected_problem_set_exact']=set(r['ProblemID'] for r in raw)==set(selected)

# raw uniqueness and grid
key=lambda r:(r['ProblemID'],int(r['Replication']),r['Mining'],r['Mode'],r['Family'])
keys=[key(r) for r in raw]
qa['raw_duplicate_keys']=len(keys)-len(set(keys))
expected_keys={(pid,rep,mining,mode,fam) for pid in selected for rep in range(1,6) for mining in minings for mode,_,_ in weights for fam in families}
qa['raw_missing_keys']=len(expected_keys-set(keys)); qa['raw_unexpected_keys']=len(set(keys)-expected_keys)
mode_weight={(m,float(wp),float(wr)) for m,wp,wr in weights}
qa['mode_weight_mismatches']=sum((r['Mode'],float(r['PWeight']),float(r['RWeight'])) not in mode_weight for r in raw)

# seed/pool compare ablation selected
p3={(r['ProblemID'],int(r['Replication'])):r for r in pools3 if r['ProblemID'] in set(selected)}
qa['pool_duplicate_keys']=len(pools)-len({(r['ProblemID'],int(r['Replication'])) for r in pools})
seed_m=poolsize_m=poolstats_m=gate_bad=0
for r in pools:
    k=(r['ProblemID'],int(r['Replication'])); q=p3.get(k)
    if q is None: poolstats_m+=1; continue
    if int(r['Seed'])!=int(q['Seed']): seed_m+=1
    if int(r['PoolSize'])!=int(q['PoolSize']): poolsize_m+=1
    # integer stats exact; floats close at machine precision
    for fld in ['PoolBest','PoolWorst','EliteN','PoorN']:
        if int(float(r[fld]))!=int(float(q[fld])): poolstats_m+=1
    for fld in ['PoolMean','PoolSD']:
        if not math.isclose(float(r[fld]),float(q[fld]),rel_tol=0,abs_tol=1e-10): poolstats_m+=1
    if str(r['HistoricalPRAuditPass']).lower() not in ('true','1'): gate_bad+=1
qa['seed_mismatches_vs_ablation']=seed_m; qa['poolsize_mismatches_vs_ablation']=poolsize_m; qa['poolstat_field_mismatches_vs_ablation']=poolstats_m; qa['pool_gate_failures']=gate_bad

# audit gate
qa['historical_pr_pass_count']=sum(str(r['Pass']).lower() in ('true','1') for r in aud)
qa['historical_pr_fail_count']=len(aud)-qa['historical_pr_pass_count']
qa['historical_pr_got_expected_mismatches']=sum(int(r['Got'])!=int(r['Expected']) for r in aud)

# common arm exact compare ablation (P-only, R-only, baseline P+R)
map3={(r['ProblemID'],int(r['Replication']),r['Mining'],r['Mode'],r['Family']):r for r in raw3 if r['ProblemID'] in set(selected)}
common={'P-only':'P-only','R-only':'R-only','P+R-baseline':'P+R'}
cm_c=cm_seq=cm_missing=cm_n=0
for r in raw:
    if r['Mode'] not in common: continue
    cm_n+=1
    k=(r['ProblemID'],int(r['Replication']),r['Mining'],common[r['Mode']],r['Family'])
    q=map3.get(k)
    if q is None: cm_missing+=1; continue
    if int(r['Cmax'])!=int(q['Cmax']): cm_c+=1
    if r['Sequence'].strip()!=q['Sequence'].strip(): cm_seq+=1
qa['ablation_common_rows_checked']=cm_n; qa['ablation_common_missing']=cm_missing; qa['ablation_common_cmax_mismatches']=cm_c; qa['ablation_common_sequence_mismatches']=cm_seq

# sequence permutation and independent Cmax
inst={}
invalid=0;cmm=0;bad_n=0
for idx,r in enumerate(raw):
    pid=r['ProblemID']
    if pid not in inst:
        row=core.load_manifest_row(ROOT,pid); p,_=core.load_instance(ROOT,row); inst[pid]=p
    p=inst[pid]; n=p.shape[0]
    seq=[int(x) for x in r['Sequence'].split()]
    if len(seq)!=n: bad_n+=1; invalid+=1; continue
    if set(seq)!=set(range(1,n+1)): invalid+=1; continue
    got=cmax_ind(seq,p)
    if got!=int(r['Cmax']): cmm+=1
qa['invalid_permutations']=invalid; qa['bad_sequence_lengths']=bad_n; qa['independent_cmax_mismatches']=cmm

qa['all_green']=all([
    qa['raw_rows']==qa['expected_raw_rows'], qa['pool_rows']==qa['expected_pool_rows'],qa['audit_rows']==qa['expected_audit_rows'],
    qa['problem_count']==28,qa['selected_problem_set_exact'],qa['raw_duplicate_keys']==0,qa['raw_missing_keys']==0,qa['raw_unexpected_keys']==0,qa['mode_weight_mismatches']==0,
    qa['pool_duplicate_keys']==0,qa['seed_mismatches_vs_ablation']==0,qa['poolsize_mismatches_vs_ablation']==0,qa['poolstat_field_mismatches_vs_ablation']==0,qa['pool_gate_failures']==0,
    qa['historical_pr_fail_count']==0,qa['historical_pr_got_expected_mismatches']==0,
    qa['ablation_common_rows_checked']==28*5*2*3*5,qa['ablation_common_missing']==0,qa['ablation_common_cmax_mismatches']==0,qa['ablation_common_sequence_mismatches']==0,
    qa['invalid_permutations']==0,qa['independent_cmax_mismatches']==0
])
qa['sha256']={'weight_sensitivity_raw':sha(rawp),'weight_sensitivity_pool':sha(poolp),'weight_sensitivity_audit':sha(audp)}
with open(S4/'weight_sensitivity_MASTER_QA.json','w',encoding='utf-8') as f: json.dump(qa,f,indent=2,ensure_ascii=False)

# Mean-of-five table by cell and weight
# collect values by pid,mining,family,mode
vals={}
for r in raw:
    k=(r['ProblemID'],r['Mining'],r['Family'],r['Mode'])
    vals.setdefault(k,[]).append(int(r['Cmax']))
meanrows=[]
for pid in selected:
  for mining in minings:
    for fam in families:
      base=np.mean(vals[(pid,mining,fam,'P+R-baseline')])
      for mode,wp,wr in weights:
        x=vals[(pid,mining,fam,mode)]
        assert len(x)==5
        mu=float(np.mean(x)); med=float(np.median(x)); best=min(x); sd=float(np.std(x,ddof=1))
        # Positive means this weight is better than 0.65/0.35 baseline.
        rel=100.0*(base-mu)/base
        meanrows.append(dict(ProblemID=pid,Mining=mining,Family=fam,Mode=mode,PWeight=wp,RWeight=wr,MeanCmax=mu,MedianCmax=med,SD=sd,BestCmax=best,DeltaVs065Pct=rel))
write(S4/'weight_sensitivity_mean_of_five_by_cell.csv',meanrows,list(meanrows[0].keys()))

# summary per weight overall + by mining + by family
summary=[]
for scope_name, filt in [('Overall',lambda r:True)]+[(f'Mining:{m}',lambda r,m=m:r['Mining']==m) for m in minings]+[(f'Family:{f}',lambda r,f=f:r['Family']==f) for f in families]:
  for mode,wp,wr in weights:
    rows=[r for r in meanrows if r['Mode']==mode and filt(r)]
    deltas=[r['DeltaVs065Pct'] for r in rows]
    w=sum(d>1e-12 for d in deltas); t=sum(abs(d)<=1e-12 for d in deltas); l=sum(d<-1e-12 for d in deltas)
    summary.append(dict(Scope=scope_name,Mode=mode,PWeight=wp,RWeight=wr,Cells=len(rows),MeanDeltaVs065Pct=float(np.mean(deltas)),MedianDeltaVs065Pct=float(np.median(deltas)),SDDeltaVs065Pct=float(np.std(deltas,ddof=1)) if len(deltas)>1 else 0.0,W=w,T=t,L=l))
write(S4/'weight_sensitivity_weight_summary.csv',summary,list(summary[0].keys()))

# rank / best frequencies on 280 cell comparisons
rankrows=[]
for pid in selected:
 for mining in minings:
  for fam in families:
   rr=[r for r in meanrows if r['ProblemID']==pid and r['Mining']==mining and r['Family']==fam]
   mus=np.array([r['MeanCmax'] for r in rr])
   order=np.argsort(mus,kind='stable')
   ranks=np.empty(len(rr),float)
   # average ranks for ties
   s=0
   while s<len(order):
     e=s+1
     while e<len(order) and mus[order[e]]==mus[order[s]]: e+=1
     av=(s+1+e)/2.0
     for z in order[s:e]: ranks[z]=av
     s=e
   mn=mus.min()
   for j,r in enumerate(rr):
    rankrows.append(dict(ProblemID=pid,Mining=mining,Family=fam,Mode=r['Mode'],PWeight=r['PWeight'],RWeight=r['RWeight'],MeanCmax=r['MeanCmax'],Rank=float(ranks[j]),TiedBest=(r['MeanCmax']==mn)))
write(S4/'weight_sensitivity_weight_ranks.csv',rankrows,list(rankrows[0].keys()))
rank_summary=[]
for mode,wp,wr in weights:
 rr=[r for r in rankrows if r['Mode']==mode]
 rank_summary.append(dict(Mode=mode,PWeight=wp,RWeight=wr,Cells=len(rr),MeanRank=float(np.mean([r['Rank'] for r in rr])),MedianRank=float(np.median([r['Rank'] for r in rr])),TiedBestCount=sum(r['TiedBest'] for r in rr)))
write(S4/'weight_sensitivity_rank_summary.csv',rank_summary,list(rank_summary[0].keys()))

print(json.dumps(qa,indent=2,ensure_ascii=False))
print('\nOVERALL SUMMARY')
for r in summary[:6]: print(r)
print('\nRANK SUMMARY')
for r in rank_summary: print(r)
