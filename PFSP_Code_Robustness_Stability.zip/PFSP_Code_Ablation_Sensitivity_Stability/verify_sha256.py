#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent
manifest=root/'SHA256SUMS.txt'
bad=[]
for line in manifest.read_text().splitlines():
    if not line.strip(): continue
    h,rel=line.split('  ',1)
    p=root/rel
    if not p.exists(): bad.append((rel,'MISSING')); continue
    got=hashlib.sha256(p.read_bytes()).hexdigest()
    if got!=h: bad.append((rel,got))
if bad:
    print('SHA256_FAIL',bad[:10]); sys.exit(1)
print('SHA256_PASS')
