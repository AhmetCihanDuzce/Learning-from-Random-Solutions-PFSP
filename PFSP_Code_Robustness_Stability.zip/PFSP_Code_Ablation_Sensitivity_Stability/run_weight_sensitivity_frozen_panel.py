#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
core=root/'core'
out=root/'results_weight_sensitivity'
pids=[x.strip() for x in (root/'weight_sensitivity_selected_28.txt').read_text().splitlines() if x.strip()]
for pid in pids:
    cmd=[sys.executable,str(core/'weight_sensitivity_weight_sensitivity_runner.py'),'--problem',pid,'--outdir',str(out)]
    print(' '.join(cmd),flush=True)
    subprocess.run(cmd,cwd=core,check=True)
