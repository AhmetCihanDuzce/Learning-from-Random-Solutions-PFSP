#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys,csv,time
import numpy as np
ROOT=Path('/mnt/data/pfsp_handoff/PFSP_AppliedSciences_Revision_Handoff_2026-09-10/03_reproducibility_core')
sys.path.insert(0,str(ROOT)); sys.path.insert(0,'/mnt/data')
import run_pfsp_single as core
import weight_sensitivity_weight_sensitivity_runner as s4
import ofat_robustness_ofat_runner_opt as meta
OUT=meta.OUT; FAMILIES=core.FAMILIES; SELECTED=meta.SELECTED; CONFIGS=meta.CONFIGS

def append_csv(path,rows,fields):
    new=not path.exists()
    with path.open('a',newline='',encoding='utf-8') as f:
      w=csv.DictWriter(f,fieldnames=fields)
      if new:w.writeheader()
      w.writerows(rows)

def completed(path):
    if not path.exists():return set()
    return {(r['ProblemID'],int(r['Replication'])) for r in csv.DictReader(open(path,newline='',encoding='utf-8'))}

def stats_counts(seqs,n):
    # Compute exact integer counts for pairwise precedence and 8-bin position histograms.
    G=seqs.shape[0]
    P8,R8=s4.thread_group_stats(seqs,n,8,4)
    pc=np.rint(P8*G).astype(np.int64)
    rc=np.rint(R8*G).astype(np.int64)
    return pc,rc,G

def combine(blocks):
    # Reconstruct cumulative-group statistics with the exact floating-point
    # operation order used by thread_group_stats. This matters because the
    # historical top-P argpartition and later information-score tie breaking
    # can be sensitive to 1-ULP differences.
    pc=sum((b[0] for b in blocks),np.zeros_like(blocks[0][0],dtype=np.int64))
    rc8=sum((b[1] for b in blocks),np.zeros_like(blocks[0][1],dtype=np.int64))
    G=sum(b[2] for b in blocks)
    n=pc.shape[0]
    P=np.zeros((n,n),dtype=np.float64)
    for i in range(n-1):
        for j in range(i+1,n):
            v=int(pc[i,j])/G
            P[i,j]=v
            P[j,i]=1.0-v
    # Original R computation is bincount/G at the requested granularity,
    # not a sum of already-divided finer-bin probabilities. Aggregate integer
    # counts first, then divide once.
    R8=rc8.astype(np.float64)/G
    rc4=rc8.reshape(n,4,2).sum(axis=2)
    rc2=rc8.reshape(n,2,4).sum(axis=2)
    R4=rc4.astype(np.float64)/G
    R2=rc2.astype(np.float64)/G
    return P,R2,R4,R8

def eval5(tpt,kk,p,P,R,q):
    wp,wr=.65,.35
    return [s4.construct_info_neh_w(tpt,p,P,R,0,wp,wr),s4.construct_info_neh_w(tpt,p,P,R,2,wp,wr),s4.construct_info_neh_w(kk,p,P,R,2,wp,wr),s4.construct_info_frb4_w(tpt,p,P,R,1,q,2,wp,wr),s4.construct_info_frb4_w(kk,p,P,R,1,q,2,wp,wr)]

def run_rep(pid,rep):
    row=core.load_manifest_row(ROOT,pid); p,_=core.load_instance(ROOT,row); n,m=p.shape
    sr=core.load_seed_rows(ROOT,pid)[rep-1]; seed=int(sr['Seed']); S=int(sr['PoolSize']); assert S==10000*n
    tie=s4.tie_mode_for(pid); t0=time.perf_counter()
    pool=s4.generate_pool_array_parallel(seed,S,n,100000,16); cs=s4.cmax_memmap_parallel(pool,p,250000,5)
    if tie=='numpy_quicksort': idx=np.argsort(cs,kind='quicksort')
    else: idx=np.lexsort((np.arange(cs.size,dtype=np.int64),cs))
    e25=round(.025*S); e50=round(.05*S); e100=round(.10*S); p50=round(.05*S); p100=round(.10*S); p200=round(.20*S)
    # Disjoint blocks. Total pairwise-stat rows = 30% of S rather than 52.5% under six cumulative groups.
    b_e1=stats_counts(np.asarray(pool[idx[:e25],:],dtype=np.uint16),n)
    b_e2=stats_counts(np.asarray(pool[idx[e25:e50],:],dtype=np.uint16),n)
    b_e3=stats_counts(np.asarray(pool[idx[e50:e100],:],dtype=np.uint16),n)
    b_p1=stats_counts(np.asarray(pool[idx[-p50:],:],dtype=np.uint16),n)
    b_p2=stats_counts(np.asarray(pool[idx[-p100:-p50],:],dtype=np.uint16),n)
    b_p3=stats_counts(np.asarray(pool[idx[-p200:-p100],:],dtype=np.uint16),n)
    ep025,er025_2,er025_4,er025_8=combine([b_e1]); ep05,er05_2,er05_4,er05_8=combine([b_e1,b_e2]); ep10,er10_2,er10_4,er10_8=combine([b_e1,b_e2,b_e3])
    bp05,br05_2,br05_4,br05_8=combine([b_p1]); bp10,br10_2,br10_4,br10_8=combine([b_p1,b_p2]); bp20,br20_2,br20_4,br20_8=combine([b_p1,b_p2,b_p3])
    def filt(M,k):return s4.historical_filter_precedence(M,k)
    PEs={2:filt(ep05-.5,2*n),3:filt(ep05-.5,3*n),4:filt(ep05-.5,4*n)}; PCs={2:filt(ep05-bp10,2*n),3:filt(ep05-bp10,3*n),4:filt(ep05-bp10,4*n)}
    mined={
      'Baseline':(PEs[3],er05_4-.25,PCs[3],er05_4-br10_4,4),
      'PRules_2n':(PEs[2],er05_4-.25,PCs[2],er05_4-br10_4,4),'PRules_4n':(PEs[4],er05_4-.25,PCs[4],er05_4-br10_4,4),
      'Regions_2':(PEs[3],er05_2-.5,PCs[3],er05_2-br10_2,4),'Regions_8':(PEs[3],er05_8-.125,PCs[3],er05_8-br10_8,4),
      'q_2':(PEs[3],er05_4-.25,PCs[3],er05_4-br10_4,2),'q_6':(PEs[3],er05_4-.25,PCs[3],er05_4-br10_4,6),
      'Elite_025':(filt(ep025-.5,3*n),er025_4-.25,filt(ep025-bp10,3*n),er025_4-br10_4,4),
      'Elite_10':(filt(ep10-.5,3*n),er10_4-.25,filt(ep10-bp10,3*n),er10_4-br10_4,4),
      'Poor_05':(PEs[3],er05_4-.25,filt(ep05-bp05,3*n),er05_4-br05_4,4),'Poor_20':(PEs[3],er05_4-.25,filt(ep05-bp20,3*n),er05_4-br20_4,4)}
    cfgmeta={x[0]:x for x in CONFIGS};tpt=core.tpt_order(p);kk=core.kk2_style_order(p);expected=s4.historical_expected(ROOT,pid,rep)
    raw=[];audit=[]
    for cfg,*_ in CONFIGS:
      PE,RE,PC,RC,q=mined[cfg];_,factor,level,ef,pf,pmult,regions,qmeta=cfgmeta[cfg];assert q==qmeta
      for mining,P,R in [('Elite-only',PE,RE),('Contrast',PC,RC)]:
       for fam,(seq,c) in zip(FAMILIES,eval5(tpt,kk,p,P,R,q)):
        core.validate_solution(seq,c,p,n);raw.append(dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,Config=cfg,Factor=factor,Level=level,EliteFrac=ef,PoorFrac=pf,TopP=int(round(pmult*n)),Regions=regions,q=q,PWeight=.65,RWeight=.35,Mining=mining,Family=fam,Cmax=int(c),Sequence=' '.join(str(x+1) for x in seq)))
        if cfg=='Baseline':
          exp=expected[(mining,fam)];audit.append(dict(ProblemID=pid,Replication=rep,Seed=seed,Mining=mining,Family=fam,Got=int(c),Expected=exp,Pass=(int(c)==exp)))
    poolaudit=dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,PoolSize=S,PoolBest=int(cs.min()),PoolMean=float(cs.mean()),PoolSD=float(cs.std(ddof=1)),PoolWorst=int(cs.max()),EliteN=e50,PoorN=p100,TieMode=tie,ElapsedSec=time.perf_counter()-t0,HistoricalPRAuditPass=all(x['Pass'] for x in audit),HistoricalPRMatched=sum(x['Pass'] for x in audit),HistoricalPRChecked=len(audit))
    if not poolaudit['HistoricalPRAuditPass']:raise RuntimeError([x for x in audit if not x['Pass']][:5])
    return raw,audit,poolaudit

def main(argv):
 rawp=OUT/'ofat_robustness_ofat_raw.csv';audp=OUT/'ofat_robustness_baseline_regression_audit.csv';poolp=OUT/'ofat_robustness_pool_audit.csv';done=completed(poolp);tokens=argv or SELECTED
 for tok in tokens:
  if ':' in tok:pid,r=tok.rsplit(':',1);reps=[int(r)]
  else:pid=tok;reps=range(1,6)
  for rep in reps:
   if (pid,rep) in done:continue
   print('RUN',pid,'rep',rep,flush=True);t=time.time();raw,aud,pool=run_rep(pid,rep);append_csv(rawp,raw,list(raw[0].keys()));append_csv(audp,aud,list(aud[0].keys()));append_csv(poolp,[pool],list(pool.keys()));done.add((pid,rep));print('PASS',pid,'rep',rep,'wall',round(time.time()-t,2),flush=True)
if __name__=='__main__':main(sys.argv[1:])
