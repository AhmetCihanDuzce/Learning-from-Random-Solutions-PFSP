#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys,csv,time
import numpy as np
ROOT=Path('/mnt/data/pfsp_handoff/PFSP_AppliedSciences_Revision_Handoff_2026-09-10/03_reproducibility_core')
sys.path.insert(0,str(ROOT))
import run_pfsp_single as core
import weight_sensitivity_weight_sensitivity_runner as s4
OUT=Path('/mnt/data/PFSP_ofat_robustness_OFAT_Robustness'); OUT.mkdir(parents=True,exist_ok=True)
FAMILIES=core.FAMILIES
SELECTED=[
'Ta20_5_1','Ta20_5_10','Ta20_10_1','Ta20_10_10','Ta20_20_1','Ta20_20_10','Ta50_5_1','Ta50_5_10','Ta50_10_1','Ta50_10_10','Ta50_20_1','Ta50_20_10',
'Ta100_5_1','Ta100_5_10','Ta100_10_1','Ta100_10_10','Ta100_20_1','Ta100_20_10','VFR100_20_1','VFR100_20_10','VFR100_40_1','VFR100_40_10','VFR100_60_1','VFR100_60_10',
'Ta200_10_1','Ta200_10_10','Ta200_20_1','Ta200_20_10']
CONFIGS=[
 ('Baseline','Baseline','final',0.05,0.10,3.0,4,4),('PRules_2n','TopP','2n',0.05,0.10,2.0,4,4),('PRules_4n','TopP','4n',0.05,0.10,4.0,4,4),
 ('Regions_2','Regions','2',0.05,0.10,3.0,2,4),('Regions_8','Regions','8',0.05,0.10,3.0,8,4),('q_2','q','2',0.05,0.10,3.0,4,2),('q_6','q','6',0.05,0.10,3.0,4,6),
 ('Elite_025','EliteFrac','0.025',0.025,0.10,3.0,4,4),('Elite_10','EliteFrac','0.10',0.10,0.10,3.0,4,4),('Poor_05','PoorFrac','0.05',0.05,0.05,3.0,4,4),('Poor_20','PoorFrac','0.20',0.05,0.20,3.0,4,4)]

def append_csv(path,rows,fields):
    new=not path.exists()
    with path.open('a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields)
        if new:w.writeheader()
        w.writerows(rows)

def completed(path):
    if not path.exists():return set()
    return {(r['ProblemID'],int(r['Replication'])) for r in csv.DictReader(open(path,newline='',encoding='utf-8'))}

def rstats(seqs,n,regions):
    G=seqs.shape[0]
    pos=np.empty((G,n),dtype=np.uint16); rows=np.arange(G,dtype=np.int64)[:,None]
    pos[rows,seqs.astype(np.intp,copy=False)]=np.arange(n,dtype=np.uint16)
    R=np.zeros((n,regions),dtype=np.float64)
    for job in range(n):
        rg=np.minimum((pos[:,job].astype(np.int64)*regions)//n,regions-1)
        R[job,:]=np.bincount(rg,minlength=regions)/G
    return R

def eval5(tpt,kk,p,P,R,q):
    wp,wr=.65,.35
    return [s4.construct_info_neh_w(tpt,p,P,R,0,wp,wr),s4.construct_info_neh_w(tpt,p,P,R,2,wp,wr),s4.construct_info_neh_w(kk,p,P,R,2,wp,wr),s4.construct_info_frb4_w(tpt,p,P,R,1,q,2,wp,wr),s4.construct_info_frb4_w(kk,p,P,R,1,q,2,wp,wr)]

def run_rep(pid,rep):
    row=core.load_manifest_row(ROOT,pid); p,_=core.load_instance(ROOT,row); n,m=p.shape
    sr=core.load_seed_rows(ROOT,pid)[rep-1]; seed=int(sr['Seed']); S=int(sr['PoolSize']); assert S==10000*n
    tie=s4.tie_mode_for(pid); t0=time.perf_counter()
    pool=s4.generate_pool_array_parallel(seed,S,n,100000,16); cs=s4.cmax_memmap_parallel(pool,p,250000,5)
    # Sort exactly once; all stratum memberships are nested slices of the same historical ordering.
    if tie=='numpy_quicksort': idx=np.argsort(cs,kind='quicksort')
    elif tie=='deterministic': idx=np.lexsort((np.arange(cs.size,dtype=np.int64),cs))
    else: raise ValueError(tie)
    ens={.025:round(.025*S),.05:round(.05*S),.10:round(.10*S)}
    pns={.05:round(.05*S),.10:round(.10*S),.20:round(.20*S)}
    groups={
      'e025':np.asarray(pool[idx[:ens[.025]],:],dtype=np.uint16),'e05':np.asarray(pool[idx[:ens[.05]],:],dtype=np.uint16),'e10':np.asarray(pool[idx[:ens[.10]],:],dtype=np.uint16),
      'p05':np.asarray(pool[idx[-pns[.05]:],:],dtype=np.uint16),'p10':np.asarray(pool[idx[-pns[.10]:],:],dtype=np.uint16),'p20':np.asarray(pool[idx[-pns[.20]:],:],dtype=np.uint16)}
    stats={}
    for nm,seqs in groups.items(): stats[nm]=s4.thread_group_stats(seqs,n,4,4)
    # extra R granularities only for baseline strata
    er2=rstats(groups['e05'],n,2); pr2=rstats(groups['p10'],n,2)
    er8=rstats(groups['e05'],n,8); pr8=rstats(groups['p10'],n,8)
    ep025,er025=stats['e025']; ep05,er05=stats['e05']; ep10,er10=stats['e10']; bp05,br05=stats['p05']; bp10,br10=stats['p10']; bp20,br20=stats['p20']
    def filt(M,k): return s4.historical_filter_precedence(M,k)
    PEs={2:filt(ep05-.5,2*n),3:filt(ep05-.5,3*n),4:filt(ep05-.5,4*n)}
    PCs={2:filt(ep05-bp10,2*n),3:filt(ep05-bp10,3*n),4:filt(ep05-bp10,4*n)}
    # direct config -> mined structures
    mined={
      'Baseline':(PEs[3],er05-.25,PCs[3],er05-br10,4),
      'PRules_2n':(PEs[2],er05-.25,PCs[2],er05-br10,4),'PRules_4n':(PEs[4],er05-.25,PCs[4],er05-br10,4),
      'Regions_2':(PEs[3],er2-.5,PCs[3],er2-pr2,4),'Regions_8':(PEs[3],er8-.125,PCs[3],er8-pr8,4),
      'q_2':(PEs[3],er05-.25,PCs[3],er05-br10,2),'q_6':(PEs[3],er05-.25,PCs[3],er05-br10,6),
      'Elite_025':(filt(ep025-.5,3*n),er025-.25,filt(ep025-bp10,3*n),er025-br10,4),
      'Elite_10':(filt(ep10-.5,3*n),er10-.25,filt(ep10-bp10,3*n),er10-br10,4),
      # Elite-only columns are intentionally identical to baseline under Poor-only changes.
      'Poor_05':(PEs[3],er05-.25,filt(ep05-bp05,3*n),er05-br05,4),
      'Poor_20':(PEs[3],er05-.25,filt(ep05-bp20,3*n),er05-br20,4),
    }
    cfgmeta={x[0]:x for x in CONFIGS}; tpt=core.tpt_order(p); kk=core.kk2_style_order(p); expected=s4.historical_expected(ROOT,pid,rep)
    raw=[];audit=[]
    for cfg,*_ in CONFIGS:
      PE,RE,PC,RC,q=mined[cfg]; _,factor,level,ef,pf,pmult,regions,qmeta=cfgmeta[cfg]
      assert q==qmeta
      for mining,P,R in [('Elite-only',PE,RE),('Contrast',PC,RC)]:
        runs=eval5(tpt,kk,p,P,R,q)
        for fam,(seq,c) in zip(FAMILIES,runs):
          core.validate_solution(seq,c,p,n)
          raw.append(dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,Config=cfg,Factor=factor,Level=level,EliteFrac=ef,PoorFrac=pf,TopP=int(round(pmult*n)),Regions=regions,q=q,PWeight=.65,RWeight=.35,Mining=mining,Family=fam,Cmax=int(c),Sequence=' '.join(str(x+1) for x in seq)))
          if cfg=='Baseline':
            exp=expected[(mining,fam)];audit.append(dict(ProblemID=pid,Replication=rep,Seed=seed,Mining=mining,Family=fam,Got=int(c),Expected=exp,Pass=(int(c)==exp)))
    elapsed=time.perf_counter()-t0
    poolaudit=dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,PoolSize=S,PoolBest=int(cs.min()),PoolMean=float(cs.mean()),PoolSD=float(cs.std(ddof=1)),PoolWorst=int(cs.max()),EliteN=ens[.05],PoorN=pns[.10],TieMode=tie,ElapsedSec=elapsed,HistoricalPRAuditPass=all(x['Pass'] for x in audit),HistoricalPRMatched=sum(x['Pass'] for x in audit),HistoricalPRChecked=len(audit))
    if not poolaudit['HistoricalPRAuditPass']: raise RuntimeError([x for x in audit if not x['Pass']][:5])
    return raw,audit,poolaudit

def main(argv):
    rawp=OUT/'ofat_robustness_ofat_raw.csv';audp=OUT/'ofat_robustness_baseline_regression_audit.csv';poolp=OUT/'ofat_robustness_pool_audit.csv';done=completed(poolp)
    # supports PID[:rep] tokens; if rep absent, run all missing reps for PID.
    tokens=argv or SELECTED
    for tok in tokens:
      if ':' in tok: pid,r=tok.rsplit(':',1); reps=[int(r)]
      else: pid=tok; reps=range(1,6)
      for rep in reps:
        if (pid,rep) in done: continue
        print('RUN',pid,'rep',rep,flush=True);t=time.time(); raw,aud,pool=run_rep(pid,rep)
        append_csv(rawp,raw,list(raw[0].keys()));append_csv(audp,aud,list(aud[0].keys()));append_csv(poolp,[pool],list(pool.keys()));done.add((pid,rep));print('PASS',pid,'rep',rep,'wall',round(time.time()-t,2),flush=True)
if __name__=='__main__': main(sys.argv[1:])
