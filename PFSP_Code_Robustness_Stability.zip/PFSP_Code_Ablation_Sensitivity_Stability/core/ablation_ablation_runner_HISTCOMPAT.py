#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, hashlib, sys, time, concurrent.futures
from pathlib import Path
import numpy as np
import run_pfsp_single as core
from numba import njit, prange, set_num_threads

FAMILIES = core.FAMILIES

def generate_pool_parallel_sort(seed,pool_size,n,path,batch_size=100000,workers=16):
    rng=np.random.default_rng(seed)
    pool=np.memmap(path,dtype=np.uint16,mode='w+',shape=(pool_size,n))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        done=0
        while done<pool_size:
            b=min(batch_size,pool_size-done)
            keys=rng.random((b,n),dtype=np.float64)
            bounds=np.linspace(0,b,min(workers,b)+1,dtype=int)
            fut=[ex.submit(np.argsort,keys[bounds[k]:bounds[k+1]],1,'quicksort') for k in range(len(bounds)-1)]
            off=done
            for f in fut:
                arr=f.result().astype(np.uint16,copy=False)
                pool[off:off+len(arr)]=arr; off+=len(arr)
            done+=b
    pool.flush(); return pool



def generate_pool_array_parallel(seed,pool_size,n,batch_size=100000,workers=16):
    rng=np.random.default_rng(seed)
    pool=np.empty((pool_size,n),dtype=np.uint16)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        done=0
        while done<pool_size:
            b=min(batch_size,pool_size-done)
            keys=rng.random((b,n),dtype=np.float64)
            bounds=np.linspace(0,b,min(workers,b)+1,dtype=int)
            fut=[ex.submit(np.argsort,keys[bounds[k]:bounds[k+1]],1,'quicksort') for k in range(len(bounds)-1)]
            off=done
            for f in fut:
                arr=f.result().astype(np.uint16,copy=False)
                pool[off:off+len(arr)]=arr; off+=len(arr)
            done+=b
    return pool

def cmax_memmap_parallel(pool,p,batch_size=250000,workers=5):
    set_num_threads(min(5,workers))
    # Warm compilation outside algorithmic validity checks.
    _=fast_cmax_batch(np.asarray(pool[:min(2,pool.shape[0])]),p)
    S=pool.shape[0]; cs=np.empty(S,dtype=np.int64); done=0
    while done<S:
        b=min(batch_size,S-done)
        cs[done:done+b]=fast_cmax_batch(np.asarray(pool[done:done+b]),p)
        done+=b
    return cs

def regression_fast_pool_equivalence():
    # exact-key-stream and per-row argsort equivalence smoke check
    import tempfile
    td=Path(tempfile.mkdtemp())
    try:
        a=core.generate_pool_to_memmap(1234567,2000,50,td/'a.bin',500,False)
        b=generate_pool_parallel_sort(1234567,2000,50,td/'b.bin',500,8)
        ok=np.array_equal(np.asarray(a),np.asarray(b))
        cc=generate_pool_array_parallel(1234567,2000,50,500,8)
        ok = ok and np.array_equal(np.asarray(a),cc)
        # Accelerated Cmax and insertion evaluator must be exact.
        test=np.asarray(a[:20],dtype=np.uint16); ptest=np.arange(50*5,dtype=np.int64).reshape(50,5)%97+1
        ok = ok and np.array_equal(fast_cmax_batch(test,ptest), core.cmax_pool(test,ptest))
        seq=np.asarray(test[0,:15],dtype=np.int64); job=int(test[0,15])
        ok = ok and np.array_equal(fast_all_insert_cmax(seq,len(seq),job,ptest), core.all_insert_cmax(seq,job,ptest))
        e=np.asarray(a[:100],dtype=np.uint16); P1,R1=fast_group_stats(e,50,4); P2,R2=core.group_stats(e,50,4)
        ok = ok and np.array_equal(P1,P2) and np.array_equal(R1,R2)
        del a,b
        return ok
    finally:
        import shutil; shutil.rmtree(td,ignore_errors=True)



@njit(cache=True)
def fast_cmax_seq(seq,p):
    m=p.shape[1]; comp=np.zeros(m,np.int64)
    for ii in range(seq.shape[0]):
        jb=seq[ii]
        for j in range(m):
            left=comp[j-1] if j>0 else 0; up=comp[j]
            comp[j]=(up if up>left else left)+p[jb,j]
    return comp[m-1]

@njit(cache=True)
def fast_all_insert_cmax(seq,k,job,p):
    m=p.shape[1]
    e=np.zeros((k+1,m),np.int64)
    for i in range(1,k+1):
        jb=seq[i-1]
        for j in range(m):
            a=e[i-1,j]; b=e[i,j-1] if j>0 else 0
            e[i,j]=(a if a>b else b)+p[jb,j]
    q=np.zeros((k+1,m),np.int64)
    for ii in range(k-1,-1,-1):
        jb=seq[ii]
        for jj in range(m-1,-1,-1):
            a=q[ii+1,jj]; b=q[ii,jj+1] if jj<m-1 else 0
            q[ii,jj]=(a if a>b else b)+p[jb,jj]
    vals=np.empty(k+1,np.int64)
    for pos in range(k+1):
        prev=0;c=0
        for j in range(m):
            a=e[pos,j]; f=(a if a>prev else prev)+p[job,j]; prev=f
            v=f+q[pos,j]
            if v>c:c=v
        vals[pos]=c
    return vals

@njit(parallel=True,cache=True)
def fast_cmax_batch(pool,p):
    B,n=pool.shape; m=p.shape[1]; out=np.empty(B,np.int64)
    for r in prange(B):
        comp=np.zeros(m,np.int64)
        for t in range(n):
            jb=pool[r,t]
            for j in range(m):
                left=comp[j-1] if j>0 else 0; up=comp[j]
                comp[j]=(up if up>left else left)+p[jb,j]
        out[r]=comp[m-1]
    return out

@njit(parallel=True,cache=True)
def fast_group_stats(seqs,n,regions):
    G=seqs.shape[0]
    pos=np.empty((G,n),np.uint16)
    for r in prange(G):
        for k in range(n): pos[r,seqs[r,k]]=k
    P=np.zeros((n,n),np.float64)
    for i in prange(n-1):
        for j in range(i+1,n):
            cnt=0
            for r in range(G):
                if pos[r,i] < pos[r,j]: cnt += 1
            v=cnt/G; P[i,j]=v; P[j,i]=1.0-v
    R=np.zeros((n,regions),np.float64)
    for job in prange(n):
        cc=np.zeros(regions,np.int64)
        for r in range(G):
            rg=(int(pos[r,job])*regions)//n
            if rg>=regions: rg=regions-1
            cc[rg]+=1
        for rg in range(regions): R[job,rg]=cc[rg]/G
    return P,R



def thread_group_stats(seqs,n,regions,workers=4):
    G=seqs.shape[0]
    pos=np.empty((G,n),dtype=np.uint16)
    rows=np.arange(G,dtype=np.int64)[:,None]
    pos[rows,seqs.astype(np.intp,copy=False)]=np.arange(n,dtype=np.uint16)
    P=np.zeros((n,n),dtype=np.float64)
    def work(ii):
        ans=[]
        for i in ii:
            pi=pos[:,int(i)]
            for j in range(int(i)+1,n):
                ans.append((int(i),j,int(np.count_nonzero(pi<pos[:,j]))))
        return ans
    chunks=np.array_split(np.arange(n-1,dtype=np.int64),workers)
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        for block in ex.map(work,chunks):
            for i,j,cnt in block:
                v=cnt/G; P[i,j]=v; P[j,i]=1.0-v
    R=np.zeros((n,regions),dtype=np.float64)
    for job in range(n):
        rg=np.minimum((pos[:,job].astype(np.int64)*regions)//n,regions-1)
        R[job,:]=np.bincount(rg,minlength=regions)/G
    return P,R

def historical_filter_precedence(M,k):
    # Historical implementation compatibility: select top-|score| upper-triangle
    # entries with np.argpartition, then write the corresponding symmetric pair.
    n=M.shape[0]; out=np.zeros_like(M); iu=np.triu_indices(n,1); vals=np.abs(M[iu])
    if k is None or k>=len(vals): return M.copy()
    idx=np.argpartition(vals,-k)[-k:]
    for z in idx:
        i=iu[0][z]; j=iu[1][z]; out[i,j]=M[i,j]; out[j,i]=M[j,i]
    return out

def fast_mine_pr_rules(elite,poor,n,regions,top_p):
    ep,er=thread_group_stats(elite,n,regions,4); bp,br=thread_group_stats(poor,n,regions,4)
    return historical_filter_precedence(ep-0.5,top_p), er-1.0/regions, historical_filter_precedence(ep-bp,top_p), er-br

def fast_strict_best_reinsert(seq,job,p,tie_rule):
    red=list(map(int,seq)); red.remove(int(job)); arr=np.asarray(red,dtype=np.int64)
    vals=fast_all_insert_cmax(arr,len(red),int(job),p); best=int(vals.min()); cand=np.flatnonzero(vals==best)
    pos=core.fallback_position(cand,int(job),p,tie_rule)
    return red[:pos]+[int(job)]+red[pos:],best

WEIGHTS = [('P-only',1.0,0.0),('R-only',0.0,1.0),('P+R',0.65,0.35)]


def insertion_score_w(partial, job, pos, P, R, wp, wr):
    ps = 0.0
    if wp != 0.0:
        before = list(partial[:pos]); after = list(partial[pos:])
        if before: ps += float(np.sum(P[np.asarray(before,dtype=np.intp), job]))
        if after: ps += float(np.sum(P[job, np.asarray(after,dtype=np.intp)]))
        ps /= max(1,len(partial))
    rs = 0.0
    if wr != 0.0:
        k=len(partial)+1; regions=R.shape[1]; reg=min((pos*regions)//k, regions-1)
        rs=float(R[job,reg])
    return wp*ps + wr*rs


def info_best_insert_w(seq, job, p, P, R, fallback_tie_rule, wp, wr):
    arr=np.asarray(seq,dtype=np.int64); vals=fast_all_insert_cmax(arr,len(seq),job,p); best=int(vals.min()); cand=np.flatnonzero(vals==best)
    if cand.size==1: return int(cand[0]),best
    scores=np.asarray([insertion_score_w(seq,job,int(k),P,R,wp,wr) for k in cand],dtype=float)
    mx=float(scores.max()); top=np.flatnonzero(scores==mx)
    pref=core.fallback_position(cand,job,p,fallback_tie_rule)
    for ix in top:
        if int(cand[ix])==pref: return pref,best
    return int(cand[top[0]]),best


def construct_info_neh_w(order,p,P,R,fallback_tie_rule,wp,wr):
    order=list(map(int,order)); seq=[order[0]]
    for job in order[1:]:
        pos,_=info_best_insert_w(seq,job,p,P,R,fallback_tie_rule,wp,wr)
        seq=seq[:pos]+[job]+seq[pos:]
    return seq,int(fast_cmax_seq(np.asarray(seq,dtype=np.int64),p))


def current_violation_w(seq,P,R,wp,wr):
    N=P.shape[0]; nseq=len(seq); pos=np.zeros(N,dtype=np.int64); present=np.zeros(N,dtype=bool)
    for k,job in enumerate(seq): pos[job]=k; present[job]=True
    v=np.zeros(N,dtype=float)
    if wp != 0.0:
        ii,jj=np.where(P>0)
        for i,j in zip(ii.tolist(),jj.tolist()):
            if present[i] and present[j] and pos[i]>pos[j]:
                w=wp*float(P[i,j]); v[i]+=w; v[j]+=w
    if wr != 0.0:
        regions=R.shape[1]; mx=R.max(axis=1)
        for k,job in enumerate(seq):
            rg=min((k*regions)//nseq,regions-1)
            v[job]+=wr*max(0.0,float(mx[job]-R[job,rg]))
    return v


def construct_info_frb4_w(order,p,P,R,p_neigh,q_info,fallback_tie_rule,wp,wr):
    order=list(map(int,order)); seq=[order[0]]
    for job in order[1:]:
        pos,_=info_best_insert_w(seq,job,p,P,R,fallback_tie_rule,wp,wr)
        seq=seq[:pos]+[job]+seq[pos:]
        neigh=[]
        for d in range(1,p_neigh+1):
            if pos-d>=0: neigh.append(seq[pos-d])
            if pos+d<len(seq): neigh.append(seq[pos+d])
        current=int(fast_cmax_seq(np.asarray(seq,dtype=np.int64),p))
        for j2 in neigh:
            cand,cc=fast_strict_best_reinsert(seq,j2,p,fallback_tie_rule)
            if cc<current: seq,current=cand,cc
        v=current_violation_w(seq,P,R,wp,wr)
        ordered_jobs=[x for _,x in sorted(enumerate(seq),key=lambda t:(-v[t[1]],t[0]))]
        info_jobs=[]
        for j2 in ordered_jobs:
            if j2!=job and j2 not in neigh:
                info_jobs.append(j2)
                if len(info_jobs)>=q_info: break
        for j2 in info_jobs:
            cand,cc=fast_strict_best_reinsert(seq,j2,p,fallback_tie_rule)
            if cc<current: seq,current=cand,cc
    return seq,int(fast_cmax_seq(np.asarray(seq,dtype=np.int64),p))


def historical_expected(root,pid,rep):
    out={}
    for r in core.read_csv_rows(root/'historical_reference.csv'):
        if r['ProblemID']==pid and int(r['Replication'])==rep:
            out[(r['Mining'],r['Family'])]=int(r['RawCmax'])
    return out


def tie_mode_for(pid):
    # Exact archive audit established that Ta50x10 and VFR historical cutoff
    # membership preserves original pool-row order within equal-Cmax cutoff blocks.
    # Other groups use NumPy quicksort ordering, matching the historical reference.
    return 'deterministic' if (pid.startswith('Ta50_10_') or pid.startswith('VFR')) else 'numpy_quicksort'


def run_rep(pid,rep,root,outdir,pool_batch=25000,cmax_batch=50000,verbose=False):
    row=core.load_manifest_row(root,pid); p,meta=core.load_instance(root,row); n,m=p.shape
    seeds=core.load_seed_rows(root,pid); seed=int(seeds[rep-1]['Seed']); pool_size=int(seeds[rep-1]['PoolSize'])
    assert pool_size==10000*n
    elite_n=round(.05*pool_size); poor_n=round(.10*pool_size); regions=4; top_p=3*n; q_info=4
    tpt=core.tpt_order(p); kk=core.kk2_style_order(p)
    poolfile=None
    t0=time.perf_counter()
    pool=generate_pool_array_parallel(seed,pool_size,n,max(pool_batch,100000),16)
    cs=cmax_memmap_parallel(pool,p,max(cmax_batch,250000),5)
    eidx,bidx=core.selection_indices(cs,elite_n,poor_n,tie_mode_for(pid))
    elite=np.asarray(pool[eidx,:],dtype=np.uint16); poor=np.asarray(pool[bidx,:],dtype=np.uint16)
    PE,RE,PC,RC=fast_mine_pr_rules(elite,poor,n,regions,top_p)
    expected=historical_expected(root,pid,rep)
    raw=[]; audit=[]
    for mode,wp,wr in WEIGHTS:
      for mining,P,R in [('Elite-only',PE,RE),('Contrast',PC,RC)]:
        runs=[
          construct_info_neh_w(tpt,p,P,R,0,wp,wr),
          construct_info_neh_w(tpt,p,P,R,2,wp,wr),
          construct_info_neh_w(kk,p,P,R,2,wp,wr),
          construct_info_frb4_w(tpt,p,P,R,1,q_info,2,wp,wr),
          construct_info_frb4_w(kk,p,P,R,1,q_info,2,wp,wr),
        ]
        for fam,(seq,c) in zip(FAMILIES,runs):
          core.validate_solution(seq,c,p,n)
          raw.append(dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,Mining=mining,Mode=mode,PWeight=wp,RWeight=wr,Family=fam,Cmax=int(c),Sequence=' '.join(str(x+1) for x in seq)))
          if mode=='P+R':
            exp=expected.get((mining,fam)); audit.append(dict(ProblemID=pid,Replication=rep,Seed=seed,Mining=mining,Family=fam,Got=int(c),Expected=exp,Pass=(exp==int(c))))
    elapsed=time.perf_counter()-t0
    poolaudit=dict(ProblemID=pid,Group=row['Group'],n=n,m=m,Replication=rep,Seed=seed,PoolSize=pool_size,PoolBest=int(cs.min()),PoolMean=float(cs.mean()),PoolSD=float(cs.std(ddof=1)),PoolWorst=int(cs.max()),EliteN=elite_n,PoorN=poor_n,TieMode=tie_mode_for(pid),ElapsedSec=elapsed,HistoricalPRAuditPass=all(x['Pass'] for x in audit),HistoricalPRMatched=sum(x['Pass'] for x in audit),HistoricalPRChecked=len(audit))
    # cleanup before fail gate
    del elite,poor,PE,RE,PC,RC,cs,pool
    if poolfile is not None and poolfile.exists(): poolfile.unlink()
    if not poolaudit['HistoricalPRAuditPass']:
      bad=[x for x in audit if not x['Pass']]
      raise RuntimeError(f'HISTORICAL P+R GATE FAIL {pid} rep{rep}: {bad[:5]}')
    return raw,audit,poolaudit


def append_csv(path,rows,fields):
    new=not path.exists()
    with path.open('a',newline='',encoding='utf-8') as f:
      w=csv.DictWriter(f,fieldnames=fields)
      if new: w.writeheader()
      w.writerows(rows)


def completed_keys(path):
    if not path.exists(): return set()
    with path.open(newline='',encoding='utf-8') as f:
      return {(r['ProblemID'],int(r['Replication'])) for r in csv.DictReader(f)}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--problem',action='append'); ap.add_argument('--start-group'); ap.add_argument('--rep',type=int); ap.add_argument('--outdir',default='/mnt/data/PFSP_ablation_Ablation_Results'); ap.add_argument('--verbose',action='store_true'); args=ap.parse_args()
    root=Path(__file__).resolve().parent; outdir=Path(args.outdir); outdir.mkdir(parents=True,exist_ok=True)
    man=core.read_csv_rows(root/'instance_manifest.csv')
    pids=args.problem or [r['ProblemID'] for r in man]
    rawpath=outdir/'ablation_ablation_raw.csv'; audpath=outdir/'ablation_pr_regression_audit.csv'; poolpath=outdir/'ablation_pool_audit.csv'
    done=completed_keys(poolpath)
    for pid in pids:
      reps=[args.rep] if args.rep else range(1,6)
      for rep in reps:
        if (pid,rep) in done: print('SKIP',pid,rep,flush=True); continue
        print('RUN',pid,'rep',rep,flush=True); t=time.time()
        raw,audit,poolaudit=run_rep(pid,rep,root,outdir,verbose=args.verbose)
        append_csv(rawpath,raw,list(raw[0].keys())); append_csv(audpath,audit,list(audit[0].keys())); append_csv(poolpath,[poolaudit],list(poolaudit.keys()))
        print('PASS',pid,'rep',rep,'elapsed',round(time.time()-t,2),'s',flush=True)

if __name__=='__main__': main()
