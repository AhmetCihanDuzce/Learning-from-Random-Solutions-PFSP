import re, time
from pathlib import Path
import numpy as np
from numba import njit
from scipy.stats import pearsonr, spearmanr, rankdata

@njit(cache=True)
def cmax_seq(seq,p):
    m=p.shape[1]; comp=np.zeros(m,np.int64)
    for ii in range(seq.shape[0]):
        jb=seq[ii]
        for j in range(m):
            left=comp[j-1] if j>0 else 0; up=comp[j]
            comp[j]=(up if up>left else left)+p[jb,j]
    return comp[m-1]

@njit(cache=True)
def all_insert_cmax(seq,k,job,p):
    m=p.shape[1]
    e=np.zeros((k+1,m),np.int64)
    for i in range(1,k+1):
        jb=seq[i-1]
        for j in range(m):
            a=e[i-1,j]; b=e[i,j-1] if j>0 else 0
            e[i,j]=(a if a>b else b)+p[jb,j]
    q=np.zeros((k+1,m),np.int64)
    for ii in range(k-1,-1,-1):
        jb=seq[ii]
        for jj in range(m-1,-1,-1):
            a=q[ii+1,jj]; b=q[ii,jj+1] if jj<m-1 else 0
            q[ii,jj]=(a if a>b else b)+p[jb,jj]
    vals=np.empty(k+1,np.int64)
    for pos in range(k+1):
        prev=0;c=0
        for j in range(m):
            a=e[pos,j]; f=(a if a>prev else prev)+p[job,j]; prev=f
            v=f+q[pos,j]
            if v>c:c=v
        vals[pos]=c
    return vals

@njit(cache=True)
def neh_from_order(order,p,tie_mode=0):
    n=order.shape[0]; seq=np.empty(n,np.int64); seq[0]=order[0]
    c=0
    for j in range(p.shape[1]): c+=p[order[0],j]
    k=1; evals=0
    for t in range(1,n):
        vals=all_insert_cmax(seq,k,order[t],p); evals += k+1
        best=vals[0]; bp=0
        for pos in range(1,k+1):
            if vals[pos]<best:
                best=vals[pos]; bp=pos
            elif vals[pos]==best:
                if tie_mode==1 and pos>bp: bp=pos
        for z in range(k,bp,-1): seq[z]=seq[z-1]
        seq[bp]=order[t]; k+=1; c=best
    return seq,c,evals

@njit(cache=True)
def insertion_pass_order(seq,p,job_order):
    n=seq.shape[0]; current=cmax_seq(seq,p); moves=0; evals=0
    reduced=np.empty(n-1,np.int64); newseq=np.empty(n,np.int64)
    for tt in range(n):
        job=job_order[tt]; idx=0
        while seq[idx]!=job: idx+=1
        q=0
        for i in range(n):
            if i!=idx: reduced[q]=seq[i]; q+=1
        vals=all_insert_cmax(reduced,n-1,job,p); evals+=n
        bp=0; bc=vals[0]
        for pos in range(1,n):
            if vals[pos]<bc: bc=vals[pos];bp=pos
        if bc<current:
            for i in range(bp):newseq[i]=reduced[i]
            newseq[bp]=job
            for i in range(bp,n-1):newseq[i+1]=reduced[i]
            seq=newseq.copy();current=bc;moves+=1
    return seq,current,moves,evals

@njit(cache=True)
def insertion_pass(seq,p):
    return insertion_pass_order(seq,p,seq.copy())

@njit(cache=True)
def insertion_descent(seq,p,max_passes=10):
    totalm=0;totale=0;passes=0;cur=cmax_seq(seq,p)
    for _ in range(max_passes):
        seq2,c,m,e=insertion_pass(seq,p);passes+=1;totalm+=m;totale+=e
        seq=seq2;cur=c
        if m==0:break
    return seq,cur,totalm,totale,passes

@njit(cache=True)
def swap_best_pass(seq,p):
    n=seq.shape[0];cur=cmax_seq(seq,p);best=cur;bi=-1;bj=-1;evals=0
    for i in range(n-1):
        for j in range(i+1,n):
            tmp=seq[i];seq[i]=seq[j];seq[j]=tmp
            c=cmax_seq(seq,p);evals+=1
            tmp=seq[i];seq[i]=seq[j];seq[j]=tmp
            if c<best:best=c;bi=i;bj=j
    if bi>=0:
        tmp=seq[bi];seq[bi]=seq[bj];seq[bj]=tmp
        return seq,best,1,evals
    return seq,cur,0,evals

@njit(cache=True)
def swap_descent(seq,p,max_passes=10):
    totalm=0;totale=0;passes=0;cur=cmax_seq(seq,p)
    for _ in range(max_passes):
        seq,c,m,e=swap_best_pass(seq,p);passes+=1;totalm+=m;totale+=e;cur=c
        if m==0:break
    return seq,cur,totalm,totale,passes

@njit(cache=True)
def block_best_pass(seq,p):
    n=seq.shape[0];cur=cmax_seq(seq,p);best=cur;bs=-1;bl=0;bt=-1;evals=0
    reduced=np.empty(n,np.int64);cand=np.empty(n,np.int64);block=np.empty(3,np.int64)
    for L in (2,3):
        for s in range(n-L+1):
            for z in range(L):block[z]=seq[s+z]
            q=0
            for i in range(n):
                if i<s or i>=s+L:reduced[q]=seq[i];q+=1
            for t in range(n-L+1):
                if t==s:continue
                for i in range(t):cand[i]=reduced[i]
                for z in range(L):cand[t+z]=block[z]
                for i in range(t,n-L):cand[i+L]=reduced[i]
                c=cmax_seq(cand,p);evals+=1
                if c<best:best=c;bs=s;bl=L;bt=t
    if bs>=0:
        L=bl
        for z in range(L):block[z]=seq[bs+z]
        q=0
        for i in range(n):
            if i<bs or i>=bs+L:reduced[q]=seq[i];q+=1
        for i in range(bt):cand[i]=reduced[i]
        for z in range(L):cand[bt+z]=block[z]
        for i in range(bt,n-L):cand[i+L]=reduced[i]
        return cand.copy(),best,1,evals
    return seq,cur,0,evals

@njit(cache=True)
def block_descent(seq,p,max_passes=10):
    totalm=0;totale=0;passes=0;cur=cmax_seq(seq,p)
    for _ in range(max_passes):
        seq,c,m,e=block_best_pass(seq,p);passes+=1;totalm+=m;totale+=e;cur=c
        if m==0:break
    return seq,cur,totalm,totale,passes

@njit(cache=True)
def vnd_isb(seq,p,max_cycles=5,ins_passes=10):
    cur=cmax_seq(seq,p);tm=0;te=0;steps=0
    for _ in range(max_cycles):
        old=cur
        seq,cur,m,e,pa=insertion_descent(seq,p,ins_passes);tm+=m;te+=e;steps+=pa
        seq2,c,m,e=swap_best_pass(seq,p);te+=e;steps+=1
        if m>0:seq=seq2;cur=c;tm+=1;continue
        seq2,c,m,e=block_best_pass(seq,p);te+=e;steps+=1
        if m>0:seq=seq2;cur=c;tm+=1;continue
        if cur>=old:break
    return seq,cur,tm,te,steps

@njit(cache=True)
def vnd_ibs(seq,p,max_cycles=5,ins_passes=10):
    cur=cmax_seq(seq,p);tm=0;te=0;steps=0
    for _ in range(max_cycles):
        old=cur
        seq,cur,m,e,pa=insertion_descent(seq,p,ins_passes);tm+=m;te+=e;steps+=pa
        seq2,c,m,e=block_best_pass(seq,p);te+=e;steps+=1
        if m>0:seq=seq2;cur=c;tm+=1;continue
        seq2,c,m,e=swap_best_pass(seq,p);te+=e;steps+=1
        if m>0:seq=seq2;cur=c;tm+=1;continue
        if cur>=old:break
    return seq,cur,tm,te,steps


def parse_instances(path):
    lines=Path(path).read_text(encoding='utf-8',errors='ignore').splitlines();out=[];i=0
    while i<len(lines):
        if lines[i].strip().startswith('number of jobs'):
            n,m,seed,ub,lb=map(int,re.findall(r'-?\d+',lines[i+1])[:5]);rows=[]
            for r in range(i+3,i+3+m):
                x=list(map(int,re.findall(r'\d+',lines[r])))
                if len(x)!=n: raise ValueError((i,r,len(x),n))
                rows.append(x)
            out.append({'n':n,'m':m,'seed':seed,'ub':ub,'lb':lb,'p':np.array(rows,np.int64).T.copy()});i+=3+m
        else:i+=1
    return out


def mine_rules(seqs,cvals,elite_frac=.05,bad_frac=.20,regions=4):
    N,n=seqs.shape; ordx=np.argsort(cvals); ne=max(10,int(round(N*elite_frac))); nb=max(20,int(round(N*bad_frac)))
    elite=seqs[ordx[:ne]]; bad=seqs[ordx[-nb:]]
    def stats(g):
        G=g.shape[0]; pos=np.empty((G,n),np.int16)
        for r in range(G): pos[r,g[r]]=np.arange(n,dtype=np.int16)
        prec=np.mean(pos[:,:,None]<pos[:,None,:],axis=0,dtype=np.float64)
        reg=np.minimum((pos*regions)//n,regions-1)
        rf=np.zeros((n,regions),float)
        for rr in range(regions):rf[:,rr]=np.mean(reg==rr,axis=0)
        adj=np.zeros((n,n),float);a=g[:,:-1].ravel();b=g[:,1:].ravel();np.add.at(adj,(a,b),1.0);adj/=G
        return prec,rf,adj
    ep,er,ea=stats(elite);bp,br,ba=stats(bad)
    return {'P':ep-bp,'R':er-br,'A':ea-ba,'EP':ep-.5,'ER':er-(1/regions),'EA':ea-(1/(n-1)),
            'elite_n':ne,'bad_n':nb}


def filter_precedence(M,k):
    n=M.shape[0]; out=np.zeros_like(M); iu=np.triu_indices(n,1); vals=np.abs(M[iu])
    if k is None or k>=len(vals):return M.copy()
    idx=np.argpartition(vals,-k)[-k:]
    for z in idx:
        i=iu[0][z];j=iu[1][z];out[i,j]=M[i,j];out[j,i]=M[j,i]
    return out


def filter_top(M,k,exclude_diag=True):
    out=np.zeros_like(M); vals=np.abs(M).ravel()
    if exclude_diag and M.ndim==2 and M.shape[0]==M.shape[1]:
        vals=vals.copy(); vals[np.arange(M.shape[0])*(M.shape[0]+1)]=-np.inf
    valid=np.isfinite(vals)
    kk=min(int(k),int(valid.sum()))
    if kk<=0:return out
    idx=np.argpartition(vals,-kk)[-kk:];out.ravel()[idx]=M.ravel()[idx];return out


def prepare_rules(seqs,cvals,kp=300,ka=100,stable_p=.10,stable_r=.05,regions=4):
    full=mine_rules(seqs,cvals,regions=regions);h=len(seqs)//2
    A=mine_rules(seqs[:h],cvals[:h],regions=regions);B=mine_rules(seqs[h:],cvals[h:],regions=regions)
    n=seqs.shape[1];off=~np.eye(n,dtype=bool)
    def corr(x,y,mask=None):
        xx=x.ravel();yy=y.ravel()
        if mask is not None:xx=xx[mask.ravel()];yy=yy[mask.ravel()]
        if np.std(xx)==0 or np.std(yy)==0:return (np.nan,np.nan)
        return float(pearsonr(xx,yy).statistic),float(spearmanr(xx,yy).statistic)
    stability={'P':corr(A['P'],B['P'],off),'R':corr(A['R'],B['R']),'A':corr(A['A'],B['A'],off)}
    # stable masks based on same sign and minimum absolute magnitude in both halves
    mp=(np.sign(A['P'])==np.sign(B['P']))&(np.minimum(np.abs(A['P']),np.abs(B['P']))>=stable_p)
    mr=(np.sign(A['R'])==np.sign(B['R']))&(np.minimum(np.abs(A['R']),np.abs(B['R']))>=stable_r)
    ma=(np.sign(A['A'])==np.sign(B['A']))&(np.minimum(np.abs(A['A']),np.abs(B['A']))>=max(.005,stable_r/5))
    rules={
      'EP':filter_precedence(full['EP'],kp),'ER':full['ER'].copy(),'EA':filter_top(full['EA'],ka),
      'P':filter_precedence(full['P'],kp),'R':full['R'].copy(),'A':filter_top(full['A'],ka),
      'SP':filter_precedence(np.where(mp,full['P'],0.0),kp),'SR':np.where(mr,full['R'],0.0),'SA':filter_top(np.where(ma,full['A'],0.0),ka),
      'stability':stability,'halfA':A,'halfB':B,'elite_n':full['elite_n'],'bad_n':full['bad_n'],
      'stable_counts':(int(mp.sum()/2),int(mr.sum()),int(ma.sum()))
    }
    return rules


def rule_score(seq,P=None,R=None,A=None,w=(1,0,0),regions=4):
    k=len(seq);sc=0.0;wp,wr,wa=w
    if P is not None and wp and k>1:
        sub=P[np.ix_(seq,seq)]
        sc+=wp*float(np.triu(sub,1).sum())/(k*(k-1)/2)
    if R is not None and wr:
        rg=np.minimum((np.arange(k)*regions)//k,regions-1);sc+=wr*float(np.mean(R[seq,rg]))
    if A is not None and wa and k>1:sc+=wa*float(np.mean(A[seq[:-1],seq[1:]]))
    return sc


def beam_neh(order,p,P=None,R=None,A=None,w=(1,0,0),beam=5,short_factor=5,lam=.35,regions=4):
    beams=[np.array([int(order[0])],np.int64)];evals=0
    for t in range(1,len(order)):
        job=int(order[t]);desc=[]
        for bi,parent in enumerate(beams):
            vals=all_insert_cmax(parent,len(parent),job,p);evals+=len(vals)
            desc.extend((int(c),bi,pos) for pos,c in enumerate(vals))
        desc.sort(key=lambda z:z[0]);guided=not(P is None and R is None and A is None)
        take=min(len(desc),beam*(short_factor if guided else 1));short=[]
        for c,bi,pos in desc[:take]:short.append((c,np.insert(beams[bi],pos,job)))
        if not guided:beams=[x[1] for x in short[:beam]];continue
        cv=np.array([x[0] for x in short],float);rs=np.array([rule_score(x[1],P,R,A,w,regions) for x in short])
        comb=rankdata(cv,method='average')+lam*rankdata(-rs,method='average')
        ii=np.argsort(comb,kind='stable')[:beam];beams=[short[i][1] for i in ii]
    fs=[(int(cmax_seq(s,p)),s) for s in beams];fs.sort(key=lambda z:z[0]);return fs[0][1],fs[0][0],evals


def method_spec(name,rules):
    if name=='Beam-N':return None,None,None,(0,0,0)
    if name=='E-P+R':return rules['EP'],rules['ER'],None,(.65,.35,0)
    if name=='CM-P':return rules['P'],None,None,(1,0,0)
    if name=='CM-R':return None,rules['R'],None,(0,1,0)
    if name=='CM-A':return None,None,rules['A'],(0,0,1)
    if name=='CM-P+R':return rules['P'],rules['R'],None,(.65,.35,0)
    if name=='CM-P+R+A':return rules['P'],rules['R'],rules['A'],(.55,.35,.10)
    if name=='SP+R':return rules['SP'],rules['SR'],None,(.65,.35,0)
    raise KeyError(name)


def job_violation_order(seq,P=None,R=None,A=None,w=(1,0,0),regions=4):
    n=len(seq);pos=np.empty(n,int);pos[seq]=np.arange(n);v=np.zeros(n,float);wp,wr,wa=w
    if P is not None and wp:
        ii,jj=np.where(P>0)
        for i,j in zip(ii,jj):
            if pos[i]>pos[j]:
                z=wp*P[i,j];v[i]+=z;v[j]+=z
    if R is not None and wr:
        rg=np.minimum((pos*regions)//n,regions-1)
        mx=R.max(axis=1);v+=wr*np.maximum(0,mx-R[np.arange(n),rg])
    if A is not None and wa and n>1:
        for k in range(n-1):
            i=seq[k];j=seq[k+1]
            if A[i,j]<0:
                z=wa*(-A[i,j]);v[i]+=z;v[j]+=z
    # stable tie break by current sequence order
    return np.array(sorted(seq.tolist(), key=lambda j:(-v[j],pos[j])),np.int64)


def guided_insertion_descent(seq,p,P,R,A,w,max_passes=10,regions=4):
    seq=seq.copy();cur=int(cmax_seq(seq,p));tm=0;te=0;passes=0
    for _ in range(max_passes):
        order=job_violation_order(seq,P,R,A,w,regions)
        seq2,c,m,e=insertion_pass_order(seq,p,order)
        seq=seq2;cur=int(c);tm+=int(m);te+=int(e);passes+=1
        if m==0:break
    return seq,cur,tm,te,passes


def candidate_positions(seq,job,P,R,A,w,q,regions=4):
    n=len(seq); scores=[]
    for pos in range(n):
        cand=np.insert(seq,pos,job)
        scores.append(rule_score(cand,P,R,A,w,regions))
    idx=np.argsort(-np.array(scores),kind='stable')[:min(q,n)]
    return np.array(idx,np.int64)

@njit(cache=True)
def insert_at(reduced,job,pos):
    n=reduced.shape[0]+1;out=np.empty(n,np.int64)
    for i in range(pos):out[i]=reduced[i]
    out[pos]=job
    for i in range(pos,n-1):out[i+1]=reduced[i]
    return out


def candidate_insertion_descent(seq,p,P,R,A,w,q=10,max_passes=10,regions=4):
    seq=seq.copy();n=len(seq);cur=int(cmax_seq(seq,p));tm=0;te=0;passes=0
    for _ in range(max_passes):
        moved=0;order=job_violation_order(seq,P,R,A,w,regions)
        for job in order:
            idx=int(np.where(seq==job)[0][0]);reduced=np.delete(seq,idx)
            poss=candidate_positions(reduced,int(job),P,R,A,w,q,regions)
            best=cur;bestseq=None
            for pos in poss:
                cand=np.insert(reduced,int(pos),int(job)).astype(np.int64)
                c=int(cmax_seq(cand,p));te+=1
                if c<best:best=c;bestseq=cand
            if bestseq is not None:
                seq=bestseq;cur=best;tm+=1;moved+=1
        passes+=1
        if moved==0:break
    return seq,cur,tm,te,passes


def apply_ls(seq,p,ls,ins_passes=10,vnd_cycles=5,vnd_order='ISB',guided=None,candidate_q=10):
    t=time.perf_counter();start=int(cmax_seq(seq,p))
    if ls=='NONE':return seq.copy(),start,0,0,0,time.perf_counter()-t
    if ls=='INS-1':s,c,m,e=insertion_pass(seq.copy(),p);return s,int(c),int(m),int(e),1,time.perf_counter()-t
    if ls=='INS-D':s,c,m,e,pa=insertion_descent(seq.copy(),p,ins_passes);return s,int(c),int(m),int(e),int(pa),time.perf_counter()-t
    if ls=='SWAP':s,c,m,e,pa=swap_descent(seq.copy(),p,10);return s,int(c),int(m),int(e),int(pa),time.perf_counter()-t
    if ls=='BLOCK':s,c,m,e,pa=block_descent(seq.copy(),p,10);return s,int(c),int(m),int(e),int(pa),time.perf_counter()-t
    if ls=='VND':
        if vnd_order=='IBS':s,c,m,e,pa=vnd_ibs(seq.copy(),p,vnd_cycles,ins_passes)
        else:s,c,m,e,pa=vnd_isb(seq.copy(),p,vnd_cycles,ins_passes)
        return s,int(c),int(m),int(e),int(pa),time.perf_counter()-t
    if ls=='G-INS-D':
        P,R,A,w=guided;s,c,m,e,pa=guided_insertion_descent(seq.copy(),p,P,R,A,w,ins_passes);return s,c,m,e,pa,time.perf_counter()-t
    if ls=='CL-INS-D':
        P,R,A,w=guided;s,c,m,e,pa=candidate_insertion_descent(seq.copy(),p,P,R,A,w,candidate_q,ins_passes);return s,c,m,e,pa,time.perf_counter()-t
    raise KeyError(ls)


def generate_pool(p,size,seed):
    n=p.shape[0];rng=np.random.default_rng(seed);seqs=np.empty((size,n),np.int16);cs=np.empty(size,np.int64);evals=0
    t=time.perf_counter()
    for r in range(size):
        s,c,e=neh_from_order(rng.permutation(n).astype(np.int64),p,0);seqs[r]=s;cs[r]=c;evals+=int(e)
    return seqs,cs,time.perf_counter()-t,evals


def cross_validate_rules(seqs,cs,kp,ka,stable_p=.10,stable_r=.05,regions=4):
    h=len(seqs)//2;out=[]
    for label,tr,te in [('AonB',slice(None,h),slice(h,None)),('BonA',slice(h,None),slice(None,h))]:
        rr=prepare_rules(seqs[tr],cs[tr],kp,ka,stable_p,stable_r,regions)
        P,R,A=rr['P'],rr['R'],rr['A'];scores=np.array([rule_score(s,P,R,A,(.55,.35,.10),regions) for s in seqs[te]])
        y=cs[te]
        out.append((label,float(pearsonr(scores,y).statistic),float(spearmanr(scores,y).statistic)))
    return out
