from __future__ import annotations
import json, math, time
from pathlib import Path
import numpy as np
from numba import njit, prange, set_num_threads, get_num_threads
from cmneh_core import cmax_seq, all_insert_cmax, parse_instances, prepare_rules

DATA = '/mnt/data/tai200_20(1).txt'
OUT = Path('/mnt/data/ta091_strong_cm_pilot')
OUT.mkdir(exist_ok=True)

@njit(cache=True)
def insert_at_local(seq, k, job, pos):
    out = np.empty(k+1, np.int64)
    for i in range(pos): out[i] = seq[i]
    out[pos] = job
    for i in range(pos, k): out[i+1] = seq[i]
    return out

@njit(cache=True)
def remove_job_at(seq, k, idx):
    out = np.empty(k-1, np.int64)
    q = 0
    for i in range(k):
        if i != idx:
            out[q] = seq[i]; q += 1
    return out

@njit(cache=True)
def find_job(seq, k, job):
    for i in range(k):
        if seq[i] == job: return i
    return -1

@njit(cache=True)
def kk2_ab(job, p):
    m = p.shape[1]
    const = (m-1)*(m-2)/2.0
    a = 0.0; b = 0.0
    for i in range(m):
        # i is zero-based; published TBKK2 weights translated from i=1..m
        a += (const + (m-(i+1))) * p[job, i]
        b += (const + i) * p[job, i]
    return a, b


def tpt_order(p):
    return np.lexsort((np.arange(p.shape[0]), -p.sum(axis=1))).astype(np.int64)


def kk2_style_order(p):
    """Johnson-style order using the published TBKK2 weighted fictitious times.
    This is labelled KK2-style, not claimed as a verbatim PRKK2 reproduction.
    """
    n = p.shape[0]
    a = np.zeros(n); b = np.zeros(n)
    for j in range(n):
        a[j], b[j] = kk2_ab.py_func(j, p)
    front = [j for j in range(n) if a[j] <= b[j]]
    back = [j for j in range(n) if a[j] > b[j]]
    front.sort(key=lambda j: (a[j], j))
    back.sort(key=lambda j: (-b[j], j))
    return np.array(front + back, dtype=np.int64)

@njit(cache=True)
def choose_insert(seq, k, job, p, tie_rule):
    vals = all_insert_cmax(seq, k, job, p)
    best = vals[0]
    for z in range(1, k+1):
        if vals[z] < best: best = vals[z]
    first = 0
    while vals[first] != best: first += 1
    last = k
    while vals[last] != best: last -= 1
    if tie_rule == 0:
        pos = first
    elif tie_rule == 1:
        pos = last
    else:
        a,b = kk2_ab(job,p)
        pos = first if a >= b else last
    return pos, best, vals

@njit(cache=True)
def construct_neh(order, p, tie_rule=0):
    n = order.shape[0]
    seq = np.empty(n, np.int64); seq[0] = order[0]
    k = 1; evals = 0
    for t in range(1,n):
        pos,best,vals = choose_insert(seq,k,order[t],p,tie_rule)
        evals += k+1
        for z in range(k,pos,-1): seq[z]=seq[z-1]
        seq[pos]=order[t]; k += 1
    return seq, cmax_seq(seq,p), evals

@njit(cache=True)
def reinsert_job_best(seq, k, job, p, tie_rule=0):
    idx = find_job(seq,k,job)
    red = remove_job_at(seq,k,idx)
    pos,best,vals = choose_insert(red,k-1,job,p,tie_rule)
    cand = insert_at_local(red,k-1,job,pos)
    return cand,best,k,idx,pos

@njit(cache=True)
def construct_frb4(order,p,p_neigh=1,tie_rule=0):
    n=order.shape[0]
    seq=np.empty(n,np.int64); seq[0]=order[0]
    k=1; evals=0; accepted=0
    for t in range(1,n):
        job=order[t]
        pos,best,vals=choose_insert(seq,k,job,p,tie_rule); evals += k+1
        for z in range(k,pos,-1): seq[z]=seq[z-1]
        seq[pos]=job; k+=1
        # Snapshot neighborhood jobs immediately after insertion.
        neigh=np.empty(2*p_neigh,np.int64); cnt=0
        for d in range(1,p_neigh+1):
            lp=pos-d
            if lp>=0: neigh[cnt]=seq[lp]; cnt+=1
            rp=pos+d
            if rp<k: neigh[cnt]=seq[rp]; cnt+=1
        current=cmax_seq(seq[:k],p)
        for z in range(cnt):
            j2=neigh[z]
            cand,cc,e,oldp,newp = reinsert_job_best(seq[:k],k,j2,p,tie_rule)
            evals += e
            if cc < current:
                for q in range(k): seq[q]=cand[q]
                current=cc; accepted+=1
    return seq,cmax_seq(seq,p),evals,accepted


def insertion_score(partial, job, pos, P, R):
    before=partial[:pos]; after=partial[pos:]
    ps=0.0
    if len(before): ps += float(P[before,job].sum())
    if len(after): ps += float(P[job,after].sum())
    ps /= max(1,len(partial))
    k=len(partial)+1; reg=min((pos*R.shape[1])//k,R.shape[1]-1)
    return 0.65*ps + 0.35*float(R[job,reg])


def current_violation(seq,P,R):
    n=len(seq); N=P.shape[0]
    pos=np.full(N,-1,dtype=int); pos[seq]=np.arange(n)
    present=np.zeros(N,dtype=bool); present[seq]=True
    v=np.zeros(N,dtype=float)
    ii,jj=np.where(P>0)
    for i,j in zip(ii.tolist(),jj.tolist()):
        if present[i] and present[j] and pos[i] > pos[j]:
            z=0.65*P[i,j]; v[i]+=z; v[j]+=z
    regions=R.shape[1]
    mx=R.max(axis=1)
    for job in seq.tolist():
        rg=min((int(pos[job])*regions)//n,regions-1)
        v[job] += 0.35*max(0.0,float(mx[job]-R[job,rg]))
    return v


def cm_best_insert(seq,job,p,P,R,tie_mode='objective',base_tie_rule=0):
    vals=all_insert_cmax(seq,len(seq),int(job),p)
    mc=int(vals.min()); cand=np.flatnonzero(vals==mc)
    if len(cand)==1: return int(cand[0]),mc,len(vals),False
    if tie_mode=='cm':
        scores=np.array([insertion_score(seq,int(job),int(z),P,R) for z in cand])
        # objective ties only; score then KK2 endpoint preference then earliest
        a,b=kk2_ab.py_func(int(job),p); pref=int(cand[0] if a>=b else cand[-1])
        best=max(range(len(cand)),key=lambda q:(scores[q], int(cand[q]==pref), -int(cand[q])))
        return int(cand[best]),mc,len(vals),True
    a,b=kk2_ab.py_func(int(job),p)
    return int(cand[0] if (base_tie_rule==0 or a>=b) else cand[-1]),mc,len(vals),False


def construct_cm_tie(order,p,P,R):
    seq=np.array([int(order[0])],dtype=np.int64); evals=0; guided=0
    for job in order[1:]:
        pos,c,e,g=cm_best_insert(seq,int(job),p,P,R,'cm',2)
        seq=np.insert(seq,pos,int(job)).astype(np.int64); evals+=e; guided+=int(g)
    return seq,int(cmax_seq(seq,p)),evals,guided


def strict_best_reinsert_py(seq,job,p,tie_rule=2):
    idx=int(np.where(seq==job)[0][0]); red=np.delete(seq,idx).astype(np.int64)
    vals=all_insert_cmax(red,len(red),int(job),p); mc=int(vals.min()); cand=np.flatnonzero(vals==mc)
    if tie_rule==2:
        a,b=kk2_ab.py_func(int(job),p); pos=int(cand[0] if a>=b else cand[-1])
    else: pos=int(cand[0])
    return np.insert(red,pos,int(job)).astype(np.int64),mc,len(vals),idx,pos


def construct_cm_frb4(order,p,P,R,p_neigh=1,q_cm=4,tie_cm=False):
    seq=np.array([int(order[0])],dtype=np.int64); evals=0; accepted=0; cm_accept=0; guided_ties=0
    for job in order[1:]:
        if tie_cm:
            pos,c,e,g=cm_best_insert(seq,int(job),p,P,R,'cm',2); guided_ties+=int(g)
        else:
            vals=all_insert_cmax(seq,len(seq),int(job),p); c=int(vals.min()); cand=np.flatnonzero(vals==c)
            a,b=kk2_ab.py_func(int(job),p); pos=int(cand[0] if a>=b else cand[-1]); e=len(vals)
        seq=np.insert(seq,pos,int(job)).astype(np.int64); evals+=e
        # Standard FRB4 neighbours from post-insertion positions.
        neigh=[]
        for d in range(1,p_neigh+1):
            if pos-d>=0: neigh.append(int(seq[pos-d]))
            if pos+d<len(seq): neigh.append(int(seq[pos+d]))
        current=int(cmax_seq(seq,p))
        for j2 in neigh:
            cand,cc,e,oldp,newp=strict_best_reinsert_py(seq,j2,p,2); evals+=e
            if cc<current:
                seq=cand; current=cc; accepted+=1
        # CM adds the q most violated jobs not already examined and not the new job.
        v=current_violation(seq,P,R)
        cmjobs=[int(j) for j in seq[np.argsort(-v[seq],kind='stable')] if int(j)!=int(job) and int(j) not in neigh][:q_cm]
        for j2 in cmjobs:
            cand,cc,e,oldp,newp=strict_best_reinsert_py(seq,j2,p,2); evals+=e
            if cc<current:
                seq=cand; current=cc; accepted+=1; cm_accept+=1
    return seq,int(cmax_seq(seq,p)),evals,accepted,cm_accept,guided_ties

@njit(parallel=True,cache=True)
def process_orders_parallel(orders,p):
    B,n=orders.shape
    seqs=np.empty((B,n),np.int16); cs=np.empty(B,np.int64)
    for r in prange(B):
        s,c,e=construct_neh(orders[r],p,0)
        for j in range(n): seqs[r,j]=s[j]
        cs[r]=c
    return seqs,cs


def generate_pool_parallel(p,size,seed,batch=2000):
    n=p.shape[0]; rng=np.random.default_rng(seed)
    seqs=np.empty((size,n),np.int16); cs=np.empty(size,np.int64)
    t=time.perf_counter(); done=0
    while done<size:
        b=min(batch,size-done)
        # argsort random keys gives independent random permutations.
        orders=np.argsort(rng.random((b,n)),axis=1).astype(np.int64)
        ss,cc=process_orders_parallel(orders,p)
        seqs[done:done+b]=ss;cs[done:done+b]=cc;done+=b
        print(f'pool {done}/{size} best={int(cs[:done].min())} mean={float(cs[:done].mean()):.1f}',flush=True)
    return seqs,cs,time.perf_counter()-t


def insertion_descent_py(seq,p,max_passes=10):
    seq=seq.copy(); cur=int(cmax_seq(seq,p)); evals=0; moves=0; passes=0
    for _ in range(max_passes):
        moved=False
        # first-improvement pass in current sequence order, objective only
        jobs=seq.copy()
        for job in jobs:
            cand,cc,e,oldp,newp=strict_best_reinsert_py(seq,int(job),p,2); evals+=e
            if cc<cur:
                seq=cand;cur=cc;moves+=1;moved=True
        passes+=1
        if not moved:break
    return seq,cur,evals,moves,passes


def run_method(name,fn):
    t=time.perf_counter(); res=fn(); elapsed=time.perf_counter()-t
    seq=np.asarray(res[0],dtype=np.int64); c=int(res[1])
    assert len(seq)==len(np.unique(seq))==p.shape[0]
    assert c==int(cmax_seq(seq,p))
    return {'method':name,'cmax':c,'sequence':seq.tolist(),'time_sec':elapsed,'extra':list(res[2:])}

if __name__=='__main__':
    set_num_threads(min(16,get_num_threads()))
    inst=parse_instances(DATA)[0]; p=inst['p']; ub=int(inst['ub']); lb=int(inst['lb'])
    print('instance',inst['seed'],ub,lb,'threads',get_num_threads(),flush=True)
    # JIT warmup.
    o=tpt_order(p); _=construct_neh(o,p,0); _=process_orders_parallel(np.stack([o,o]),p)

    pool_size=40000; pool_seed=291200201
    seqs,cs,pool_sec=generate_pool_parallel(p,pool_size,pool_seed,batch=2000)
    tm=time.perf_counter(); rules=prepare_rules(seqs,cs,kp=600,ka=0,stable_p=.05,stable_r=.03,regions=4); mining_sec=time.perf_counter()-tm
    P=rules['P'];R=rules['R']
    print('pool done',pool_sec,'mining',mining_sec,'best',cs.min(),'stability',rules['stability'],flush=True)

    tpt=tpt_order(p); kk=kk2_style_order(p)
    methods=[]
    methods.append(run_method('NEH',lambda: construct_neh(tpt,p,0)))
    methods.append(run_method('NEH-TBKK2',lambda: construct_neh(tpt,p,2)))
    methods.append(run_method('KK2-style-NEH',lambda: construct_neh(kk,p,2)))
    for pp in (1,2,3):
        methods.append(run_method(f'FRB4-p{pp}',lambda pp=pp: construct_frb4(tpt,p,pp,2)))
    methods.append(run_method('INEH-inspired-KK2+FRB4-p1',lambda: construct_frb4(kk,p,1,2)))
    methods.append(run_method('CM-NEH-TBKK2',lambda: construct_cm_tie(tpt,p,P,R)))
    for q in (2,4,6):
        methods.append(run_method(f'CM-FRB4-p1-q{q}',lambda q=q: construct_cm_frb4(tpt,p,P,R,1,q,False)))
    for q in (2,4,6):
        methods.append(run_method(f'CM-INEH-inspired-q{q}',lambda q=q: construct_cm_frb4(kk,p,P,R,1,q,True)))

    # Objective-focused portfolio: best raw candidate, then insertion descent from three best distinct methods.
    methods_sorted=sorted(methods,key=lambda x:(x['cmax'],x['time_sec']))
    best_three=methods_sorted[:3]
    for src in best_three:
        methods.append(run_method('INS-D from '+src['method'],lambda src=src: insertion_descent_py(np.array(src['sequence'],np.int64),p,10)))

    methods_sorted=sorted(methods,key=lambda x:(x['cmax'],x['time_sec']))
    for r in methods_sorted: print(r['method'],r['cmax'],r['time_sec'],r['extra'],flush=True)
    result={
      'problem':'Ta091','n':200,'m':20,'seed':int(inst['seed']),'reported_ub':ub,'reported_lb':lb,
      'pool':{'size':pool_size,'seed':pool_seed,'best':int(cs.min()),'mean':float(cs.mean()),'worst':int(cs.max()),'sec':pool_sec,'mining_sec':mining_sec,
              'elite_n':int(rules['elite_n']),'poor_n':int(rules['bad_n']),'P_pearson':float(rules['stability']['P'][0]),'P_spearman':float(rules['stability']['P'][1]),
              'R_pearson':float(rules['stability']['R'][0]),'R_spearman':float(rules['stability']['R'][1]),'top_precedence':600,'regions':4},
      'protocol':{
        'pool_rule':'S=10*n*m=40000 randomized-order NEH schedules',
        'elite_frac':0.05,'poor_frac':0.20,'P_R_weights':'0.65/0.35','adjacency':'not used',
        'FRB4':'after each insertion, reinsert p jobs before and after the inserted position; strict Cmax improvement',
        'CM_FRB4':'FRB4-p1 plus q highest P+R contrast-violation jobs; strict Cmax improvement',
        'NEH_TBKK2':'TPT order with published TBKK2 first/last exact-tie rule',
        'KK2_style':'Johnson-style weighted order built from published TBKK2 fictitious weights; not claimed as verbatim PRKK2',
        'INEH_inspired':'KK2-style order + FRB4-p1; not claimed as verbatim published INEH (which uses NNEH alpha=0.1)',
        'CM_INEH_inspired':'INEH-inspired construction plus CM exact-tie guidance and CM violation reinsertion',
        'post_improvement':'objective-only insertion descent from the three best raw candidates'
      },
      'methods':methods,
      'ranking':[{'rank':i+1,'method':r['method'],'cmax':r['cmax'],'gap_ub':r['cmax']-ub,'rpd_ub':100*(r['cmax']-ub)/ub,'time_sec':r['time_sec']} for i,r in enumerate(methods_sorted)]
    }
    (OUT/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    np.savez_compressed(OUT/'mining_summary.npz',cmax=cs)
    print('saved',OUT/'results.json',flush=True)
