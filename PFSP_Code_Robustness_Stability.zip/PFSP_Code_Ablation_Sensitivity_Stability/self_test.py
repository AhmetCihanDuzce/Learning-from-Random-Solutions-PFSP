#!/usr/bin/env python3
from pathlib import Path
import csv, os, shutil, subprocess, sys, tempfile
root=Path(__file__).resolve().parent
core=root/'core'
tmp=Path(tempfile.mkdtemp(prefix='pfsp_interim_selftest_'))
try:
    s3=tmp/'s3'; s4=tmp/'s4'; s5=tmp/'s5'
    subprocess.run([sys.executable,str(core/'ablation_ablation_runner_HISTCOMPAT.py'),'--problem','Ta20_5_1','--rep','1','--outdir',str(s3)],cwd=core,check=True)
    subprocess.run([sys.executable,str(core/'weight_sensitivity_weight_sensitivity_runner.py'),'--problem','Ta20_5_1','--rep','1','--outdir',str(s4)],cwd=core,check=True)
    env=os.environ.copy(); env['PFSP_ofat_robustness_OUTDIR']=str(s5)
    subprocess.run([sys.executable,str(core/'ofat_robustness_ofat_runner_PORTABLE.py'),'Ta20_5_1:1'],cwd=core,env=env,check=True)
    checks=[(s3/'ablation_pr_regression_audit.csv',10),(s4/'ablation_pr_regression_audit.csv',10),(s5/'ofat_robustness_baseline_regression_audit.csv',10)]
    for path,n in checks:
        rows=list(csv.DictReader(path.open(newline='',encoding='utf-8')))
        assert len(rows)==n, (path,len(rows),n)
        assert all(str(r['Pass']).lower()=='true' for r in rows), path
    print('SELF_TEST_PASS: ablation analysis, weight-sensitivity analysis and OFAT-robustness analysis historical baseline gates passed for Ta20_5_1 rep1.')
finally:
    shutil.rmtree(tmp,ignore_errors=True)
