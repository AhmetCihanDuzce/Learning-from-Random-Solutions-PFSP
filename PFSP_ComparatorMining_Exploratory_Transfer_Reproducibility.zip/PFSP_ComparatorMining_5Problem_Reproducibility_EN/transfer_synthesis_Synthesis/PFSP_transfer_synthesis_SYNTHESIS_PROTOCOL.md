# PFSP transfer synthesis — Integrated Statistical Synthesis Protocol

**Status: FROZEN SYNTHESIS; no new performance experiments or inferential tests.**

## Purpose
transfer synthesis consolidates the already completed QA-GREEN analysis phase 9A and exploratory transfer analysis analyses and the explicitly exploratory transfer experiment 01–9B.16 comparator-integration follow-ups into a manuscript-ready evidence hierarchy. It does not re-tune any method, select new benchmark instances, or create new statistical hypotheses.

## Evidence hierarchy
1. **Primary/confirmatory context:** exploratory transfer analysis native 28-problem panel, inferential unit = problem, 12 methods kept separate.
2. **Primary reproducibility audit:** analysis phase 9A structural stability and output variability, inferential unit = problem.
3. **Secondary diagnostic:** common deterministic LS panel from exploratory transfer analysis.
4. **Exploratory mechanism evidence:** transfer experiment 01–9B.16 selected difficult-instance comparator integrations. All failed and successful variants are retained in the lineage table.
5. **Pending independent cost evidence:** analysis phase 2 runtime benchmark; not used to alter transfer synthesis solution-quality conclusions.

## Reporting rules
- Native exploratory transfer analysis is the primary absolute-quality comparison.
- No best-of-10 guided portfolio is created.
- QIG/Q-NEH superiority in the 28-problem panel is reported without qualification or concealment.
- The five-problem transfer exercise is labeled *targeted exploratory evidence*. Mechanisms may be scale/architecture specific and are not presented as one universal algorithm.
- Budget accounting is displayed row-by-row. Equal-online and amortized equal-total evidence must not be conflated.
- Strict H=10 accounting is summarized separately.
- Failed exploratory variants are disclosed in Supplementary lineage material.

## Frozen manuscript allocation
- Main text: condensed analysis phase 9A table; exploratory transfer analysis 12-method table; compact exploratory transfer table with explicit caveats.
- Supplementary: complete inferential tables, common-LS diagnostic, strict H=10 audit, and full exploratory lineage.
