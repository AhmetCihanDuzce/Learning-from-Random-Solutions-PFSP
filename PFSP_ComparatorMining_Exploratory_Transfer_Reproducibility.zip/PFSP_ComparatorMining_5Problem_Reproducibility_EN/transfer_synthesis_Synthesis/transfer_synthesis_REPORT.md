# PFSP transfer synthesis — Integrated Statistical Synthesis

**MASTER QA: GREEN**

transfer synthesis performs no new optimization runs and no new inferential testing. It freezes how the completed analysis phase 9 evidence should be presented in the manuscript and Supplementary Material.

## 1. Reproducibility and mining-mode interpretation
analysis phase 9A shows high reproducibility under both mining modes. Contrast has higher P-support overlap and P/R rank/shape agreement, while Elite-only has lower absolute R-score MAE. Contrast also has modestly lower output variability (CV and relative range), but the effect is not uniform across host heuristic families. Therefore the manuscript should state that Contrast is generally more reproducible in support/ranking/region choice, **not** that it dominates every stability measure.

## 2. Absolute solution quality under the primary 28-problem comparator panel
The frozen native 12-method panel gives Friedman chi-square=247.005 (df=11, p=1.18e-46), Kendall W=0.802. QIG is first (mean problem RPD 0.2644%, average rank 1.071) and Q-NEH second (1.9124%, rank 2.000). The strongest mined guided heuristic is FRB4-p1|Contrast (2.6541%, rank 4.107). All 10 guided variants are worse than QIG on all 28 problem-level means, and only FRB4-p1|Elite beats Q-NEH on any frozen problem-level means (2/28). This is the primary absolute-quality result and must remain explicit.

## 3. What the exploratory transfer experiments add
The follow-up experiments ask a different question: whether the **mined information itself** can help the two stronger comparators when inserted through architecture-compatible interfaces. Across the five targeted difficult instances, an exploratory favorable interface was found for the mean performance of both QIG and Q-NEH on all five instances. This is descriptive mechanism evidence, not a confirmatory 5/5 benchmark claim.

For QIG, n=50 benefited from a reusable mined FRB4-p1|Contrast warm start under equal online time, whereas the three larger targets benefited from reusable Contrast-P soft destruction bias under H=10 amortized equal-total accounting. For Q-NEH, n=50 benefited from a Contrast-P Q-table order prior under equal online time; Ta100_20_1 and VFR100_40_10 benefited from optimized near-tie Contrast-P under H=10 accounting; Ta100_20_10 required the already-defined order-prior + near-tie combination and remained favorable in the strict H=10 audit.

## 4. Critical cost boundary
A separate strict H=10 table prevents overstatement. Under uniform amortized equal-total accounting, QIG has favorable problem-mean deltas on **3/5** targets and Q-NEH on **4/5**. The mean of the five problem-level deltas is +0.0179 pp for QIG and +0.0130 pp for Q-NEH, both slightly baseline-favoring because the n=50 Ta50_20_1 loss is comparatively large. Therefore the paper must **not** claim 5/5 strict end-to-end superiority.

The defensible conclusion is that mined structural information can improve the search behavior of strong comparators on selected hard instances, but the net benefit depends on the integration interface, problem scale, and whether offline mining cost can be amortized.

## 5. Recommended main-text claim
> The external-comparator analysis showed that QIG and Q-NEH remained substantially stronger than the guided NEH-family heuristics in absolute solution quality. A targeted exploratory follow-up nevertheless indicated that the mined structural information was not restricted to those heuristic architectures. When injected through architecture-compatible low-intervention interfaces, mined information improved the mean performance of both comparators on each of five selected difficult instances under the corresponding matched-online or amortized-budget test. The effective interface was scale- and architecture-dependent, and strict H=10 accounting did not yield universal superiority; hence these results are interpreted as evidence of reusable structural knowledge rather than as a new state-of-the-art algorithm claim.

## 6. Main manuscript tables
- **Table M1:** condensed structural reproducibility + output repeatability.
- **Table M2:** native 12-method comparator ranking across 28 problems.
- **Table M3:** five-problem exploratory knowledge transfer, with mechanism and budget accounting explicitly shown.

## 7. Supplementary tables
Full structural inference, output variability/family heterogeneity, 20 external contrasts, common-LS diagnostics, strict H=10 cost audit, and the complete transfer experiment 01–9B.16 lineage (including failed variants) should be retained in Supplementary Material.

## 8. analysis phase 2 dependency
analysis phase 2 runtime results are independent of the analysis phase 9 solution-quality inference. When available, they should be added as a separate computational-cost table and used to qualify the practical amortization discussion; they should not be used to re-select or re-interpret analysis phase 9 methods.
