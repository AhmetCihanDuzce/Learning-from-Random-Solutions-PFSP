from __future__ import annotations
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
required=[
 'PFSP_external_comparator_FINAL_280of280_GREEN.zip',
 'pfsp_single_tmp/PFSP_Pure_Python_Single_Instance/run_pfsp_single.py',
 'PFSP_transfer10_N50_BestArchivedFRB4_WarmStart/transfer10_runner.py',
 'PFSP_transfer05_QIG_Reusable_H10_All5/transfer05_runner.py',
 'PFSP_transfer12_QNEH_OptimizedNearTie/transfer12_runner.py',
 'PFSP_transfer14_QNEH_N50_POrderPrior/transfer14_runner.py',
 'PFSP_transfer16_QNEH_N100_CombinedPriorNearTie/transfer16_runner.py',
 'transfer_synthesis_Synthesis/transfer_synthesis_table3_exploratory_selected_interface_transfer.csv',
 'transfer_synthesis_Synthesis/transfer_synthesis_table4_strict_H10_budget_audit.csv',
]
missing=[x for x in required if not (ROOT/x).exists()]
qa_files=[
 'PFSP_transfer05_QIG_Reusable_H10_All5/transfer05_MASTER_QA.json',
 'PFSP_transfer10_N50_BestArchivedFRB4_WarmStart/transfer10_MASTER_QA.json',
 'PFSP_transfer12_QNEH_OptimizedNearTie/transfer12_MASTER_QA.json',
 'PFSP_transfer14_QNEH_N50_POrderPrior/transfer14_MASTER_QA.json',
 'PFSP_transfer16_QNEH_N100_CombinedPriorNearTie/transfer16_MASTER_QA.json',
]
qa=[]
for q in qa_files:
    p=ROOT/q
    if not p.exists(): qa.append((q,'MISSING'))
    else: qa.append((q,json.loads(p.read_text()).get('status')))
manifest=ROOT/'SHA256SUMS.txt'
manifest_bad=[]
if manifest.exists():
    for line in manifest.read_text().splitlines():
        if not line.strip(): continue
        h,rel=line.split('  ',1); p=ROOT/rel
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h: manifest_bad.append(rel)
else: manifest_bad.append('SHA256SUMS.txt missing')
print('Required files:', 'OK' if not missing else f'MISSING {missing}')
print('QA:', qa)
print('Manifest:', 'OK' if not manifest_bad else f'FAILED {manifest_bad[:10]}')
if missing or any(s!='GREEN' for _,s in qa) or manifest_bad: raise SystemExit(1)
print('PACKAGE STATUS: GREEN')
