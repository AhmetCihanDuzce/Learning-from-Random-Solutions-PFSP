# PFSP Comparator-Mining Five-Problem Reproducibility Package

## Purpose

This package reproduces the exploratory follow-up question:

> Can structural information mined from random PFSP solution pools improve two strong learning-based comparators, QIG and Q-NEH, on five targeted difficult instances?

The five instances are:

- `Ta50_10_1`
- `Ta50_20_1`
- `Ta100_20_1`
- `Ta100_20_10`
- `VFR100_40_10`

This is an **exploratory transfer study**, not a claim that a single universal mining interface dominates QIG or Q-NEH. Different low-intervention interfaces were investigated because the two comparators have different internal decision structures and because short `n=50` budgets behave differently from the larger cases.

## Main reproducibility finding

Using the selected architecture-compatible interfaces, the mean solution quality was improved on all five targeted instances for both comparators under the evaluation mode used for the selected-interface demonstration. When reusable mining cost is charged under the strict `H=10` accounting audit, the favorable mean is retained on 3/5 QIG cases and 4/5 Q-NEH cases. The strict audit therefore does **not** support a universal end-to-end 5/5 claim.

See `transfer_synthesis_Synthesis/` and the separate Supplementary Material package for the final tables and the full exploratory lineage.

## Package layout

- `PFSP_transfer01_...` through `PFSP_transfer16_...`: the complete exploratory analysis phase lineage, including code, frozen protocols, cached mined structures where applicable, reference outputs, summaries, and QA files.
- `pfsp_single_tmp/PFSP_Pure_Python_Single_Instance/`: the frozen pure-Python PFSP pool/mining core used by the follow-up code.
- `PFSP_external_comparator_FINAL_280of280_GREEN.zip`: the frozen external-comparator analysis comparator/reference package used for budgets, archived schedules, and provenance.
- `transfer_synthesis_Synthesis/`: integrated final synthesis tables and provenance notes.
- `requirements.txt`: tested Python dependencies.
- `TESTED_ENVIRONMENT.md`: tested software stack and timing reproducibility caveat.
- `RUN_ORDER.md`: exact run order for the full lineage and for the selected-interface reproduction.
- `DATA_DICTIONARY.md`: definitions of the principal result fields.
- `make_clean_selected_rerun.py`: creates a clean copy in which the selected final analyses can be rerun instead of skipped because archived JSON files already exist.
- `verify_package.py`: verifies package integrity and the presence/status of the principal QA assets.
- `SHA256SUMS.txt`: package-level SHA-256 manifest.

## Installation

Python 3.13 was used for the archived runs. From the package root:

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
```

## Verify the archived package

```bash
python verify_package.py
```

The verifier checks required files, the package manifest, and the principal GREEN QA records.

## Quick reproduction of the selected interfaces

The analysis phase folders contain archived outputs. The original runners intentionally skip completed JSON files. To obtain a clean rerun workspace:

```bash
python make_clean_selected_rerun.py --dest ./rerun_selected
cd rerun_selected
```

Then execute the five selected-analysis phase runners in the order shown in `RUN_ORDER.md`.

## Important timing note

QIG and Q-NEH are stopped by **wall-clock time**, not by a fixed number of iterations. The RNG seed therefore fixes stochastic draws only conditional on the amount of search executed. Different CPUs, operating systems, Python/NumPy/Numba builds, or background load can change the number of completed episodes and consequently the final Cmax. The archived JSON/CSV files are the reference outputs used in the manuscript. Reproduction on another machine should focus on protocol, seed, accounting logic, validity checks, and qualitative effect rather than expecting bit-identical time-budgeted outcomes.

## Mining-cost accounting

Three accounting modes appear in the exploratory lineage:

1. **Equal online time**: baseline and mining-informed comparator receive the same online search time; mining/archive construction is reported separately.
2. **Fresh end-to-end**: fresh mining cost is charged to the mining-informed method in the same run.
3. **Reusable H=10 accounting**: a previously mined structural object is reused across ten comparator runs; one tenth of the mining cost is charged per run.

The final Supplementary Material keeps these modes separate. They must not be conflated.

## Reproducibility and reporting scope

The complete unsuccessful and intermediate attempts are retained in the exploratory transfer analysis lineage. This is intentional. The package documents the development path rather than publishing only favorable combinations.
