# PFSP exploratory transfer analysis.2c — VFR100_40_10 Strict End-to-End Audit

Status: FROZEN BEFORE EXECUTION.
Nature: exploratory follow-up permitted by the transfer experiment 02 frozen protocol after directional holdout benefit.

## Fixed target and variant
- Problem: VFR100_40_10 only.
- Variant: QIG + Contrast-P soft bias, always guidance, lambda = 0.25 (`always_l025`).
- Replications: the same frozen external-comparator analysis replications r=1..5 and seeds.
- No further tuning or variant selection is allowed in this audit.

## Equal end-to-end budget
For each replication r:
- `G8_r` is the frozen external-comparator analysis online budget.
- `T_off_r` is the fresh Contrast-P mining wall time already measured in the transfer experiment 02 holdout for the same problem/replication.
- Equal total budget: `B_r = T_off_r + G8_r`.
- Unguided QIG receives `B_r` seconds of online search.
- Guided QIG pays `T_off_r` for mining and receives `G8_r` seconds of online search; the already completed transfer experiment 02 `always_l025` guided run is reused because it used the identical seed, P matrix, and `G8_r` online budget.

Thus both alternatives are charged the same end-to-end time budget; fresh mining time is not amortized.

## Outcome
Primary paired outcome is Delta RPD = RPD_guided - RPD_baseline_extended, so negative favors mining-guided QIG.
Report per-replication Cmax/RPD, paired W/T/L, mean and median Delta RPD, and budget arithmetic.

## Interpretation restriction
This is an exploratory single-instance strict-budget audit. It cannot establish general superiority. exploratory transfer analysis confirmatory comparator conclusions remain primary.
