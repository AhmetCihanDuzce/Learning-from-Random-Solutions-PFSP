# PFSP transfer experiment 02 — QIG Contrast-P Soft-Bias Rescue Pilot

Status: FROZEN BEFORE EXECUTION of transfer experiment 02 variants.
Nature: exploratory mechanism-development experiment. It does not replace the confirmatory exploratory transfer analysis results.

## Motivation
exploratory transfer analysis.1b produced a limited but directional signal for QIG+Contrast P/R under equal online time, while the strict end-to-end test showed that fresh mining cost erased that gain. transfer experiment 02 therefore tests whether a less intrusive use of the mined information can improve QIG search behavior without altering its Q-learning state/action mechanism, acceptance rule, local search, or destruction-size policy.

## Development problems and replications
Development set (fixed before observing any transfer experiment 02 result):
- Ta50_10_1
- Ta50_20_1
- Ta100_20_1

Replications: external-comparator analysis replications 1–3 only (R=3), using the frozen external-comparator analysis seed manifest and the frozen external-comparator analysis online budget G8(k,r).

The unguided online-matched QIG baselines are reused from the completed exploratory transfer analysis.1b audit for these identical problem/seed/budget combinations.

## Frozen guidance source
Only the **Contrast precedence matrix P_C** mined under the existing frozen protocol is used.
- Pool size: S = 10,000 n.
- Elite: best 5%; Poor: worst 10%.
- P rules: top 3n precedence relations by absolute contrast score.
- Region information R is NOT used in transfer experiment 02.

Thus transfer experiment 02 is a Contrast-P-only study.

## Soft-bias mechanism
The original QIG chooses destruction size d in {1,2,3} through its existing Q-learning mechanism. transfer experiment 02 does not alter d.

For the current incumbent sequence, each job receives a P-only violation score: for each positive P_C(i,j) rule violated by the current order (i occurs after j), P_C(i,j) is added to both jobs' violation scores.

When guidance is active, the d destruction jobs are sampled without replacement from the incumbent sequence using

p_j = (1-lambda)/n + lambda * v_j / sum(v),

where v_j is the nonnegative P-only violation score. If all v_j are zero, selection is uniform. This leaves every job with positive selection probability and therefore acts as a soft bias rather than a hard structural filter.

All remaining QIG mechanisms are frozen: NEH initialization, insertion local search, Q-learning state/action definition, epsilon schedule, destruction size, greedy reconstruction, SA-style acceptance, reward, and deadlines.

## Frozen development grid
P-only is fixed, leaving exactly four variants (the earlier informal note saying eight was an arithmetic slip):
1. Always guidance, lambda = 0.25
2. Always guidance, lambda = 0.50
3. Stagnation-triggered guidance, lambda = 0.25
4. Stagnation-triggered guidance, lambda = 0.50

For stagnation-triggered variants, guidance activates after 10 consecutive completed episodes without a new global best and remains active until a new global best is found; the stagnation counter then resets to zero.

## Development comparison and selection rule
Primary development criterion is the paired RPD change versus the online-matched unguided QIG baseline at the identical problem, replication, seed, and G8 online budget:
Delta RPD = RPD_variant - RPD_QIG, so negative is better.

Across the 9 development pairs, variants are ordered by:
1. lowest mean Delta RPD;
2. if tied, larger number of wins;
3. if still tied, lower lambda;
4. if still tied, stagnation-triggered before always (less intervention).

The top two variants are promoted automatically. No significance test is used for tuning.

## Frozen holdout set
The holdout problems are fixed before development execution:
- Ta100_20_10 — the next-worst non-development Taillard QIG case in exploratory transfer analysis.
- VFR100_40_10 — the worst non-development VFR QIG case in exploratory transfer analysis.

Each promoted variant is evaluated with external-comparator analysis replications 1–5 (R=5) using the same frozen G8 online budget. A fresh Contrast-P mining operation is performed once per problem/replication and its wall time is recorded separately.

For the holdout mechanism test, unguided QIG is rerun at the identical G8 online budget. Report paired W/T/L, mean and median Delta RPD, and per-problem results.

## Time-budget interpretation
The development and holdout tests in transfer experiment 02 are **online-time-matched mechanism tests**. Fresh mining wall time is measured and reported separately; therefore these results cannot by themselves support an end-to-end superiority claim.

A strict end-to-end follow-up is permitted only after the holdout is complete and only for a promoted variant that shows a directional holdout benefit. In that audit the unguided baseline must receive B = T_offline + G8 seconds while the guided method receives G8 online seconds after paying T_offline.

## Reporting restrictions
- transfer experiment 02 is exploratory and must be labeled as such.
- All four development variants must be reported, not only the winner.
- Holdout problems must not be changed after development results are observed.
- exploratory transfer analysis confirmatory external-comparator conclusions remain primary.
