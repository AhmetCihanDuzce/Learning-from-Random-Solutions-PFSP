# transfer experiment 02 Report — QIG Contrast-P Soft-Bias Rescue Pilot

## Status
Development, holdout, and permitted strict VFR end-to-end follow-up completed. All saved permutation/Cmax QA checks are GREEN.

## Development selection
Four frozen Contrast-P-only soft-bias variants were tested on Ta50_10_1, Ta50_20_1, and Ta100_20_1 with R=3. The top two promoted variants were `always_l025` and `always_l050`.

## Holdout mechanism results (equal online time)
- Ta100_20_10, always_l025: mean Delta RPD +0.06217; W/T/L 3/0/2.
- Ta100_20_10, always_l050: mean Delta RPD -0.15542; W/T/L 4/0/1.
- VFR100_40_10, always_l025: mean Delta RPD -0.24396; median -0.23893; W/T/L 4/0/1.
- VFR100_40_10, always_l050: mean Delta RPD +0.04276; median +0.12575; W/T/L 2/0/3.
- Across both holdouts, always_l025: mean Delta RPD -0.09090; W/T/L 7/0/3.
- Across both holdouts, always_l050: mean Delta RPD -0.05633; W/T/L 6/0/4.

Negative Delta RPD favors guided QIG.

## VFR strict end-to-end follow-up
Target: VFR100_40_10, `always_l025` only, R=5.
Equal total budget per replication: B = fresh mining wall time + frozen G8 online budget.
Unguided QIG received B seconds online; guided QIG paid mining time and retained G8 online time.

Result:
- mean guided RPD: 0.31690%
- mean extended-baseline RPD: 0.31942%
- mean Delta RPD: -0.00252 percentage points
- median Delta RPD: +0.13833 percentage points
- W/T/L: 2/0/3
- mean fresh mining wall time: 64.2276 s
- mean equal total budget: 90.4935 s

Interpretation: Contrast-P soft bias improved QIG search behavior on VFR100_40_10 when online time was held equal, but the gain was almost exactly erased when fresh mining cost was charged under a strict equal end-to-end budget. This is an exploratory single-instance result and does not alter the primary exploratory transfer analysis conclusions.
