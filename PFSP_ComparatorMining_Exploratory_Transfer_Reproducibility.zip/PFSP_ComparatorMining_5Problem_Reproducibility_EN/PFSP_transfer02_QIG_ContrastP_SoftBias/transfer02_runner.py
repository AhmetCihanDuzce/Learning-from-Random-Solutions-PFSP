from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys, json, time, math, csv
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
OLD=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(OLD))
import transfer01_runner as r
from external_comparator_comparators import cmax_numba, best_insert_ff, insert_at, remove_job, neh_ff, validate_permutation
from run_pfsp_single import pfsp_cmax

DEV=['Ta50_10_1','Ta50_20_1','Ta100_20_1']
DEV_REPS=range(1,4)
HOLD=['Ta100_20_10','VFR100_40_10']
HOLD_REPS=range(1,6)
VARIANTS=[
    ('always_l025','always',0.25),
    ('always_l050','always',0.50),
    ('stagnation10_l025','stagnation10',0.25),
    ('stagnation10_l050','stagnation10',0.50),
]

def p_violation(seq,P):
    seq=np.asarray(seq,dtype=np.int64); n=P.shape[0]
    pos=np.empty(n,dtype=np.int64); pos[seq]=np.arange(seq.size,dtype=np.int64)
    v=np.zeros(n,dtype=float)
    ii,jj=np.where(P>0)
    for i,j in zip(ii.tolist(),jj.tolist()):
        if pos[i]>pos[j]:
            w=float(P[i,j]); v[i]+=w; v[j]+=w
    return v

def qig_soft_p(p,seed,time_limit_sec,P,lam,trigger,tau=.7,epsilon=.8,beta=.996,alpha=.6,gamma=.8,E=6,eta=.3,max_ls_passes=100):
    n,m=p.shape; rng=np.random.default_rng(seed); start=time.perf_counter(); deadline=start+float(time_limit_sec)
    seq,_=neh_ff(p); best_seq=seq.copy(); best_c=int(cmax_numba(seq,p))
    seq,curr_c,init_passes,_=r.insertion_local_search_deadline(seq,p,rng,deadline,max_ls_passes)
    if curr_c<best_c: best_c=int(curr_c); best_seq=seq.copy()
    Q=np.zeros((2,3),dtype=float); state=0; d=int(rng.integers(1,4)); temp=float(tau)*float(p.sum())/float(n*m*10.0)
    episodes=iterations=accepts=0; eps=float(epsilon); guided_destructions=0; total_destructions=0; stagnation=0
    while time.perf_counter()<deadline:
        Cprev=int(curr_c); Cbest_prev=int(best_c); C_ep=int(curr_c); used_d=d
        active = (trigger=='always') or (trigger=='stagnation10' and stagnation>=10)
        for _ in range(E):
            if time.perf_counter()>=deadline: break
            iterations+=1; total_destructions+=1
            if active:
                v=p_violation(seq,P); sv=float(v.sum())
                if sv>0:
                    probs=(1.0-float(lam))/float(n) + float(lam)*(v[seq]/sv)
                    probs=probs/float(probs.sum())
                    idxs=rng.choice(seq.size,size=d,replace=False,p=probs); guided_destructions+=1
                else:
                    idxs=rng.choice(seq.size,size=d,replace=False)
            else:
                idxs=rng.choice(seq.size,size=d,replace=False)
            removed=seq[idxs].copy(); keepmask=np.ones(seq.size,dtype=bool); keepmask[idxs]=False
            partial=seq[keepmask].copy(); partial,_,_,_=r.insertion_local_search_deadline(partial,p,rng,deadline,max_ls_passes)
            if time.perf_counter()>=deadline: break
            cand=partial
            for job in removed:
                if time.perf_counter()>=deadline: break
                pos,_,_,_=best_insert_ff(cand,int(job),p); cand=insert_at(cand,int(job),pos)
            if cand.size!=n or time.perf_counter()>=deadline: break
            cand,cand_c,_,_=r.insertion_local_search_deadline(cand,p,rng,deadline,max_ls_passes)
            accept=cand_c<=curr_c
            if not accept and temp>0: accept=rng.random()<math.exp((float(curr_c)-float(cand_c))/temp)
            if accept:
                seq=cand; curr_c=int(cand_c); accepts+=1
                if curr_c<C_ep:C_ep=curr_c
            if cand_c<best_c: best_c=int(cand_c); best_seq=cand.copy()
            if time.perf_counter()>=deadline: break
        rlocal=max(Cprev-C_ep,0)/float(Cprev); rglobal=max(Cbest_prev-best_c,0)/float(Cbest_prev)
        reward=eta*rlocal+(1-eta)*rglobal; improved=best_c<Cbest_prev; new_state=1 if improved else 0
        Q[state,used_d-1]+=alpha*(reward+gamma*float(np.max(Q[new_state]))-Q[state,used_d-1])
        eps*=beta; d=(int(np.argmax(Q[new_state]))+1) if rng.random()>=eps else int(rng.integers(1,4)); state=new_state; episodes+=1
        stagnation=0 if improved else stagnation+1
    elapsed=time.perf_counter()-start
    return {'algorithm':'QIG+ContrastP-soft','seed':seed,'cmax':int(best_c),'seq':best_seq,'elapsed_sec':elapsed,
            'episodes':episodes,'iterations':iterations,'accepts':accepts,'guided_destructions':guided_destructions,
            'total_destructions':total_destructions,'guided_fraction':guided_destructions/max(1,total_destructions),
            'init_ls_passes':init_passes,'lambda':float(lam),'trigger':trigger,'stagnation_final':stagnation}

def qa(res,p,n):
    return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))

def get_online_dev_baseline(pid,rep):
    _,ordn=r.seed_for(pid,rep)
    f=OLD/'online_matched_baseline'/f'{ordn:02d}_{pid}_r{rep:02d}.json'
    d=json.loads(f.read_text())
    return int(d['QIG']['cmax']), float(d['QIG']['elapsed_sec']), float(d['g8_sec'])

def mine_cache(pid,rep,seed,p):
    cache=HERE/'cache'/f'{pid}_r{rep:02d}_PC.npz'
    if cache.exists():
        z=np.load(cache); return z['PC'], float(z['offline_sec']), json.loads(str(z['stats_json']))
    PE,RE,PC,RC,off,stats=r.mine(pid,rep,seed,p)
    np.savez_compressed(cache,PC=PC,offline_sec=np.array(off),stats_json=np.array(json.dumps(stats)))
    return PC,float(off),stats

def run_dev():
    r.warmup(); outdir=HERE/'development'; outdir.mkdir(exist_ok=True)
    for pid in DEV:
      for rep in DEV_REPS:
        seed,ordn=r.seed_for(pid,rep); row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid)
        base_c,base_elapsed,g8=get_online_dev_baseline(pid,rep)
        PC,off,stats=mine_cache(pid,rep,seed,p)
        rec=[]
        for name,trig,lam in VARIANTS:
            fn=outdir/f'{ordn:02d}_{pid}_r{rep:02d}_{name}.json'
            if fn.exists():
                d=json.loads(fn.read_text()); rec.append(d); print('SKIP',pid,rep,name,flush=True); continue
            print('START',pid,rep,name,'G8',g8,flush=True)
            rr=qig_soft_p(p,seed,g8,PC,lam,trig); ok=qa(rr,p,n)
            d={'status':'GREEN' if ok else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,
               'g8_sec':g8,'offline_reconstruction_sec':off,'baseline_cmax':base_c,'baseline_elapsed_sec':base_elapsed,
               'variant':name,'trigger':trig,'lambda':lam,'cmax':int(rr['cmax']),'rpd':100*(rr['cmax']-ub)/ub,
               'baseline_rpd':100*(base_c-ub)/ub,'delta_rpd':100*(rr['cmax']-base_c)/ub,'elapsed_sec':float(rr['elapsed_sec']),
               'qa':ok,'details':{k:v for k,v in rr.items() if k not in ('seq','cmax','elapsed_sec')}}
            fn.write_text(json.dumps(d,indent=2),encoding='utf-8'); rec.append(d)
            print('DONE',pid,rep,name,'cmax',d['cmax'],'delta_rpd',d['delta_rpd'],flush=True)

def summarize_dev():
    data=[]
    for f in sorted((HERE/'development').glob('*.json')): data.append(json.loads(f.read_text()))
    assert len(data)==len(DEV)*len(DEV_REPS)*len(VARIANTS),len(data)
    rows=[]
    for name,trig,lam in VARIANTS:
        z=[x for x in data if x['variant']==name]
        ds=np.array([x['delta_rpd'] for x in z],dtype=float)
        w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        rows.append({'variant':name,'trigger':trig,'lambda':lam,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),
                     'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,
                     'mean_guided_fraction':float(np.mean([x['details']['guided_fraction'] for x in z]))})
    trigger_order={'stagnation10':0,'always':1}
    rows.sort(key=lambda x:(x['mean_delta_rpd'],-x['wins'],x['lambda'],trigger_order[x['trigger']]))
    for i,x in enumerate(rows,1): x['rank']=i; x['promoted']=i<=2
    with open(HERE/'transfer02_development_summary.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    (HERE/'transfer02_selection.json').write_text(json.dumps({'selection_rule':'mean delta RPD, then wins, lower lambda, stagnation before always','ranked':rows,'promoted':[x['variant'] for x in rows[:2]]},indent=2),encoding='utf-8')
    return rows[:2]

def run_holdout(promoted):
    r.warmup(); outdir=HERE/'holdout'; outdir.mkdir(exist_ok=True)
    mp={x[0]:(x[1],x[2]) for x in VARIANTS}
    for pid in HOLD:
      for rep in HOLD_REPS:
        seed,ordn=r.seed_for(pid,rep); row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid); g8,_,_=r.external_comparator_max_guided(pid,rep)
        PC,off,stats=mine_cache(pid,rep,seed,p)
        basefile=outdir/f'{ordn:02d}_{pid}_r{rep:02d}_baseline.json'
        if basefile.exists(): base=json.loads(basefile.read_text())
        else:
            print('START HOLD BASE',pid,rep,'G8',g8,flush=True); rr=r.qig_deadline(p,seed,g8); ok=qa(rr,p,n)
            base={'status':'GREEN' if ok else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,'g8_sec':g8,
                  'offline_sec':off,'cmax':int(rr['cmax']),'rpd':100*(rr['cmax']-ub)/ub,'elapsed_sec':float(rr['elapsed_sec']),'qa':ok}
            basefile.write_text(json.dumps(base,indent=2),encoding='utf-8'); print('DONE HOLD BASE',pid,rep,base['cmax'],flush=True)
        for x in promoted:
            name=x['variant']; trig,lam=mp[name]; fn=outdir/f'{ordn:02d}_{pid}_r{rep:02d}_{name}.json'
            if fn.exists(): print('SKIP HOLD',pid,rep,name,flush=True); continue
            print('START HOLD',pid,rep,name,'G8',g8,flush=True); rr=qig_soft_p(p,seed,g8,PC,lam,trig); ok=qa(rr,p,n)
            d={'status':'GREEN' if ok else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,'g8_sec':g8,'offline_sec':off,
               'baseline_cmax':base['cmax'],'baseline_rpd':base['rpd'],'variant':name,'trigger':trig,'lambda':lam,'cmax':int(rr['cmax']),
               'rpd':100*(rr['cmax']-ub)/ub,'delta_rpd':100*(rr['cmax']-base['cmax'])/ub,'elapsed_sec':float(rr['elapsed_sec']),'qa':ok,
               'details':{k:v for k,v in rr.items() if k not in ('seq','cmax','elapsed_sec')}}
            fn.write_text(json.dumps(d,indent=2),encoding='utf-8'); print('DONE HOLD',pid,rep,name,d['cmax'],'delta',d['delta_rpd'],flush=True)

def summarize_holdout(promoted):
    rows=[]
    for pid in HOLD:
      for x in promoted:
        name=x['variant']; z=[json.loads(f.read_text()) for f in sorted((HERE/'holdout').glob(f'*_{pid}_r*_{name}.json'))]
        assert len(z)==5,(pid,name,len(z)); ds=np.array([a['delta_rpd'] for a in z])
        w=sum(a['cmax']<a['baseline_cmax'] for a in z); t=sum(a['cmax']==a['baseline_cmax'] for a in z); l=5-w-t
        rows.append({'problem':pid,'variant':name,'n_pairs':5,'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),
                     'wins':w,'ties':t,'losses':l,'mean_variant_rpd':float(np.mean([a['rpd'] for a in z])),
                     'mean_baseline_rpd':float(np.mean([a['baseline_rpd'] for a in z])),'mean_offline_sec':float(np.mean([a['offline_sec'] for a in z])),
                     'mean_online_sec':float(np.mean([a['elapsed_sec'] for a in z]))})
    for x in promoted:
      name=x['variant']; z=[json.loads(f.read_text()) for f in sorted((HERE/'holdout').glob(f'*_r*_{name}.json'))]
      ds=np.array([a['delta_rpd'] for a in z]); w=sum(a['cmax']<a['baseline_cmax'] for a in z); t=sum(a['cmax']==a['baseline_cmax'] for a in z); l=len(z)-w-t
      rows.append({'problem':'ALL_HOLDOUT','variant':name,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),
                   'wins':w,'ties':t,'losses':l,'mean_variant_rpd':float(np.mean([a['rpd'] for a in z])),
                   'mean_baseline_rpd':float(np.mean([a['baseline_rpd'] for a in z])),'mean_offline_sec':float(np.mean([a['offline_sec'] for a in z])),
                   'mean_online_sec':float(np.mean([a['elapsed_sec'] for a in z]))})
    with open(HERE/'transfer02_holdout_summary.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    return rows

def main():
    run_dev(); promoted=summarize_dev(); print('PROMOTED',[x['variant'] for x in promoted],flush=True); run_holdout(promoted); summarize_holdout(promoted); print('transfer02 COMPLETE',flush=True)
if __name__=='__main__': main()
