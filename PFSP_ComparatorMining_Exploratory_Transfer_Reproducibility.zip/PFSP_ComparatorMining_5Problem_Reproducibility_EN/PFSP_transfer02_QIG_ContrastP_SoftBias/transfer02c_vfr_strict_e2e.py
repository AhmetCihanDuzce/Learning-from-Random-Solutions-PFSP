from pathlib import Path
import json, csv, sys
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import transfer02_runner as s
r=s.r
PID='VFR100_40_10'; VAR='always_l025'
OUT=HERE/'strict_e2e_vfr'; OUT.mkdir(exist_ok=True)

def main():
    r.warmup()
    rows=[]
    for rep in range(1,6):
        seed,ordn=r.seed_for(PID,rep)
        row=r.load_manifest_row(r.PFSP_ROOT,PID); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(PID)
        gf=HERE/'holdout'/f'{ordn:02d}_{PID}_r{rep:02d}_{VAR}.json'
        guided=json.loads(gf.read_text())
        g8=float(guided['g8_sec']); off=float(guided['offline_sec']); B=g8+off
        bf=OUT/f'{ordn:02d}_{PID}_r{rep:02d}_baseline_extended.json'
        if bf.exists():
            base=json.loads(bf.read_text())
            print('SKIP',rep,base['cmax'],flush=True)
        else:
            print('START',rep,'B',B,'G8',g8,'OFF',off,flush=True)
            rr=r.qig_deadline(p,seed,B); ok=s.qa(rr,p,n)
            base={'status':'GREEN' if ok else 'RED','problem':PID,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,
                  'g8_sec':g8,'offline_sec':off,'equal_total_budget_sec':B,'cmax':int(rr['cmax']),
                  'rpd':100*(rr['cmax']-ub)/ub,'elapsed_sec':float(rr['elapsed_sec']),'qa':ok}
            bf.write_text(json.dumps(base,indent=2),encoding='utf-8')
            print('DONE',rep,base['cmax'],base['rpd'],base['elapsed_sec'],flush=True)
        delta=100*(int(guided['cmax'])-int(base['cmax']))/ub
        rows.append({'problem':PID,'rep':rep,'seed':seed,'reference_ub':ub,'g8_sec':g8,'offline_sec':off,'equal_total_budget_sec':B,
                     'baseline_extended_cmax':int(base['cmax']),'baseline_extended_rpd':float(base['rpd']),
                     'guided_cmax':int(guided['cmax']),'guided_rpd':float(guided['rpd']),'delta_rpd':delta,
                     'baseline_elapsed_sec':float(base['elapsed_sec']),'guided_online_elapsed_sec':float(guided['elapsed_sec']),
                     'guided_accounted_total_sec':off+float(guided['elapsed_sec']),'baseline_qa':bool(base['qa']),'guided_qa':bool(guided['qa'])})
    with open(HERE/'transfer02c_vfr_strict_e2e_raw.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    ds=np.array([x['delta_rpd'] for x in rows]);
    wins=sum(x['guided_cmax']<x['baseline_extended_cmax'] for x in rows); ties=sum(x['guided_cmax']==x['baseline_extended_cmax'] for x in rows); losses=5-wins-ties
    summary={'problem':PID,'variant':VAR,'n_pairs':5,'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),
             'wins':wins,'ties':ties,'losses':losses,'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in rows])),
             'mean_baseline_extended_rpd':float(np.mean([x['baseline_extended_rpd'] for x in rows])),
             'mean_offline_sec':float(np.mean([x['offline_sec'] for x in rows])),
             'mean_equal_total_budget_sec':float(np.mean([x['equal_total_budget_sec'] for x in rows])),
             'all_qa_green':all(x['baseline_qa'] and x['guided_qa'] for x in rows)}
    with open(HERE/'transfer02c_vfr_strict_e2e_summary.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(summary.keys())); w.writeheader(); w.writerow(summary)
    print('SUMMARY',json.dumps(summary,indent=2),flush=True)
if __name__=='__main__': main()
