from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys, csv, json, time, zipfile, math
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
PFSP_ROOT=(Path(__file__).resolve().parent.parent/'pfsp_single_tmp'/'PFSP_Pure_Python_Single_Instance')
sys.path.insert(0,str(PFSP_ROOT)); sys.path.insert(0,str(HERE))
from run_pfsp_single import (load_manifest_row, load_instance, generate_pool_to_memmap,
    cmax_memmap, selection_indices, mine_pr_rules, current_violation, insertion_score, pfsp_cmax)
from external_comparator_comparators import (qig, qneh_time, cmax_numba, best_insert_ff, insert_at,
    remove_job, neh_ff, insertion_local_search_ff, validate_permutation)

external_comparator_ZIP=(Path(__file__).resolve().parent.parent/'PFSP_external_comparator_FINAL_280of280_GREEN.zip')
SEEDS=HERE/'external_comparator_seed_manifest.csv'
REF=HERE/'reference_benchmark_reference_ub_MASTER.csv'
OUT=HERE/'raw'; OUT.mkdir(exist_ok=True)
TMP=HERE/'tmp'; TMP.mkdir(exist_ok=True)
TARGETS=['Ta50_10_1','Ta50_20_1','Ta100_20_1']
REPS=range(1,6)
QINFO=4


def rows(path):
    with open(path,encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
SEED_ROWS=rows(SEEDS); REF_ROWS=rows(REF)

def seed_for(pid,rep):
    rr=[x for x in SEED_ROWS if x['ProblemID']==pid and int(x['Replication'])==rep]
    assert len(rr)==1
    return int(rr[0]['Seed']), int(rr[0]['ProblemOrdinal'])

def ub_for(pid):
    rr=[x for x in REF_ROWS if x['Problem']==pid]; assert len(rr)==1
    return float(rr[0]['Reference UB'])

def boundary_mode(pid):
    return 'deterministic' if (pid.startswith('Ta50_10_') or pid.startswith('VFR')) else 'numpy_quicksort'

def external_comparator_max_guided(pid,rep):
    z=zipfile.ZipFile(external_comparator_ZIP)
    matches=[n for n in z.namelist() if '/native_runs/' in n and f'_{pid}_r{rep:02d}.json' in n]
    assert len(matches)==1,(pid,rep,matches)
    d=json.loads(z.read(matches[0]))
    assert int(d['replication'])==rep and int(d['seed'])==seed_for(pid,rep)[0]
    return float(d['framework']['max_guided_sec']), float(d['framework']['offline_sec']), float(d['framework']['budget_sec'])

def mine(pid,rep,seed,p):
    n=p.shape[0]; S=10000*n; elite_n=round(.05*S); poor_n=round(.10*S)
    path=TMP/f'{pid}_r{rep:02d}.uint16'
    if path.exists(): path.unlink()
    t0=time.perf_counter()
    pool=generate_pool_to_memmap(seed,S,n,path,25000,False)
    cs=cmax_memmap(pool,p,50000,False)
    eidx,bidx=selection_indices(cs,elite_n,poor_n,boundary_mode(pid))
    elite=np.asarray(pool[eidx,:],dtype=np.uint16); poor=np.asarray(pool[bidx,:],dtype=np.uint16)
    PE,RE,PC,RC=mine_pr_rules(elite,poor,n,4,3*n)
    elapsed=time.perf_counter()-t0
    stats={'pool_size':S,'pool_best':int(cs.min()),'pool_mean':float(cs.mean()),
           'elite_mean':float(cs[eidx].mean()),'poor_mean':float(cs[bidx].mean()),
           'boundary_mode':boundary_mode(pid)}
    del elite,poor,cs,pool
    try:path.unlink()
    except FileNotFoundError:pass
    return PE,RE,PC,RC,elapsed,stats

def best_structural_action(seq, candidates, P,R):
    # Same frozen insertion_score semantics, computed in O(|candidates|*|seq|).
    # Stable smallest job id on exact tie.
    arr=np.asarray(seq,dtype=np.int64)
    k=arr.size; regions=R.shape[1]
    regs=np.minimum((np.arange(k+1,dtype=np.int64)*regions)//max(1,k+1), regions-1)
    best_job=None; best_s=-1e300
    for job in np.sort(np.asarray(candidates,dtype=np.int64)):
        j=int(job)
        if k==0:
            scores=0.35*R[j,regs]
        else:
            a=P[arr,j].astype(float,copy=False)
            b=P[j,arr].astype(float,copy=False)
            pref=np.empty(k+1,dtype=float); pref[0]=0.0; pref[1:]=np.cumsum(a)
            suff=np.empty(k+1,dtype=float); suff[k]=0.0; suff[:k]=np.cumsum(b[::-1])[::-1]
            ps=(pref+suff)/float(k)
            scores=0.65*ps+0.35*R[j,regs]
        s=float(np.max(scores))
        if s>best_s+1e-15:
            best_s=s; best_job=j
    return int(best_job)

def qneh_pr(p,seed,time_limit_sec,P,R,epsilon=.5,alpha=.5,gamma=.8):
    n,m=p.shape; rng=np.random.default_rng(seed); Q=np.zeros((n,n),dtype=float)
    best_c=2**63-1; best_seq=None; episodes=0; guided_ties=0
    t0=time.perf_counter()
    while episodes==0 or (time.perf_counter()-t0)<float(time_limit_sec):
        seq=np.empty(0,dtype=np.int64); remaining=np.arange(n,dtype=np.int64)
        for t in range(n):
            if rng.random()<epsilon:
                action=int(remaining[int(rng.integers(0,remaining.size))])
            else:
                vals=Q[t,remaining]; mx=float(np.max(vals)); cand=remaining[vals==mx]
                if cand.size>1:
                    action=best_structural_action(seq.tolist(),cand,P,R); guided_ties+=1
                else: action=int(cand[0])
            pos,bestins_c,append_c,_=best_insert_ff(seq,action,p)
            next_seq=insert_at(seq,action,pos)
            reward=1.0/float(append_c)+(float(append_c)-float(bestins_c))/float(append_c)
            rem2=remaining[remaining!=action]
            nextmax=0.0 if t==n-1 else float(np.max(Q[t+1,rem2]))
            Q[t,action]+=alpha*(reward+gamma*nextmax-Q[t,action])
            seq=next_seq; remaining=rem2
        c=int(cmax_numba(seq,p)); episodes+=1
        if c<best_c: best_c=c; best_seq=seq.copy()
    elapsed=time.perf_counter()-t0
    return {'algorithm':'Q-NEH+PR','seed':seed,'cmax':int(best_c),'seq':best_seq,
            'elapsed_sec':elapsed,'episodes':episodes,'guided_q_ties':guided_ties,
            'q_nonzero':int(np.count_nonzero(Q))}

def insertion_local_search_deadline(seq,p,rng,deadline,max_passes=100):
    seq=np.asarray(seq,dtype=np.int64).copy(); current=int(cmax_numba(seq,p)); passes=0
    for _ in range(max_passes):
        if time.perf_counter()>=deadline: return seq,current,passes,True
        passes+=1; improved=False; jobs=seq.copy(); rng.shuffle(jobs)
        for job in jobs:
            if time.perf_counter()>=deadline: return seq,current,passes,True
            partial=remove_job(seq,int(job)); pos,cand_c,_,_=best_insert_ff(partial,int(job),p)
            seq=insert_at(partial,int(job),pos)
            if cand_c<current: improved=True
            current=int(cand_c)
        if not improved: break
    return seq,current,passes,False

def qig_deadline(p,seed,time_limit_sec,tau=.7,epsilon=.8,beta=.996,alpha=.6,gamma=.8,E=6,eta=.3,max_ls_passes=100):
    n,m=p.shape; rng=np.random.default_rng(seed); start=time.perf_counter(); deadline=start+float(time_limit_sec)
    seq,_=neh_ff(p); best_seq=seq.copy(); best_c=int(cmax_numba(seq,p))
    seq,curr_c,init_passes,to=insertion_local_search_deadline(seq,p,rng,deadline,max_ls_passes)
    if curr_c<best_c: best_c=int(curr_c); best_seq=seq.copy()
    Q=np.zeros((2,3),dtype=float); state=0; d=int(rng.integers(1,4)); temp=float(tau)*float(p.sum())/float(n*m*10.0)
    episodes=iterations=accepts=0; eps=float(epsilon)
    while time.perf_counter()<deadline:
        Cprev=int(curr_c); Cbest_prev=int(best_c); C_ep=int(curr_c); used_d=d
        for _ in range(E):
            if time.perf_counter()>=deadline: break
            iterations+=1
            idxs=rng.choice(seq.size,size=d,replace=False); removed=seq[idxs].copy(); keepmask=np.ones(seq.size,dtype=bool); keepmask[idxs]=False
            partial=seq[keepmask].copy(); partial,_,_,to=insertion_local_search_deadline(partial,p,rng,deadline,max_ls_passes)
            if time.perf_counter()>=deadline: break
            cand=partial
            for job in removed:
                if time.perf_counter()>=deadline: break
                pos,_,_,_=best_insert_ff(cand,int(job),p); cand=insert_at(cand,int(job),pos)
            if cand.size!=n or time.perf_counter()>=deadline: break
            cand,cand_c,_,to=insertion_local_search_deadline(cand,p,rng,deadline,max_ls_passes)
            accept=cand_c<=curr_c
            if not accept and temp>0: accept=rng.random()<math.exp((float(curr_c)-float(cand_c))/temp)
            if accept:
                seq=cand; curr_c=int(cand_c); accepts+=1
                if curr_c<C_ep:C_ep=curr_c
            if cand_c<best_c: best_c=int(cand_c); best_seq=cand.copy()
            if time.perf_counter()>=deadline: break
        rlocal=max(Cprev-C_ep,0)/float(Cprev); rglobal=max(Cbest_prev-best_c,0)/float(Cbest_prev)
        reward=eta*rlocal+(1-eta)*rglobal; new_state=1 if best_c<Cbest_prev else 0
        Q[state,used_d-1]+=alpha*(reward+gamma*float(np.max(Q[new_state]))-Q[state,used_d-1])
        eps*=beta; d=(int(np.argmax(Q[new_state]))+1) if rng.random()>=eps else int(rng.integers(1,4)); state=new_state; episodes+=1
    elapsed=time.perf_counter()-start
    return {'algorithm':'QIG-hard-deadline','seed':seed,'cmax':int(best_c),'seq':best_seq,'elapsed_sec':elapsed,'episodes':episodes,'iterations':iterations,'accepts':accepts,'init_ls_passes':init_passes}

def qig_pr(p,seed,time_limit_sec,P,R,tau=.7,epsilon=.8,beta=.996,alpha=.6,gamma=.8,E=6,eta=.3,max_ls_passes=100,q_info=4):
    n,m=p.shape; rng=np.random.default_rng(seed); start=time.perf_counter(); deadline=start+float(time_limit_sec)
    seq,_=neh_ff(p); best_seq=seq.copy(); best_c=int(cmax_numba(seq,p))
    seq,curr_c,init_passes,_=insertion_local_search_deadline(seq,p,rng,deadline,max_ls_passes)
    if curr_c<best_c: best_c=int(curr_c); best_seq=seq.copy()
    Q=np.zeros((2,3),dtype=float); state=0
    d=int(rng.integers(1,4)); temp=float(tau)*float(p.sum())/float(n*m*10.0)
    episodes=iterations=accepts=0; eps=float(epsilon); guided_destructions=0
    while time.perf_counter()<deadline:
        Cprev=int(curr_c); Cbest_prev=int(best_c); C_ep=int(curr_c); used_d=d
        for _ in range(E):
            iterations+=1
            v=current_violation(seq.tolist(),P,R)
            ordered=[x for _,x in sorted(enumerate(seq.tolist()), key=lambda t:(-v[t[1]],t[0]))]
            top=np.asarray(ordered[:min(q_info,len(ordered))],dtype=np.int64)
            if top.size<d: top=np.asarray(seq,dtype=np.int64)
            removed=rng.choice(top,size=d,replace=False).astype(np.int64,copy=False); guided_destructions+=1
            # remove selected jobs preserving incumbent order among retained jobs
            keepmask=~np.isin(seq,removed); partial=seq[keepmask].copy()
            partial,_,_,_=insertion_local_search_deadline(partial,p,rng,deadline,max_ls_passes)
            if time.perf_counter()>=deadline: break
            cand=partial
            # reconstruct in sampled removal order, as original QIG does with draw order
            for job in removed:
                if time.perf_counter()>=deadline: break
                pos,_,_,_=best_insert_ff(cand,int(job),p); cand=insert_at(cand,int(job),pos)
            if cand.size!=n or time.perf_counter()>=deadline: break
            cand,cand_c,_,_=insertion_local_search_deadline(cand,p,rng,deadline,max_ls_passes)
            accept=cand_c<=curr_c
            if not accept and temp>0:
                accept=rng.random()<math.exp((float(curr_c)-float(cand_c))/temp)
            if accept:
                seq=cand; curr_c=int(cand_c); accepts+=1
                if curr_c<C_ep:C_ep=curr_c
            if cand_c<best_c:
                best_c=int(cand_c); best_seq=cand.copy()
            if time.perf_counter()>=deadline: break
        rlocal=max(Cprev-C_ep,0)/float(Cprev); rglobal=max(Cbest_prev-best_c,0)/float(Cbest_prev)
        reward=eta*rlocal+(1-eta)*rglobal; new_state=1 if best_c<Cbest_prev else 0
        Q[state,used_d-1]+=alpha*(reward+gamma*float(np.max(Q[new_state]))-Q[state,used_d-1])
        eps*=beta
        d=(int(np.argmax(Q[new_state]))+1) if rng.random()>=eps else int(rng.integers(1,4))
        state=new_state; episodes+=1
    elapsed=time.perf_counter()-start
    return {'algorithm':'QIG+PR','seed':seed,'cmax':int(best_c),'seq':best_seq,
            'elapsed_sec':elapsed,'episodes':episodes,'iterations':iterations,'accepts':accepts,
            'guided_destructions':guided_destructions,'init_ls_passes':init_passes}

def qa_result(res,p,n):
    return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))

def warmup():
    row=load_manifest_row(PFSP_ROOT,'Ta20_5_1'); p,_=load_instance(PFSP_ROOT,row)
    s=np.arange(5,dtype=np.int64); cmax_numba(s,p); best_insert_ff(s[:-1],int(s[-1]),p)

def run_one(pid,rep):
    row=load_manifest_row(PFSP_ROOT,pid); p,_=load_instance(PFSP_ROOT,row); n,m=p.shape
    seed,ordn=seed_for(pid,rep); ub=ub_for(pid); g8,oldoff,oldB=external_comparator_max_guided(pid,rep)
    PE,RE,PC,RC,off,stats=mine(pid,rep,seed,p)
    B=off+g8
    methods=[
      ('QIG','Base',lambda:qig_deadline(p,seed,B)),
      ('QIG','Elite',lambda:qig_pr(p,seed,g8,PE,RE)),
      ('QIG','Contrast',lambda:qig_pr(p,seed,g8,PC,RC)),
      ('Q-NEH','Base',lambda:qneh_time(p,seed,B)),
      ('Q-NEH','Elite',lambda:qneh_pr(p,seed,g8,PE,RE)),
      ('Q-NEH','Contrast',lambda:qneh_pr(p,seed,g8,PC,RC)),
    ]
    # rotate execution order by replication to reduce fixed order effects
    shift=(rep-1)%len(methods); methods=methods[shift:]+methods[:shift]
    rec=[]
    for fam,mode,fn in methods:
        print(f'START {pid} rep{rep} {fam}|{mode}',flush=True)
        r=fn(); ok=qa_result(r,p,n)
        print(f'DONE  {pid} rep{rep} {fam}|{mode} cmax={r["cmax"]} elapsed={r["elapsed_sec"]:.6f}',flush=True)
        rec.append({'family':fam,'mode':mode,'cmax':int(r['cmax']),'rpd':100*(r['cmax']-ub)/ub,
                    'elapsed_sec':float(r['elapsed_sec']),'qa':ok,
                    'details':{k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in r.items() if k not in ('seq','cmax','elapsed_sec')}})
    out={'status':'GREEN' if all(x['qa'] for x in rec) else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,
         'n':n,'m':m,'reference_ub':ub,'fresh_offline_sec':off,'frozen_external_comparator_max_guided_sec':g8,
         'pilot_equal_total_budget_sec':B,'external_comparator_old_offline_sec':oldoff,'external_comparator_old_budget_sec':oldB,
         'pool_stats':stats,'results':rec}
    path=OUT/f'{ordn:02d}_{pid}_r{rep:02d}.json'; path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({'problem':pid,'rep':rep,'status':out['status'],'off':off,'g8':g8,'B':B,
        'results':{f"{x['family']}|{x['mode']}":x['cmax'] for x in rec}},indent=2),flush=True)
    return out

def main():
    warmup()
    for pid in TARGETS:
        for rep in REPS:
            run_one(pid,rep)
if __name__=='__main__': main()
