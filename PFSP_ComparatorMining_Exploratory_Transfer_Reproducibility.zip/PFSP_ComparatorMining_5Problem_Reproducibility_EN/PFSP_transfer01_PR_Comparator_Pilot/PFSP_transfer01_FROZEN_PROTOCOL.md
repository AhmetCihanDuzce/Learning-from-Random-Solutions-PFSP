# PFSP transfer experiment 01 — Targeted P/R-Augmented Comparator Pilot (FROZEN)

Frozen before observing any transfer experiment 01 pilot outcome.

## Purpose
Exploratory stress-test of whether the already-frozen Elite-only / Contrast P+R information layer can improve QIG and Q-NEH specifically on external-comparator analysis cases where those comparators had relatively weak native performance. This is a targeted diagnostic pilot, not a portfolio-wide superiority claim.

## Problem selection
Selection uses exploratory transfer analysis native 10-rep problem-mean RPD only, before the pilot is run:
- Ta50_10_1 — worst QIG mean RPD in the 28-problem external-comparator analysis panel; Q-NEH also relatively weak.
- Ta50_20_1 — second-worst QIG mean RPD and also weak Q-NEH.
- Ta100_20_1 — worst Q-NEH mean RPD and third-worst QIG.

No additional problem may be added after seeing these pilot outcomes without being labeled a separate follow-up.

## Replications
Use external-comparator analysis replications 1..5 and their frozen external-comparator analysis seeds. R=5 per problem.

## Frozen mining semantics
For each problem/replication:
- random pool S = 10000*n;
- Elite = best 5%; Poor = worst 10%;
- P = strongest 3n precedence relations;
- R = four equal relative-position regions;
- P/R weights = 0.65 / 0.35;
- Elite-only and Contrast are evaluated separately;
- historical external-comparator analysis boundary selection semantics are retained.

## Q-NEH + P/R integration
Q-NEH learning, rewards, epsilon, alpha, gamma, and Cmax-based insertion remain unchanged. P/R is used only as a secondary action selector during exploitation when multiple remaining jobs have exactly the same maximal Q value. Among the tied actions, select the job with the highest best-achievable structural insertion score over all positions. Exploration remains uniformly random. Thus P/R never overrides a strictly larger learned Q value and does not change the insertion objective.

## QIG + P/R integration
QIG parameters, destruction-size Q-learning, local search, reconstruction, Metropolis acceptance, rewards, and stopping semantics remain unchanged. Only destruction-job selection is guided. At each destruction step, compute the frozen P/R current-violation score and form a candidate pool from the q=4 highest-violation jobs (stable current-sequence order on ties); sample the QIG destruction size d in {1,2,3} uniformly without replacement from that top-q pool. No worse solution is accepted because of P/R.

## Equal end-to-end time budget
Primary pilot is a strict end-to-end budget test.

For each problem/replication, let G8(k,r) be the frozen external-comparator analysis max guided-variant online time recorded for that exact run. Fresh mining is timed in the pilot as T_off(k,r). Define

B_pilot(k,r) = T_off(k,r) + G8(k,r).

- Baseline QIG and baseline Q-NEH each receive B_pilot seconds of online search and incur no mining cost.
- Each P/R-guided QIG/Q-NEH variant is charged T_off and receives exactly G8 seconds of online search.
- Therefore baseline and guided methods have the same accounted end-to-end budget B_pilot.
- The same mined pool is physically reused across variants to avoid redundant experiment runtime, but T_off is fully charged to every guided alternative in accounting; no amortization is used in the primary result.

## Methods
Six alternatives per problem/replication:
1. QIG baseline
2. QIG + Elite P/R
3. QIG + Contrast P/R
4. Q-NEH baseline
5. Q-NEH + Elite P/R
6. Q-NEH + Contrast P/R

## Primary outcome
Within comparator, guided-minus-baseline RPD difference under equal end-to-end budget. Negative is improvement.

Report per problem and mode:
- mean Cmax and mean RPD over 5 reps;
- paired Cmax W/T/L versus the corresponding baseline;
- mean and median paired RPD change;
- online time, offline time, and accounted end-to-end time.

Because problems were deliberately selected for poor comparator performance and there are only three problems, this pilot is descriptive/exploratory. No portfolio-wide generalization or confirmatory significance claim is permitted.

## QA
- single process / single computational thread where controllable;
- JIT warm-up before timing;
- all output permutations validated;
- Cmax independently recomputed;
- seeds checked against external-comparator analysis records;
- budget arithmetic audited;
- no external-comparator analysis/9 result overwritten.


## Implementation amendment before official production restart
The first technical shakedown revealed that the original external-comparator analysis QIG local-search routine can allow a single local-search call to overrun a short pilot online budget by an arbitrarily large amount because the timer is checked only outside that call. All shakedown outputs were discarded. Before the official transfer experiment 01 production restart, both baseline QIG and P/R-guided QIG were therefore switched to the same deadline-aware version of the *same* insertion local search: the search checks the common wall-clock deadline between job reinsertion evaluations and returns the last valid full permutation / previous incumbent when the deadline is reached. No P/R rule, QIG parameter, acceptance rule, destruction-size policy, reward rule, or mining rule was changed. This amendment exists solely to enforce the already-frozen equal-time-budget requirement symmetrically for baseline and guided QIG.
