from pathlib import Path
import transfer01_runner as r

r.warmup()
for pid in r.TARGETS:
    for rep in r.REPS:
        seed, ordn = r.seed_for(pid,rep)
        path = r.OUT/f'{ordn:02d}_{pid}_r{rep:02d}.json'
        if path.exists():
            print(f'SKIP existing {pid} rep{rep}', flush=True)
            continue
        r.run_one(pid,rep)
print('ALL MISSING COMPLETE', flush=True)
