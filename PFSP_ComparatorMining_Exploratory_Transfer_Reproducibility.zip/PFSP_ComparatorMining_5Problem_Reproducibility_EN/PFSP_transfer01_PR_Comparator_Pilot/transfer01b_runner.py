import json, time
from pathlib import Path
import transfer01_runner as r

OUT=r.HERE/'online_matched_baseline'; OUT.mkdir(exist_ok=True)
r.warmup()
for pid in r.TARGETS:
    for rep in r.REPS:
        seed,ordn=r.seed_for(pid,rep)
        out=OUT/f'{ordn:02d}_{pid}_r{rep:02d}.json'
        if out.exists():
            print('SKIP',pid,rep,flush=True); continue
        row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]
        g8,_,_=r.external_comparator_max_guided(pid,rep)
        print(f'START {pid} rep{rep} QIG online={g8:.6f}',flush=True)
        qig=r.qig_deadline(p,seed,g8); qig_ok=r.qa_result(qig,p,n)
        print(f'DONE  {pid} rep{rep} QIG cmax={qig["cmax"]} elapsed={qig["elapsed_sec"]:.6f}',flush=True)
        print(f'START {pid} rep{rep} Q-NEH online={g8:.6f}',flush=True)
        qn=r.qneh_time(p,seed,g8); qn_ok=r.qa_result(qn,p,n)
        print(f'DONE  {pid} rep{rep} Q-NEH cmax={qn["cmax"]} elapsed={qn["elapsed_sec"]:.6f}',flush=True)
        d={'status':'GREEN' if qig_ok and qn_ok else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'g8_sec':g8,
           'QIG':{'cmax':int(qig['cmax']),'elapsed_sec':float(qig['elapsed_sec']),'qa':qig_ok},
           'Q-NEH':{'cmax':int(qn['cmax']),'elapsed_sec':float(qn['elapsed_sec']),'qa':qn_ok}}
        out.write_text(json.dumps(d,indent=2),encoding='utf-8')
        print(json.dumps(d),flush=True)
print('ALL ONLINE-MATCHED BASELINES COMPLETE',flush=True)
