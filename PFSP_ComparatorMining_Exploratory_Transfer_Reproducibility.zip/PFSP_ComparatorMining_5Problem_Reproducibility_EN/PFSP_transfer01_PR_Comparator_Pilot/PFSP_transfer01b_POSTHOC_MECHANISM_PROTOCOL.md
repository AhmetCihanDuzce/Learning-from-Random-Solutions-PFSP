# PFSP exploratory transfer analysis.1b — Post-hoc Online-Matched Mechanism Audit

Status: EXPLORATORY / POST-HOC. Frozen after observing the transfer experiment 01 strict end-to-end pilot and before executing this secondary audit.

## Purpose
The transfer experiment 01 primary test charges fresh P/R mining time to the guided alternatives and therefore gives the unguided comparators more online search time within the same end-to-end budget. This secondary audit asks a narrower mechanism question: **if online search time is held equal, does P/R guidance improve QIG or Q-NEH search behavior on the same targeted hard cases?**

This audit must not be used as a fair end-to-end superiority claim because the guided methods still require offline mining time.

## Data reused
- Same three targeted problems and five external-comparator analysis seeds per problem.
- Same transfer experiment 01 guided QIG+Elite, QIG+Contrast, Q-NEH+Elite, and Q-NEH+Contrast outputs.
- Same frozen external-comparator analysis online budget G8(k,r) for each problem/replication.

## New runs
For each problem/replication rerun only:
1. unguided QIG with online time exactly G8(k,r), using the transfer experiment 01 deadline-aware QIG implementation;
2. unguided Q-NEH with online time exactly G8(k,r).

Seeds and all comparator parameters remain unchanged.

## Comparison
Within each comparator, compare each already-computed guided result against the new online-matched baseline for the same problem, replication, seed, and G8 budget.

Report mean Cmax/RPD, paired W/T/L, mean/median paired RPD change, and online times. Also report the fresh offline mining time from transfer experiment 01 separately to show that this is a mechanism audit rather than an end-to-end cost comparison.

No confirmatory significance claim and no portfolio-wide generalization are permitted.
