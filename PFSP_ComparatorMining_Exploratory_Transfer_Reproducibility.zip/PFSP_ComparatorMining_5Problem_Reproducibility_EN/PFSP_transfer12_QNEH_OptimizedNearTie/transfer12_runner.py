from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,time,csv,hashlib,zipfile
from pathlib import Path
import numpy as np
from numba import njit

HERE=Path(__file__).resolve().parent
B1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
B2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias')
B11=(Path(__file__).resolve().parent.parent/'PFSP_transfer11_QNEH_NearTie')
sys.path.insert(0,str(B1)); sys.path.insert(0,str(B11))
import transfer01_runner as r
import transfer11_runner as old
from external_comparator_comparators import cmax_numba,best_insert_ff,insert_at,validate_permutation
from run_pfsp_single import pfsp_cmax

VAL=['Ta50_10_1','Ta50_20_1','Ta100_20_1','Ta100_20_10','VFR100_40_10']; REPS=range(6,11); THETA=.05

@njit(cache=True)
def p_action_score_fast(seq,candidates,P):
    k=seq.size
    # candidates expected sorted asc; caller sorts for stable tie semantics
    best_job=int(candidates[0]); best_s=-1e300
    if k==0:
        for ci in range(candidates.size):
            j=int(candidates[ci]); s=0.0
            for h in range(P.shape[1]): s+=P[j,h]
            if s>best_s+1e-15:
                best_s=s; best_job=j
        return best_job
    for ci in range(candidates.size):
        j=int(candidates[ci])
        pref=0.0; suff=0.0
        for idx in range(k): suff += P[j,int(seq[idx])]
        s=(pref+suff)/k
        local_best=s
        for pos in range(1,k+1):
            x=int(seq[pos-1]); pref += P[x,j]; suff -= P[j,x]
            s=(pref+suff)/k
            if s>local_best: local_best=s
        if local_best>best_s+1e-15:
            best_s=local_best; best_job=j
    return best_job

def qneh_fast(p,seed,time_limit_sec,P,theta=THETA,epsilon=.5,alpha=.5,gamma=.8):
    n,m=p.shape; rng=np.random.default_rng(seed); Q=np.zeros((n,n),dtype=float)
    best_c=2**63-1; best_seq=None; episodes=0; guided=0; exploit=0; cand_sum=0; cand_max=0
    t0=time.perf_counter()
    while episodes==0 or (time.perf_counter()-t0)<float(time_limit_sec):
        seq=np.empty(0,dtype=np.int64); remaining=np.arange(n,dtype=np.int64)
        for t in range(n):
            if rng.random()<epsilon:
                action=int(remaining[int(rng.integers(0,remaining.size))])
            else:
                exploit+=1; vals=Q[t,remaining]; mx=float(np.max(vals)); mn=float(np.min(vals)); span=mx-mn
                if span<=1e-18: cand=remaining
                else: cand=remaining[(mx-vals)<=float(theta)*span+1e-18]
                if cand.size>1:
                    cand=np.sort(cand.astype(np.int64))
                    action=int(p_action_score_fast(seq,cand,P)); guided+=1; cand_sum+=int(cand.size); cand_max=max(cand_max,int(cand.size))
                else: action=int(cand[0])
            pos,bestins_c,append_c,_=best_insert_ff(seq,action,p)
            next_seq=insert_at(seq,action,pos)
            reward=1.0/float(append_c)+(float(append_c)-float(bestins_c))/float(append_c)
            rem2=remaining[remaining!=action]
            nextmax=0.0 if t==n-1 else float(np.max(Q[t+1,rem2]))
            Q[t,action]+=alpha*(reward+gamma*nextmax-Q[t,action])
            seq=next_seq; remaining=rem2
        c=int(cmax_numba(seq,p)); episodes+=1
        if c<best_c: best_c=c; best_seq=seq.copy()
    elapsed=time.perf_counter()-t0
    return {'algorithm':'Q-NEH+ContrastP-neartie-fast','seed':int(seed),'theta':float(theta),'cmax':int(best_c),'seq':best_seq,
            'elapsed_sec':float(elapsed),'episodes':int(episodes),'overrun_sec':max(0.,float(elapsed)-float(time_limit_sec)),
            'guided_nearties':int(guided),'exploit_actions':int(exploit),'guided_fraction':float(guided/max(1,exploit)),
            'mean_candidate_size_when_guided':float(cand_sum/max(1,guided)),'max_candidate_size':int(cand_max)}

def qa(res,p,n): return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))
def load_pc(pid):
    z=np.load(B2/'cache'/f'{pid}_r01_PC.npz'); return z['PC'],float(z['offline_sec'])

def semantic_regression():
    rng=np.random.default_rng(991122)
    total=0; fails=[]
    for pid in VAL:
        P,_=load_pc(pid); n=P.shape[0]
        # compile
        p_action_score_fast(np.array([],dtype=np.int64),np.array([0,1],dtype=np.int64),P)
        for _ in range(100):
            perm=rng.permutation(n); k=int(rng.integers(0,n)); seq=perm[:k].astype(np.int64)
            rem=np.setdiff1d(np.arange(n,dtype=np.int64),seq,assume_unique=False)
            if rem.size==0: continue
            sz=int(rng.integers(1,min(rem.size,12)+1)); cand=np.sort(rng.choice(rem,size=sz,replace=False).astype(np.int64))
            a=int(old.p_action_score(seq,cand,P)); b=int(p_action_score_fast(seq,cand,P)); total+=1
            if a!=b: fails.append({'problem':pid,'k':k,'cand':cand.tolist(),'old':a,'fast':b})
    d={'status':'GREEN' if not fails else 'RED','cases':total,'failures':len(fails),'examples':fails[:5]}
    (HERE/'semantic_regression.json').write_text(json.dumps(d,indent=2)); print('SEMANTIC',d,flush=True)
    if fails: raise RuntimeError('semantic regression failed')

def run():
    semantic_regression(); out=HERE/'validation'; out.mkdir(exist_ok=True)
    for pid in VAL:
        row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid); P,off=load_pc(pid)
        for rep in REPS:
            seed,ordn=r.seed_for(pid,rep); g8,_,_=r.external_comparator_max_guided(pid,rep)
            bfile=B11/'validation'/f'{ordn:02d}_{pid}_r{rep:02d}_base.json'; bd=json.loads(bfile.read_text())
            fn=out/f'{ordn:02d}_{pid}_r{rep:02d}_guided.json'
            if fn.exists(): continue
            rr=qneh_fast(p,seed,g8,P); ok=qa(rr,p,n)
            d={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'theta':THETA,'g8_sec':g8,'offline_sec':off,'amortized_offline_sec':off/10,
               'accounted_total_sec':g8+off/10,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(rr['cmax']),'rpd':100*(rr['cmax']-ub)/ub,
               'delta_rpd':100*(rr['cmax']-bd['cmax'])/ub,'elapsed_sec':rr['elapsed_sec'],'qa':ok,'details':{k:v for k,v in rr.items() if k not in ('seq','cmax','elapsed_sec')}}
            fn.write_text(json.dumps(d,indent=2)); print('RUN',pid,rep,d['cmax'],d['delta_rpd'],rr['episodes'],flush=True)

def summarize():
    rows=[]
    for pid in VAL:
        z=[json.loads(f.read_text()) for f in sorted((HERE/'validation').glob(f'*_{pid}_r*_guided.json'))]; assert len(z)==5
        ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=5-w-t
        # old guided episodes for comparison
        oldz=[json.loads(f.read_text()) for f in sorted((B11/'validation').glob(f'*_{pid}_r*_guided.json'))]
        rows.append({'problem':pid,'n_pairs':5,'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,
                     'mean_guided_rpd':float(np.mean([x['rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),
                     'guided_best_cmax':min(x['cmax'] for x in z),'baseline_best_cmax':min(x['baseline_cmax'] for x in z),
                     'mean_fast_episodes':float(np.mean([x['details']['episodes'] for x in z])),'mean_old_episodes':float(np.mean([x['details']['episodes'] for x in oldz])),
                     'episode_ratio_fast_over_old':float(np.mean([x['details']['episodes'] for x in z])/np.mean([x['details']['episodes'] for x in oldz])),
                     'mean_guided_fraction':float(np.mean([x['details']['guided_fraction'] for x in z]))})
    with open(HERE/'transfer12_summary.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    qa_all=all(json.loads(f.read_text())['status']=='GREEN' for f in (HERE/'validation').glob('*.json'))
    rep=['# transfer experiment 12 Report','',f'QA: {"GREEN" if qa_all else "RED"}','','The near-tie semantics and theta=0.05 are unchanged; only the structural scorer is optimized.','']
    for x in rows: rep.append(f'- {x["problem"]}: mean ΔRPD={x["mean_delta_rpd"]:.6f}, W/T/L={x["wins"]}/{x["ties"]}/{x["losses"]}, episodes fast/old={x["mean_fast_episodes"]:.1f}/{x["mean_old_episodes"]:.1f}.')
    (HERE/'transfer12_REPORT.md').write_text('\n'.join(rep)+'\n')
    qa={'status':'GREEN' if qa_all else 'RED','validation_json':len(list((HERE/'validation').glob('*.json'))),'semantic_regression':json.loads((HERE/'semantic_regression.json').read_text()),'all_permutation_cmax_qa':qa_all}
    (HERE/'transfer12_MASTER_QA.json').write_text(json.dumps(qa,indent=2))
    files=[p for p in HERE.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt' and not p.name.endswith('.zip')]
    with open(HERE/'SHA256SUMS.txt','w') as f:
        for p in sorted(files): f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(HERE))+'\n')
    zp=(Path(__file__).resolve().parent.parent/'PFSP_transfer12_QNEH_OptimizedNearTie_GREEN.zip')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.rglob('*')):
            if p.is_file(): z.write(p,arcname=str(Path(HERE.name)/p.relative_to(HERE)))
    with zipfile.ZipFile(zp) as z: bad=z.testzip()
    print('FINAL',qa['status'],'bad',bad,flush=True)

if __name__=='__main__':
    r.warmup(); run(); summarize()
