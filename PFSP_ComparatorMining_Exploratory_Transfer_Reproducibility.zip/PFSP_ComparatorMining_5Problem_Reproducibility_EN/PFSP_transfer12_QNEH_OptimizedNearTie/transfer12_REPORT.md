# transfer experiment 12 Report

QA: GREEN

The near-tie semantics and theta=0.05 are unchanged; only the structural scorer is optimized.

- Ta50_10_1: mean ΔRPD=-0.000000, W/T/L=2/1/2, episodes fast/old=920.4/654.2.
- Ta50_20_1: mean ΔRPD=0.207792, W/T/L=1/0/4, episodes fast/old=1486.2/1110.8.
- Ta100_20_1: mean ΔRPD=-0.061271, W/T/L=3/0/2, episodes fast/old=4094.6/3415.2.
- Ta100_20_10: mean ΔRPD=0.049736, W/T/L=2/0/3, episodes fast/old=4313.0/3320.8.
- VFR100_40_10: mean ΔRPD=-0.067907, W/T/L=3/0/2, episodes fast/old=5181.2/4314.4.
