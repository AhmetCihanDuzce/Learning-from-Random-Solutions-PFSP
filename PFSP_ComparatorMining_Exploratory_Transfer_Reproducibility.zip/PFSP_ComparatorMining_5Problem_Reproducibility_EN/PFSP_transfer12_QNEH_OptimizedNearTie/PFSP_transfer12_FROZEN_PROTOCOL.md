# PFSP transfer experiment 12 — Optimized Contrast-P Near-Tie Q-NEH

Status: FROZEN BEFORE EXECUTION.
Nature: implementation-efficiency follow-up to transfer experiment 11; no parameter retuning.

## Motivation
transfer experiment 11 preserved Q-NEH semantics but the Python structural insertion scorer substantially reduced the number of completed Q-NEH episodes. This analysis phase tests whether the same near-tie decision rule performs differently when the structural scorer is compiled/optimized without changing any action decision semantics.

## Frozen semantics
Exactly transfer experiment 11:
- Contrast-P only;
- theta = 0.05 for both n=50 and n=100 (the transfer experiment 11 frozen selections);
- uniform exploration unchanged;
- exploitation candidate rule unchanged;
- among multiple near-tie candidates, select the candidate with maximum best-achievable P insertion score;
- Cmax insertion, reward, Q update, epsilon, alpha and gamma unchanged;
- H=10 reusable-mining accounting unchanged.

The only change is replacing the Python P scorer with a Numba-compiled scorer that must pass semantic regression against the transfer experiment 11 scorer before performance runs.

## Validation
Same five problems and same external-comparator analysis reps 6..10 as transfer experiment 11. The same replication-1 archived 10,000n Contrast-P matrices and measured mining times are used. Equal-budget baselines are reused verbatim from transfer experiment 11; guided Q-NEH is rerun with the optimized scorer for G8 seconds.

## Outcomes
Same as transfer experiment 11. Report paired Delta RPD, W/T/L, batch-best, episode counts, and guidance fraction. No result is discarded.
