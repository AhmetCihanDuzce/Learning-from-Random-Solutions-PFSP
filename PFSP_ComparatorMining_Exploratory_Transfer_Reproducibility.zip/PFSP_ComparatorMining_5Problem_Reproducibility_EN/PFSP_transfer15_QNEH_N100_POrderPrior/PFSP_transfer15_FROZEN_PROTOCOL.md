# PFSP transfer experiment 15 — n=100 Contrast-P order prior for Q-NEH

Status: FROZEN BEFORE EXECUTION.
Nature: targeted exploratory comparator-integration study.

## Objective
Test whether the low-overhead Contrast-P order-prior interface that was successful for n=50 can improve Q-NEH on the previously difficult Ta100_20_10 case, without changing the online Q-NEH mechanism.

## Fixed mined source
Use the already archived transfer experiment 02 S=10,000n Contrast-P matrix for Ta100_20_10, source replication 1. The source is fixed by replication number and is not screened using Q-NEH performance.

## Interface
Compute each job's net precedence strength as the row sum of the Contrast-P matrix. Sort jobs by descending net strength (stable smaller job index for exact ties). Starting from Q=0, replay this action order through the original Q-NEH best-insertion, reward and Q-update equations for D teacher passes. The resulting Q table initializes online Q-NEH. During online search, epsilon-greedy action selection, insertion, reward, alpha=0.5, gamma=0.8 and all remaining Q-NEH logic remain unchanged. No P score is evaluated online.

## n=100-specific development
Target: Ta100_20_10 only.
Teacher passes D in {1,3,5}.
Fresh seed extensions 61..63.
Baseline and prior-seeded Q-NEH receive the same online wall-clock budget equal to the median original external-comparator analysis comparator budget for Ta100_20_10.
Select D by lowest mean paired Delta RPD; ties -> more wins -> smaller D.

## Independent validation
Fresh seed extensions 66..70, five paired runs. Selected D is frozen before validation. Same equal-online budget.

## Strict reusable-cost audit
If validation mean Delta RPD is favorable (<0), run H=10 equal-total-budget audit on fresh extensions 71..75. Baseline receives total budget B. Guided receives B - (source mining time + prior-construction time)/10 online seconds.

## Outcomes
Report mean/median paired Delta RPD, W/T/L, mean RPD, batch-best Cmax, episodes, mining/preparation cost and permutation/Cmax QA. Negative Delta RPD favors mining-informed Q-NEH. All results are retained.
