# transfer experiment 15 Report — n=100 Contrast-P order prior Q-NEH

QA: GREEN

Selected n=100 teacher passes: D=3.

Equal-online validation: mean ΔRPD=0.037302, W/T/L=2/0/3, best 6616 vs 6613.
