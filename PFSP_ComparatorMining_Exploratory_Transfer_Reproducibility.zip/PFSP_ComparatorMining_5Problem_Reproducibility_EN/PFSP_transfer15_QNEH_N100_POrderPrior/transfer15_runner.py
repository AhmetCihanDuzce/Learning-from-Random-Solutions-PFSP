from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,time,csv,zipfile,hashlib
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
B1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
B2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias')
B13=(Path(__file__).resolve().parent.parent/'PFSP_transfer13_QNEH_N50_DemoPrior')
sys.path.insert(0,str(B1)); sys.path.insert(0,str(B13))
import transfer01_runner as r
import transfer13_runner as b13
from external_comparator_comparators import qneh_time,validate_permutation
from run_pfsp_single import pfsp_cmax

PID='Ta100_20_10'; DS=[1,3,5]; DEV_REPS=range(61,64); VAL_REPS=range(66,71); STRICT_REPS=range(71,76); H=10

def load_pc():
    z=np.load(B2/'cache'/f'{PID}_r01_PC.npz'); return z['PC'],float(z['offline_sec'])

def p_order(P):
    s=P.sum(axis=1); jobs=np.arange(P.shape[0],dtype=np.int64); return np.lexsort((jobs,-s)).astype(np.int64)

def qa(x,p,n): return bool(validate_permutation(x['seq'],n) and int(pfsp_cmax(x['seq'],p))==int(x['cmax']))

def source_info():
    p,ub=b13.load_problem(PID); P,off=load_pc(); order=p_order(P); B=b13.fixed_budget(PID)
    return {'p':p,'ub':ub,'P':P,'offline_sec':off,'order':order,'budget_sec':B}

def run_dev(s):
    out=HERE/'development'; out.mkdir(exist_ok=True); p=s['p']; n=p.shape[0]; ub=s['ub']; B=s['budget_sec']
    priors={D:b13.build_demo_prior(p,s['order'],D) for D in DS}
    for rep in DEV_REPS:
        seed,_=b13.seed_ext(PID,rep); fb=out/f'{PID}_r{rep:02d}_base.json'
        if fb.exists(): bd=json.loads(fb.read_text())
        else:
            br=qneh_time(p,seed,B); ok=qa(br,p,n); bd={'status':'GREEN' if ok else 'RED','problem':PID,'rep':rep,'seed':seed,'budget_sec':B,'cmax':int(br['cmax']),'rpd':100*(br['cmax']-ub)/ub,'episodes':br['episodes'],'elapsed_sec':br['elapsed_sec'],'qa':ok}; fb.write_text(json.dumps(bd,indent=2)); print('DEV BASE',rep,bd['cmax'],br['episodes'],flush=True)
        for D in DS:
            fg=out/f'{PID}_r{rep:02d}_D{D}.json'
            if fg.exists(): continue
            Q0,prep,lastc=priors[D]; gr=b13.qneh_from_prior(p,seed,B,Q0); ok=qa(gr,p,n); gd={'status':'GREEN' if ok else 'RED','problem':PID,'rep':rep,'seed':seed,'D':D,'budget_sec':B,'source_offline_sec':s['offline_sec'],'prior_prepare_sec':prep,'prior_demo_constructed_cmax':lastc,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(gr['cmax']),'rpd':100*(gr['cmax']-ub)/ub,'delta_rpd':100*(gr['cmax']-bd['cmax'])/ub,'episodes':gr['episodes'],'elapsed_sec':gr['elapsed_sec'],'qa':ok}; fg.write_text(json.dumps(gd,indent=2)); print('DEV GUID',rep,D,gd['cmax'],gd['delta_rpd'],gr['episodes'],flush=True)

def select_D():
    data=[json.loads(f.read_text()) for f in sorted((HERE/'development').glob('*_D*.json'))]; rows=[]
    for D in DS:
        z=[x for x in data if x['D']==D]; assert len(z)==3,(D,len(z)); ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        rows.append({'D':D,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l})
    rows.sort(key=lambda x:(x['mean_delta_rpd'],-x['wins'],x['D']))
    for i,x in enumerate(rows,1): x['rank']=i; x['selected']=i==1
    with open(HERE/'transfer15_development_summary.csv','w',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    (HERE/'transfer15_selection.json').write_text(json.dumps({'selected_D':rows[0]['D'],'rule':'lowest mean delta RPD; ties -> more wins -> smaller D','ranked':rows},indent=2)); print('SELECT',rows[0]['D'],rows,flush=True); return rows[0]['D']

def run_set(s,D,reps,folder,strict=False):
    out=HERE/folder; out.mkdir(exist_ok=True); p=s['p']; n=p.shape[0]; ub=s['ub']; B=s['budget_sec']; Q0,prep,lastc=b13.build_demo_prior(p,s['order'],D)
    charge=(s['offline_sec']+prep)/H if strict else 0.0; gB=B-charge; assert gB>0
    for rep in reps:
        seed,_=b13.seed_ext(PID,rep); fb=out/f'{PID}_r{rep:02d}_base.json'; fg=out/f'{PID}_r{rep:02d}_guided.json'
        if fb.exists(): bd=json.loads(fb.read_text())
        else:
            br=qneh_time(p,seed,B); ok=qa(br,p,n); bd={'status':'GREEN' if ok else 'RED','problem':PID,'rep':rep,'seed':seed,'budget_sec':B,'cmax':int(br['cmax']),'rpd':100*(br['cmax']-ub)/ub,'episodes':br['episodes'],'elapsed_sec':br['elapsed_sec'],'qa':ok}; fb.write_text(json.dumps(bd,indent=2)); print(folder,'BASE',rep,bd['cmax'],br['episodes'],flush=True)
        if fg.exists(): continue
        gr=b13.qneh_from_prior(p,seed,gB,Q0); ok=qa(gr,p,n); gd={'status':'GREEN' if ok else 'RED','problem':PID,'rep':rep,'seed':seed,'D':D,'total_budget_sec':B,'guided_online_budget_sec':gB,'source_offline_sec':s['offline_sec'],'prior_prepare_sec':prep,'amortized_charge_sec':charge,'accounted_total_sec':gB+charge,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(gr['cmax']),'rpd':100*(gr['cmax']-ub)/ub,'delta_rpd':100*(gr['cmax']-bd['cmax'])/ub,'episodes':gr['episodes'],'elapsed_sec':gr['elapsed_sec'],'qa':ok}; fg.write_text(json.dumps(gd,indent=2)); print(folder,'GUID',rep,gd['cmax'],gd['delta_rpd'],gr['episodes'],flush=True)

def summarize(folder,outname):
    z=[json.loads(f.read_text()) for f in sorted((HERE/folder).glob(f'{PID}_r*_guided.json'))]; assert len(z)==5,(folder,len(z)); ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=5-w-t
    row={'problem':PID,'n_pairs':5,'D':z[0]['D'],'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,'mean_guided_rpd':float(np.mean([x['rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),'guided_best_cmax':min(x['cmax'] for x in z),'baseline_best_cmax':min(x['baseline_cmax'] for x in z),'mean_guided_episodes':float(np.mean([x['episodes'] for x in z]))}
    with open(HERE/outname,'w',newline='') as f: ww=csv.DictWriter(f,fieldnames=list(row)); ww.writeheader(); ww.writerow(row)
    return row

def finalize(D,val,strict):
    qa_all=True
    for f in HERE.rglob('*.json'):
        d=json.loads(f.read_text());
        if isinstance(d,dict) and d.get('status') not in (None,'GREEN'): qa_all=False
    rep=['# transfer experiment 15 Report — n=100 Contrast-P order prior Q-NEH','',f'QA: {"GREEN" if qa_all else "RED"}','',f'Selected n=100 teacher passes: D={D}.','',f'Equal-online validation: mean ΔRPD={val["mean_delta_rpd"]:.6f}, W/T/L={val["wins"]}/{val["ties"]}/{val["losses"]}, best {val["guided_best_cmax"]} vs {val["baseline_best_cmax"]}.']
    if strict is not None: rep += ['',f'Strict H=10: mean ΔRPD={strict["mean_delta_rpd"]:.6f}, W/T/L={strict["wins"]}/{strict["ties"]}/{strict["losses"]}, best {strict["guided_best_cmax"]} vs {strict["baseline_best_cmax"]}.']
    (HERE/'transfer15_REPORT.md').write_text('\n'.join(rep)+'\n')
    qa={'status':'GREEN' if qa_all else 'RED','selected_D':D,'equal_online_favorable':val['mean_delta_rpd']<0,'strict_h10_run':strict is not None,'all_permutation_cmax_qa':qa_all}; (HERE/'transfer15_MASTER_QA.json').write_text(json.dumps(qa,indent=2))
    files=[p for p in HERE.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt' and not p.name.endswith('.zip')]
    with open(HERE/'SHA256SUMS.txt','w') as f:
        for p in sorted(files): f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(HERE))+'\n')
    zp=(Path(__file__).resolve().parent.parent/'PFSP_transfer15_QNEH_N100_POrderPrior_GREEN.zip')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.rglob('*')):
            if p.is_file(): z.write(p,arcname=str(Path(HERE.name)/p.relative_to(HERE)))
    with zipfile.ZipFile(zp) as z: bad=z.testzip()
    print('FINAL',qa,'bad',bad,flush=True)

def main():
    r.warmup(); s=source_info(); run_dev(s); D=select_D(); run_set(s,D,VAL_REPS,'validation',False); val=summarize('validation','transfer15_validation_summary.csv'); strict=None
    if val['mean_delta_rpd']<0: run_set(s,D,STRICT_REPS,'strict_h10',True); strict=summarize('strict_h10','transfer15_strict_h10_summary.csv')
    finalize(D,val,strict)
if __name__=='__main__': main()
