from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys, json, csv, time, hashlib
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias')
S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(S2)); sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from run_pfsp_single import generate_pool_to_memmap, cmax_memmap, selection_indices, mine_pr_rules, pfsp_cmax
from external_comparator_comparators import validate_permutation

DEV='VFR100_40_10'
HOLD='VFR100_60_10'
FACTORS=[2500,5000]
LAM=0.25
TRIGGER='always'
REPS=range(1,6)
TMP=HERE/'tmp'; TMP.mkdir(exist_ok=True)
RAW=HERE/'raw'; RAW.mkdir(exist_ok=True)


def qa(res,p,n):
    return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))


def mine_factor(pid,rep,seed,p,factor):
    n=p.shape[0]; S=int(factor*n); elite_n=round(.05*S); poor_n=round(.10*S)
    path=TMP/f'{pid}_r{rep:02d}_S{factor}n.uint16'
    if path.exists(): path.unlink()
    t0=time.perf_counter()
    pool=generate_pool_to_memmap(seed,S,n,path,25000,False)
    cs=cmax_memmap(pool,p,50000,False)
    eidx,bidx=selection_indices(cs,elite_n,poor_n,r.boundary_mode(pid))
    elite=np.asarray(pool[eidx,:],dtype=np.uint16); poor=np.asarray(pool[bidx,:],dtype=np.uint16)
    PE,RE,PC,RC=mine_pr_rules(elite,poor,n,4,3*n)
    off=time.perf_counter()-t0
    stats={'pool_size':S,'factor_n':factor,'pool_best':int(cs.min()),'pool_mean':float(cs.mean()),
           'elite_mean':float(cs[eidx].mean()),'poor_mean':float(cs[bidx].mean()),'boundary_mode':r.boundary_mode(pid)}
    del elite,poor,cs,pool
    try:path.unlink()
    except FileNotFoundError:pass
    return PC,float(off),stats


def support_jaccard(A,B):
    a=np.asarray(A)!=0; b=np.asarray(B)!=0
    u=np.logical_or(a,b).sum(); inter=np.logical_and(a,b).sum()
    return 1.0 if u==0 else float(inter/u)


def ref10k(pid,rep):
    z=np.load(S2/'cache'/f'{pid}_r{rep:02d}_PC.npz')
    return z['PC'], float(z['offline_sec'])


def run_problem(pid,factors):
    records=[]
    for rep in REPS:
        seed,ordn=r.seed_for(pid,rep)
        row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid)
        g8,_,_=r.external_comparator_max_guided(pid,rep)
        PC10,off10=ref10k(pid,rep) if (S2/'cache'/f'{pid}_r{rep:02d}_PC.npz').exists() else (None,float('nan'))
        # one common online baseline per replication; reuse across factors
        bfile=RAW/f'{pid}_r{rep:02d}_online_baseline.json'
        if bfile.exists():
            base=json.loads(bfile.read_text())
        else:
            print('START ONLINE BASE',pid,rep,'G8',g8,flush=True)
            rr=r.qig_deadline(p,seed,g8); ok=qa(rr,p,n)
            base={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'g8_sec':g8,'reference_ub':ub,
                  'cmax':int(rr['cmax']),'rpd':100*(rr['cmax']-ub)/ub,'elapsed_sec':float(rr['elapsed_sec']),'qa':ok}
            bfile.write_text(json.dumps(base,indent=2)); print('DONE ONLINE BASE',pid,rep,base['cmax'],flush=True)
        for factor in factors:
            outfile=RAW/f'{pid}_r{rep:02d}_S{factor}n.json'
            if outfile.exists():
                d=json.loads(outfile.read_text()); records.append(d); print('SKIP',pid,rep,factor,flush=True); continue
            print('START MINING',pid,rep,factor,flush=True)
            PC,off,stats=mine_factor(pid,rep,seed,p,factor)
            jac=support_jaccard(PC,PC10) if PC10 is not None else float('nan')
            print('DONE MINING',pid,rep,factor,'off',off,'jac10k',jac,flush=True)
            print('START GUIDED',pid,rep,factor,'G8',g8,flush=True)
            gr=s2.qig_soft_p(p,seed,g8,PC,LAM,TRIGGER); gok=qa(gr,p,n)
            print('DONE GUIDED',pid,rep,factor,gr['cmax'],flush=True)
            B=off+g8
            print('START STRICT BASE',pid,rep,factor,'B',B,flush=True)
            br=r.qig_deadline(p,seed,B); bok=qa(br,p,n)
            print('DONE STRICT BASE',pid,rep,factor,br['cmax'],flush=True)
            d={'status':'GREEN' if (base['qa'] and gok and bok) else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,
               'reference_ub':ub,'pool_factor_n':factor,'pool_size':int(factor*n),'lambda':LAM,'trigger':TRIGGER,
               'g8_sec':g8,'offline_sec':off,'offline_10k_reference_sec':off10,'equal_total_budget_sec':B,
               'p_support_jaccard_vs_10k':jac,'pool_stats':stats,
               'online_baseline_cmax':int(base['cmax']),'online_baseline_rpd':float(base['rpd']),'online_baseline_elapsed_sec':float(base['elapsed_sec']),
               'guided_cmax':int(gr['cmax']),'guided_rpd':100*(int(gr['cmax'])-ub)/ub,'guided_online_elapsed_sec':float(gr['elapsed_sec']),
               'online_delta_rpd':100*(int(gr['cmax'])-int(base['cmax']))/ub,
               'strict_baseline_cmax':int(br['cmax']),'strict_baseline_rpd':100*(int(br['cmax'])-ub)/ub,'strict_baseline_elapsed_sec':float(br['elapsed_sec']),
               'strict_delta_rpd':100*(int(gr['cmax'])-int(br['cmax']))/ub,
               'guided_accounted_total_sec':off+float(gr['elapsed_sec']),'qa_online_base':bool(base['qa']),'qa_guided':bool(gok),'qa_strict_base':bool(bok),
               'guided_details':{k:v for k,v in gr.items() if k not in ('seq','cmax','elapsed_sec')}}
            outfile.write_text(json.dumps(d,indent=2)); records.append(d)
    return records


def summarize(pid,records,outname):
    rows=[]
    for factor in sorted({int(x['pool_factor_n']) for x in records}):
        z=[x for x in records if int(x['pool_factor_n'])==factor]
        assert len(z)==5,(pid,factor,len(z))
        od=np.array([x['online_delta_rpd'] for x in z]); sd=np.array([x['strict_delta_rpd'] for x in z])
        ow=sum(x['guided_cmax']<x['online_baseline_cmax'] for x in z); ot=sum(x['guided_cmax']==x['online_baseline_cmax'] for x in z); ol=5-ow-ot
        sw=sum(x['guided_cmax']<x['strict_baseline_cmax'] for x in z); st=sum(x['guided_cmax']==x['strict_baseline_cmax'] for x in z); sl=5-sw-st
        rows.append({'problem':pid,'pool_factor_n':factor,'n_pairs':5,
                     'mean_offline_sec':float(np.mean([x['offline_sec'] for x in z])),
                     'mean_offline_ratio_vs_10k':float(np.mean([x['offline_sec']/x['offline_10k_reference_sec'] for x in z])) if all(np.isfinite(x['offline_10k_reference_sec']) for x in z) else float('nan'),
                     'mean_p_support_jaccard_vs_10k':float(np.nanmean([x['p_support_jaccard_vs_10k'] for x in z])),
                     'mean_online_delta_rpd':float(od.mean()),'median_online_delta_rpd':float(np.median(od)),'online_wins':ow,'online_ties':ot,'online_losses':ol,
                     'mean_strict_delta_rpd':float(sd.mean()),'median_strict_delta_rpd':float(np.median(sd)),'strict_wins':sw,'strict_ties':st,'strict_losses':sl,
                     'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in z])),
                     'mean_online_baseline_rpd':float(np.mean([x['online_baseline_rpd'] for x in z])),
                     'mean_strict_baseline_rpd':float(np.mean([x['strict_baseline_rpd'] for x in z])),
                     'all_qa_green':all(x['status']=='GREEN' for x in z)})
    with open(HERE/outname,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    return rows


def main():
    r.warmup()
    dev=run_problem(DEV,FACTORS)
    devsum=summarize(DEV,dev,'transfer03_development_summary.csv')
    cand=sorted(devsum,key=lambda x:(x['mean_strict_delta_rpd'],x['pool_factor_n']))[0]
    passes=(cand['mean_strict_delta_rpd']<0 and cand['strict_wins']>=cand['strict_losses'])
    selection={'candidate_pool_factor_n':cand['pool_factor_n'],'gate_passed':bool(passes),'criterion':cand}
    (HERE/'transfer03_selection.json').write_text(json.dumps(selection,indent=2))
    print('SELECTION',json.dumps(selection,indent=2),flush=True)
    if passes:
        hold=run_problem(HOLD,[int(cand['pool_factor_n'])])
        summarize(HOLD,hold,'transfer03_holdout_summary.csv')
        print('HOLDOUT COMPLETE',flush=True)
    else:
        print('GATE FAILED; HOLDOUT NOT RUN',flush=True)

if __name__=='__main__': main()
