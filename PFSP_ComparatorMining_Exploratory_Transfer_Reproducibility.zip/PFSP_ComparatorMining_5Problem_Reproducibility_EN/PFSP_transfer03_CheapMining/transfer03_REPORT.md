# transfer experiment 03 Report — Low-Cost Contrast-P Mining for QIG

Status: **GREEN (development completed; frozen promotion gate failed, so holdout was not run).**

## Design
Fixed QIG+Contrast-P soft bias from transfer experiment 02 (always active, lambda=0.25). Only mining pool size changed: S=2,500n and S=5,000n. Development problem: VFR100_40_10, R=5. Both equal-online-time and strict equal-total-budget comparisons were evaluated.

## Main results

| Pool | Mean offline (s) | Offline vs 10,000n | P-support Jaccard vs 10,000n | Online ΔRPD | Online W/T/L | Strict ΔRPD | Strict W/T/L |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2,500n | 15.852 | 24.7% | 0.835 | -0.0201 | 3/0/2 | +0.0855 | 2/0/3 |
| 5,000n | 31.925 | 49.7% | 0.901 | +0.1006 | 0/1/4 | +0.2666 | 0/0/5 |
| 10,000n reference | 64.228 | 100% | 1.000 | -0.2440 | 4/0/1 | -0.0025 | 2/0/3 |

Negative ΔRPD favors guided QIG.

## Interpretation
S=2,500n reduced fresh mining time to about one quarter of the S=10,000n cost while retaining mean P-support Jaccard ≈0.835. However, the strong equal-online-time benefit seen with S=10,000n largely disappeared: mean online ΔRPD was only -0.0201. Under strict equal-total-budget accounting it became +0.0855 with W/T/L=2/0/3.

S=5,000n retained more of the 10,000n P support (mean Jaccard ≈0.901) but performed worse in this small R=5 pilot, both online-matched and strict. This non-monotonicity should not be overinterpreted.

The frozen promotion gate required mean strict ΔRPD<0 and wins>=losses. Neither reduced pool passed. Therefore the pre-specified VFR100_60_10 holdout was **not run**.

The conclusion is that reducing the random-pool cost alone did not produce a strict end-to-end advantage in this pilot. The transfer experiment 02 result remains: high-quality Contrast-P information can guide QIG beneficially, but there is a cost–information trade-off; too much pool reduction weakens the useful signal.
