# PFSP transfer experiment 03 — Low-Cost Contrast-P Mining for QIG

Status: FROZEN BEFORE EXECUTION.
Nature: exploratory efficiency follow-up to transfer experiment 02. It does not replace the confirmatory exploratory transfer analysis results.

## Objective
transfer experiment 02 showed that QIG + Contrast-P soft bias can improve QIG under equal online time, but fresh S=10,000n mining largely consumed the gain under strict end-to-end accounting. transfer experiment 03 tests whether smaller random pools preserve enough P information to retain the search benefit while reducing offline mining cost.

## Fixed guided mechanism
The QIG mechanism is not retuned. It is fixed at the transfer experiment 02 choice:
- Contrast-P only; no R information.
- Always-active soft destruction bias.
- lambda = 0.25.
- QIG state/action definition, destruction size selection, local search, reconstruction, acceptance, reward, epsilon schedule, and all other search parameters unchanged.

## Mining factors under test
Only the pool size changes:
- S = 2,500n
- S = 5,000n

The original S=10,000n transfer experiment 02 result is retained as an external reference and is not rerun for tuning.
For every pool size, all other mining settings remain frozen:
- Elite = best 5%.
- Poor = worst 10%.
- Contrast precedence rules = top 3n pairwise relations by absolute contrast score.
- Same external-comparator analysis seed for a given problem/replication.

Because the same RNG seed and generator are used, the smaller pools are intended as nested prefixes of the corresponding larger generated stream; no new seed tuning is allowed.

## Development problem
VFR100_40_10, which already showed the strongest transfer experiment 02 online-matched Contrast-P signal.
Replications: external-comparator analysis replications 1–5.

For each replication and each mining factor:
1. fresh mining is performed and timed;
2. unguided QIG is run for the frozen online budget G8;
3. guided QIG is run for the same G8;
4. unguided QIG is run for B = T_offline + G8 to form the strict equal-total-budget comparator.

Thus two views are reported:
- mechanism view: guided(G8) versus unguided(G8);
- strict end-to-end view: [offline + guided(G8)] versus unguided(T_offline + G8).

## Structural-retention audit
For each replication and reduced pool size, the mined Contrast-P support is compared with the existing S=10,000n Contrast-P matrix from transfer experiment 02 using directional nonzero-support Jaccard. This is descriptive and not used to tune the method.

## Frozen selection gate
The reduced pool size with the lowest mean strict end-to-end Delta RPD on the five VFR100_40_10 replications is the candidate. Ties are broken in favor of the smaller pool.

The candidate is promoted to holdout only if:
- mean strict Delta RPD < 0, and
- strict wins >= strict losses.

If no reduced pool passes this gate, transfer experiment 03 stops and no holdout is run.

## Independent holdout if gate passes
VFR100_60_10 is frozen now as the independent holdout because it is the next-highest QIG-RPD VFR case in the already completed exploratory transfer analysis panel after VFR100_40_10, among cases not previously used in transfer experiment 02 tuning.
Replications: external-comparator analysis replications 1–5.
Only the single promoted pool size is run. Both mechanism and strict end-to-end comparisons are reported exactly as above.

## Interpretation
transfer experiment 03 is exploratory. A positive result may support the mechanism/efficiency claim that lower-cost mined Contrast-P information can improve QIG on selected difficult VFR cases. It must not be generalized to all PFSP instances or presented as replacing the main exploratory transfer analysis comparator analysis.
