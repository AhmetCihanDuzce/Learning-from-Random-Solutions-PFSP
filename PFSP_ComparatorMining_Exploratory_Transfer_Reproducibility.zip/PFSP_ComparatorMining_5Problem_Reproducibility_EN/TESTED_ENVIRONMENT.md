# Tested environment

The archived experiments were executed with:

- Python 3.13.5
- NumPy 2.3.5
- Numba 0.65.1
- Single-thread environment variables requested for OMP/OpenBLAS/MKL/Numba where the runner sets them.

The comparator experiments are wall-clock-budgeted. Exact episode counts and final Cmax values can vary across hardware and software stacks even with the same RNG seeds because the stopping rule is time based. The archived JSON/CSV results in this package are the reference outputs used in the manuscript analysis.
