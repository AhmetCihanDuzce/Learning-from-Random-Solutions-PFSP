from __future__ import annotations
import argparse, shutil
from pathlib import Path

SELECTED = {
    'PFSP_transfer10_N50_BestArchivedFRB4_WarmStart': ['raw','transfer10_summary.csv','transfer10_MASTER_QA.json','transfer10_archive_selection.json','SHA256SUMS.txt'],
    'PFSP_transfer05_QIG_Reusable_H10_All5': ['raw','transfer05_summary.csv','transfer05_MASTER_QA.json','SHA256SUMS.txt'],
    'PFSP_transfer12_QNEH_OptimizedNearTie': ['validation','transfer12_summary.csv','transfer12_MASTER_QA.json','semantic_regression.json','SHA256SUMS.txt'],
    'PFSP_transfer14_QNEH_N50_POrderPrior': ['development','validation','strict_h10','transfer14_development_summary.csv','transfer14_validation_summary.csv','transfer14_strict_h10_summary.csv','transfer14_selection.json','transfer14_MASTER_QA.json','SHA256SUMS.txt'],
    'PFSP_transfer16_QNEH_N100_CombinedPriorNearTie': ['equal_online','strict_h10','transfer16_equal_online_summary.csv','transfer16_strict_h10_summary.csv','transfer16_MASTER_QA.json','SHA256SUMS.txt'],
}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--dest',required=True,help='Destination directory for a clean rerun copy')
    args=ap.parse_args()
    src=Path(__file__).resolve().parent
    dst=Path(args.dest).resolve()
    if dst.exists(): raise SystemExit(f'Destination already exists: {dst}')
    shutil.copytree(src,dst,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    for analysis_phase,items in SELECTED.items():
        s=dst/analysis_phase
        for item in items:
            p=s/item
            if p.is_dir(): shutil.rmtree(p)
            elif p.exists(): p.unlink()
    # Do not keep the top-level manifest, because the clean copy intentionally differs.
    m=dst/'SHA256SUMS.txt'
    if m.exists(): m.unlink()
    print(f'Clean selected-rerun workspace created at: {dst}')
    print('Follow RUN_ORDER.md, section A.')
if __name__=='__main__': main()
