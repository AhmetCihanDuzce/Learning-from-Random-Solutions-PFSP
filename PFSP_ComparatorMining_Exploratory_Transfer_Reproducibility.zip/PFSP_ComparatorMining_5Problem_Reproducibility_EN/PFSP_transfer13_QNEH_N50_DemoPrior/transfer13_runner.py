from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,time,csv,zipfile,hashlib
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
B1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
B10=(Path(__file__).resolve().parent.parent/'PFSP_transfer10_N50_BestArchivedFRB4_WarmStart')
sys.path.insert(0,str(B1))
import transfer01_runner as r
from external_comparator_comparators import qneh_time,cmax_numba,best_insert_ff,insert_at,validate_permutation
from run_pfsp_single import pfsp_cmax

ZPATH=(Path(__file__).resolve().parent.parent/'PFSP_external_comparator_FINAL_280of280_GREEN.zip')
PROBLEMS=['Ta50_10_1','Ta50_20_1']
DS=[1,3,5]
DEV_REPS=range(26,29)
VAL_REPS=range(31,36)
STRICT_REPS=range(36,41)
H=10


def seed_ext(pid,rep):
    _,ordn=r.seed_for(pid,1)
    return 820260000+100*ordn+rep,ordn

def load_problem(pid):
    row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row)
    return p,r.ub_for(pid)

def payload(pid,rep):
    with zipfile.ZipFile(ZPATH) as z:
        names=[n for n in z.namelist() if '/native_runs/' in n and f'_{pid}_r{rep:02d}.json' in n]
        assert len(names)==1,(pid,rep,names)
        return json.loads(z.read(names[0]))

def select_archive(pid):
    cand=[]
    for rep in range(1,11):
        d=payload(pid,rep)
        x=[x for x in d['framework']['variants'] if x['family']=='FRB4-p1' and x['mining']=='Contrast']; assert len(x)==1
        cand.append((int(x[0]['cmax']),rep,np.asarray(x[0]['seq'],dtype=np.int64),float(x[0]['guided_sec']),float(d['framework']['offline_sec'])))
    cand.sort(key=lambda z:(z[0],z[1]))
    return cand[0]

def fixed_budget(pid):
    return float(np.median([float(payload(pid,rep)['framework']['budget_sec']) for rep in range(1,11)]))

def build_demo_prior(p,action_order,passes,alpha=.5,gamma=.8):
    n=p.shape[0]; Q=np.zeros((n,n),dtype=np.float64); order=np.asarray(action_order,dtype=np.int64)
    assert validate_permutation(order,n)
    t0=time.perf_counter()
    last_c=None
    for _ in range(int(passes)):
        seq=np.empty(0,dtype=np.int64); remaining=np.arange(n,dtype=np.int64)
        for t in range(n):
            action=int(order[t]); assert np.any(remaining==action)
            pos,bestins_c,append_c,_=best_insert_ff(seq,action,p)
            next_seq=insert_at(seq,action,pos)
            reward=1.0/float(append_c)+(float(append_c)-float(bestins_c))/float(append_c)
            rem2=remaining[remaining!=action]
            nextmax=0.0 if t==n-1 else float(np.max(Q[t+1,rem2]))
            Q[t,action]+=alpha*(reward+gamma*nextmax-Q[t,action])
            seq=next_seq; remaining=rem2
        last_c=int(cmax_numba(seq,p))
    return Q,time.perf_counter()-t0,int(last_c)

def qneh_from_prior(p,seed,time_limit_sec,Q0,epsilon=.5,alpha=.5,gamma=.8):
    n=p.shape[0]; rng=np.random.default_rng(seed); Q=np.asarray(Q0,dtype=np.float64).copy()
    best_c=2**63-1; best_seq=None; episodes=0
    t0=time.perf_counter()
    while episodes==0 or (time.perf_counter()-t0)<float(time_limit_sec):
        seq=np.empty(0,dtype=np.int64); remaining=np.arange(n,dtype=np.int64)
        for t in range(n):
            if rng.random()<epsilon:
                action=int(remaining[int(rng.integers(0,remaining.size))])
            else:
                action=int(remaining[int(np.argmax(Q[t,remaining]))])
            pos,bestins_c,append_c,_=best_insert_ff(seq,action,p)
            next_seq=insert_at(seq,action,pos)
            reward=1.0/float(append_c)+(float(append_c)-float(bestins_c))/float(append_c)
            rem2=remaining[remaining!=action]
            nextmax=0.0 if t==n-1 else float(np.max(Q[t+1,rem2]))
            Q[t,action]+=alpha*(reward+gamma*nextmax-Q[t,action])
            seq=next_seq; remaining=rem2
        c=int(cmax_numba(seq,p)); episodes+=1
        if c<best_c: best_c=c; best_seq=seq.copy()
    elapsed=time.perf_counter()-t0
    return {'algorithm':'Q-NEH+MinedDemoPrior','seed':int(seed),'time_limit_sec':float(time_limit_sec),'cmax':int(best_c),'seq':best_seq,
            'elapsed_sec':float(elapsed),'episodes':int(episodes),'overrun_sec':max(0.,float(elapsed)-float(time_limit_sec)),
            'q_nonzero_final':int(np.count_nonzero(Q)),'q_nonzero_prior':int(np.count_nonzero(Q0))}

def qa(x,p,n): return bool(validate_permutation(x['seq'],n) and int(pfsp_cmax(x['seq'],p))==int(x['cmax']))

def prep_sources():
    src={}
    for pid in PROBLEMS:
        p,ub=load_problem(pid); wc,wrep,wseq,wguided,woff=select_archive(pid); B=fixed_budget(pid)
        assert int(pfsp_cmax(wseq,p))==wc
        src[pid]={'source_rep':wrep,'warm_cmax':wc,'warm_seq':wseq,'source_guided_sec':wguided,'source_offline_sec':woff,'budget_sec':B,'ub':ub,'p':p}
    return src

def run_dev(src):
    out=HERE/'development'; out.mkdir(exist_ok=True)
    baselines={}
    priors={}
    for pid in PROBLEMS:
        s=src[pid]; p=s['p']; n=p.shape[0]; B=s['budget_sec']; ub=s['ub']
        for D in DS:
            Q0,prep,lastc=build_demo_prior(p,s['warm_seq'],D); priors[(pid,D)]=(Q0,prep,lastc)
        for rep in DEV_REPS:
            seed,_=seed_ext(pid,rep)
            fb=out/f'{pid}_r{rep:02d}_base.json'
            if fb.exists(): bd=json.loads(fb.read_text())
            else:
                b=qneh_time(p,seed,B); ok=qa(b,p,n)
                bd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'budget_sec':B,'cmax':int(b['cmax']),'rpd':100*(b['cmax']-ub)/ub,'elapsed_sec':b['elapsed_sec'],'episodes':b['episodes'],'qa':ok}
                fb.write_text(json.dumps(bd,indent=2)); print('DEV BASE',pid,rep,bd['cmax'],b['episodes'],flush=True)
            baselines[(pid,rep)]=bd
            for D in DS:
                fg=out/f'{pid}_r{rep:02d}_D{D}.json'
                if fg.exists(): continue
                Q0,prep,lastc=priors[(pid,D)]
                g=qneh_from_prior(p,seed,B,Q0); ok=qa(g,p,n)
                gd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'D':D,'budget_sec':B,'source_rep':s['source_rep'],'warm_cmax':s['warm_cmax'],
                    'prior_prepare_sec':prep,'prior_demo_constructed_cmax':lastc,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(g['cmax']),'rpd':100*(g['cmax']-ub)/ub,
                    'delta_rpd':100*(g['cmax']-bd['cmax'])/ub,'elapsed_sec':g['elapsed_sec'],'episodes':g['episodes'],'qa':ok,'q_nonzero_prior':g['q_nonzero_prior']}
                fg.write_text(json.dumps(gd,indent=2)); print('DEV GUID',pid,rep,'D',D,gd['cmax'],gd['delta_rpd'],g['episodes'],flush=True)

def select_D():
    data=[json.loads(f.read_text()) for f in sorted((HERE/'development').glob('*_D*.json'))]
    rows=[]
    for D in DS:
        z=[x for x in data if x['D']==D]; assert len(z)==len(PROBLEMS)*len(list(DEV_REPS))
        ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        rows.append({'D':D,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,
                    'mean_guided_rpd':float(np.mean([x['rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z]))})
    rows.sort(key=lambda x:(x['mean_delta_rpd'],-x['wins'],x['D']))
    for i,x in enumerate(rows,1): x['rank']=i; x['selected']=i==1
    with open(HERE/'transfer13_development_summary.csv','w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)
    sel=rows[0]['D']; (HERE/'transfer13_selection.json').write_text(json.dumps({'rule':'lowest mean delta RPD; ties -> more wins -> smaller D','selected_D':sel,'ranked':rows},indent=2))
    print('SELECT D',sel,rows,flush=True); return sel

def run_validation(src,D):
    out=HERE/'validation'; out.mkdir(exist_ok=True)
    for pid in PROBLEMS:
        s=src[pid]; p=s['p']; n=p.shape[0]; B=s['budget_sec']; ub=s['ub']; Q0,prep,lastc=build_demo_prior(p,s['warm_seq'],D)
        for rep in VAL_REPS:
            seed,_=seed_ext(pid,rep); fb=out/f'{pid}_r{rep:02d}_base.json'; fg=out/f'{pid}_r{rep:02d}_guided.json'
            if fb.exists(): bd=json.loads(fb.read_text())
            else:
                b=qneh_time(p,seed,B); ok=qa(b,p,n); bd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'budget_sec':B,'cmax':int(b['cmax']),'rpd':100*(b['cmax']-ub)/ub,'elapsed_sec':b['elapsed_sec'],'episodes':b['episodes'],'qa':ok}; fb.write_text(json.dumps(bd,indent=2)); print('VAL BASE',pid,rep,bd['cmax'],b['episodes'],flush=True)
            if not fg.exists():
                g=qneh_from_prior(p,seed,B,Q0); ok=qa(g,p,n); gd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'D':D,'budget_sec':B,'source_rep':s['source_rep'],'warm_cmax':s['warm_cmax'],'source_offline_sec':s['source_offline_sec'],'source_guided_sec':s['source_guided_sec'],'prior_prepare_sec':prep,'prior_demo_constructed_cmax':lastc,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(g['cmax']),'rpd':100*(g['cmax']-ub)/ub,'delta_rpd':100*(g['cmax']-bd['cmax'])/ub,'elapsed_sec':g['elapsed_sec'],'episodes':g['episodes'],'qa':ok,'q_nonzero_prior':g['q_nonzero_prior']}; fg.write_text(json.dumps(gd,indent=2)); print('VAL GUID',pid,rep,gd['cmax'],gd['delta_rpd'],g['episodes'],flush=True)

def summarize_folder(folder,name):
    rows=[]
    for pid in PROBLEMS:
        z=[json.loads(f.read_text()) for f in sorted((HERE/folder).glob(f'{pid}_r*_guided.json'))]; assert len(z)==5,(folder,pid,len(z))
        ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        rows.append({'problem':pid,'n_pairs':5,'D':z[0]['D'],'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,
                     'mean_guided_rpd':float(np.mean([x['rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),
                     'guided_best_cmax':min(x['cmax'] for x in z),'baseline_best_cmax':min(x['baseline_cmax'] for x in z),
                     'mean_guided_episodes':float(np.mean([x['episodes'] for x in z]))})
    with open(HERE/name,'w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)
    return rows

def run_strict(src,D):
    out=HERE/'strict_h10'; out.mkdir(exist_ok=True)
    for pid in PROBLEMS:
        s=src[pid]; p=s['p']; n=p.shape[0]; B=s['budget_sec']; ub=s['ub']; Q0,prep,lastc=build_demo_prior(p,s['warm_seq'],D)
        prep_total=float(s['source_offline_sec']+s['source_guided_sec']+prep); charge=prep_total/H; g_budget=B-charge
        assert g_budget>0
        for rep in STRICT_REPS:
            seed,_=seed_ext(pid,rep); fb=out/f'{pid}_r{rep:02d}_base.json'; fg=out/f'{pid}_r{rep:02d}_guided.json'
            if fb.exists(): bd=json.loads(fb.read_text())
            else:
                b=qneh_time(p,seed,B); ok=qa(b,p,n); bd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'budget_sec':B,'cmax':int(b['cmax']),'rpd':100*(b['cmax']-ub)/ub,'elapsed_sec':b['elapsed_sec'],'episodes':b['episodes'],'qa':ok}; fb.write_text(json.dumps(bd,indent=2)); print('STRICT BASE',pid,rep,bd['cmax'],b['episodes'],flush=True)
            if not fg.exists():
                g=qneh_from_prior(p,seed,g_budget,Q0); ok=qa(g,p,n); gd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'D':D,'total_budget_sec':B,'guided_online_budget_sec':g_budget,'source_offline_sec':s['source_offline_sec'],'source_guided_sec':s['source_guided_sec'],'prior_prepare_sec':prep,'prep_total_sec':prep_total,'amortized_charge_sec':charge,'accounted_total_sec':g_budget+charge,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(g['cmax']),'rpd':100*(g['cmax']-ub)/ub,'delta_rpd':100*(g['cmax']-bd['cmax'])/ub,'elapsed_sec':g['elapsed_sec'],'episodes':g['episodes'],'qa':ok}; fg.write_text(json.dumps(gd,indent=2)); print('STRICT GUID',pid,rep,gd['cmax'],gd['delta_rpd'],g['episodes'],flush=True)

def finalize(D,val_rows,strict_rows=None):
    alljson=list(HERE.rglob('*.json')); qa_all=True
    for f in alljson:
        d=json.loads(f.read_text())
        if isinstance(d,dict) and 'status' in d and d['status'] not in ('GREEN',): qa_all=False
    report=['# transfer experiment 13 Report — n=50 mined-demonstration prior Q-NEH','',f'QA: {"GREEN" if qa_all else "RED"}','',f'Selected common n=50 teacher passes: D={D}.','', '## Equal-online independent validation']
    for x in val_rows: report.append(f'- {x["problem"]}: mean ΔRPD={x["mean_delta_rpd"]:.6f}, W/T/L={x["wins"]}/{x["ties"]}/{x["losses"]}, guided-best={x["guided_best_cmax"]}, baseline-best={x["baseline_best_cmax"]}.')
    if strict_rows is not None:
        report += ['', '## Strict H=10 equal-total-budget audit']
        for x in strict_rows: report.append(f'- {x["problem"]}: mean ΔRPD={x["mean_delta_rpd"]:.6f}, W/T/L={x["wins"]}/{x["ties"]}/{x["losses"]}, guided-best={x["guided_best_cmax"]}, baseline-best={x["baseline_best_cmax"]}.')
    (HERE/'transfer13_REPORT.md').write_text('\n'.join(report)+'\n')
    qa={'status':'GREEN' if qa_all else 'RED','selected_D':D,'equal_online_both_favorable':all(x['mean_delta_rpd']<0 for x in val_rows),'strict_h10_run':strict_rows is not None,'all_permutation_cmax_qa':qa_all}
    (HERE/'transfer13_MASTER_QA.json').write_text(json.dumps(qa,indent=2))
    files=[p for p in HERE.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt' and not p.name.endswith('.zip')]
    with open(HERE/'SHA256SUMS.txt','w') as f:
        for p in sorted(files): f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(HERE))+'\n')
    zp=(Path(__file__).resolve().parent.parent/'PFSP_transfer13_QNEH_N50_DemoPrior_GREEN.zip')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.rglob('*')):
            if p.is_file(): z.write(p,arcname=str(Path(HERE.name)/p.relative_to(HERE)))
    with zipfile.ZipFile(zp) as z: bad=z.testzip()
    print('FINAL',qa,'zip',zp,'bad',bad,flush=True)

def main():
    r.warmup(); src=prep_sources(); run_dev(src); D=select_D(); run_validation(src,D); val_rows=summarize_folder('validation','transfer13_validation_summary.csv')
    strict_rows=None
    if all(x['mean_delta_rpd']<0 for x in val_rows):
        run_strict(src,D); strict_rows=summarize_folder('strict_h10','transfer13_strict_h10_summary.csv')
    finalize(D,val_rows,strict_rows)

if __name__=='__main__': main()
