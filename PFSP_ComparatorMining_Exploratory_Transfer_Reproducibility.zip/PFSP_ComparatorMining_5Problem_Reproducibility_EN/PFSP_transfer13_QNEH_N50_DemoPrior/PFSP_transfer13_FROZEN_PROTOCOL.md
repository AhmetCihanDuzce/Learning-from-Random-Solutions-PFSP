# PFSP transfer experiment 13 — n=50 mined-demonstration prior for Q-NEH

Status: FROZEN BEFORE EXECUTION.
Nature: targeted exploratory n=50 comparator-integration study; it does not replace the exploratory transfer analysis confirmatory comparator panel.

## Objective
Test whether the already-mined FRB4-p1 | Contrast information can improve Q-NEH on the two n=50 hard comparator cases through a low-overhead interface that leaves the online Q-NEH mechanism unchanged.

## Targets
- Ta50_10_1
- Ta50_20_1

## Mined source
For each target, use exactly the best archived external-comparator analysis `FRB4-p1 | Contrast` schedule already selected in transfer experiment 10, based only on the ten historical external-comparator analysis mining replications and before the present Q-NEH runs:
- Ta50_10_1: external-comparator analysis rep 4, Cmax 3090.
- Ta50_20_1: external-comparator analysis rep 7, Cmax 4003.
No Q-NEH result is used to select the source schedule.

## Integration mechanism: reusable demonstration Q-prior
The mined schedule is treated as one deterministic demonstration action order. Starting from Q=0, a teacher pass replays that job order through the unmodified Q-NEH insertion/reward/Q-update equations (epsilon-greedy selection is bypassed only during this offline replay). The resulting Q table is stored as an offline reusable prior. Online Q-NEH then starts from this Q table instead of an all-zero table.

During online search, exploration probability, exploitation rule, insertion objective, reward, alpha=0.5, gamma=0.8, epsilon=0.5, time stopping, and all remaining Q-NEH logic are exactly unchanged. No P/R score is queried online.

## Development grid
Teacher passes D in {1, 3, 5}. One common n=50 D is selected across both targets.
Development seeds: fresh rep extensions 26..28 for each target.
Primary development budget: equal online wall-clock budget for standard and prior-seeded Q-NEH, equal to the median original external-comparator analysis comparator budget for that problem.
Selection rule: lowest mean paired Delta RPD (guided - baseline) across all six development pairs; ties -> more wins -> smaller D.

## Independent validation
Fresh rep extensions 31..35 for both targets. The selected D is frozen before these validation runs.
Primary validation: equal online budget, 5 paired runs per target.

## Strict reusable-cost audit
If the selected prior has favorable mean Delta RPD on both validation targets, additionally run an H=10 strict equal-total-budget audit on the same frozen D and fresh rep extensions 36..40.
The one-time knowledge-preparation cost is the selected external-comparator analysis source replication's offline mining time + its FRB4-p1 Contrast guided construction time + one Q-prior preparation time. One tenth of that cost is charged per prospective use. Baseline Q-NEH receives the full fixed total budget B; prior-seeded Q-NEH receives B - preparation_cost/10 online seconds. Both therefore have equal accounted total budget B.

## Outcomes
Per target report mean/median paired Delta RPD, W/T/L, mean RPD, batch-best Cmax, episodes, preparation time, and QA. Negative Delta RPD favors mining-informed Q-NEH.

All results, favorable or unfavorable, are retained.
