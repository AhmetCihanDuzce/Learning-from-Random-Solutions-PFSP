# transfer experiment 13 Report — n=50 mined-demonstration prior Q-NEH

QA: GREEN

Selected common n=50 teacher passes: D=5.

## Equal-online independent validation
- Ta50_10_1: mean ΔRPD=0.247409, W/T/L=1/0/4, guided-best=3071, baseline-best=3067.
- Ta50_20_1: mean ΔRPD=-0.093506, W/T/L=3/0/2, guided-best=3988, baseline-best=3996.
