# transfer experiment 11 Report

QA: GREEN

Selected theta n=50: 0.05; n=100: 0.05.

## Validation
- Ta50_10_1: mean ΔRPD=0.093614, W/T/L=1/0/4, guided-best=3084, baseline-best=3080.
- Ta50_20_1: mean ΔRPD=0.207792, W/T/L=1/0/4, guided-best=3989, baseline-best=3971.
- Ta100_20_1: mean ΔRPD=-0.003225, W/T/L=3/0/2, guided-best=6437, baseline-best=6449.
- Ta100_20_10: mean ΔRPD=0.090146, W/T/L=2/0/3, guided-best=6621, baseline-best=6622.
- VFR100_40_10: mean ΔRPD=-0.067907, W/T/L=3/0/2, guided-best=8245, baseline-best=8246.
