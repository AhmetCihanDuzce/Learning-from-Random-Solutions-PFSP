from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,time,csv,hashlib,zipfile
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
B1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
B2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias')
sys.path.insert(0,str(B1))
import transfer01_runner as r
from external_comparator_comparators import qneh_time,cmax_numba,best_insert_ff,insert_at,validate_permutation
from run_pfsp_single import pfsp_cmax

THETAS=[0.02,0.05,0.10,0.20]
DEV50=['Ta50_10_1','Ta50_20_1']; DEV100=['Ta100_20_1']; DEV_REPS=range(1,4)
VAL=['Ta50_10_1','Ta50_20_1','Ta100_20_1','Ta100_20_10','VFR100_40_10']; VAL_REPS=range(6,11)
H=10

def p_action_score(seq,candidates,P):
    arr=np.asarray(seq,dtype=np.int64); k=arr.size
    cands=np.sort(np.asarray(candidates,dtype=np.int64))
    if cands.size==1: return int(cands[0])
    best_job=int(cands[0]); best_s=-1e300
    if k==0:
        # no positional evidence yet: row-net precedence tendency as deterministic P-only prior
        # same P matrix, no extra data. Higher outward precedence score means earlier tendency.
        vals=P[cands,:].sum(axis=1)
        mx=float(np.max(vals)); return int(cands[np.flatnonzero(vals==mx)[0]])
    for jj in cands:
        j=int(jj)
        a=P[arr,j].astype(float,copy=False)   # scheduled job before candidate if inserted after
        b=P[j,arr].astype(float,copy=False)   # candidate before scheduled job if inserted before
        pref=np.empty(k+1,dtype=float); pref[0]=0.; pref[1:]=np.cumsum(a)
        suff=np.empty(k+1,dtype=float); suff[k]=0.; suff[:k]=np.cumsum(b[::-1])[::-1]
        s=float(np.max((pref+suff)/float(k)))
        if s>best_s+1e-15:
            best_s=s; best_job=j
    return best_job

def qneh_neartie(p,seed,time_limit_sec,P,theta,epsilon=.5,alpha=.5,gamma=.8):
    n,m=p.shape; rng=np.random.default_rng(seed); Q=np.zeros((n,n),dtype=float)
    best_c=2**63-1; best_seq=None; episodes=0; guided=0; exploit=0; cand_sum=0; cand_max=0
    t0=time.perf_counter()
    while episodes==0 or (time.perf_counter()-t0)<float(time_limit_sec):
        seq=np.empty(0,dtype=np.int64); remaining=np.arange(n,dtype=np.int64)
        for t in range(n):
            if rng.random()<epsilon:
                action=int(remaining[int(rng.integers(0,remaining.size))])
            else:
                exploit+=1
                vals=Q[t,remaining]; mx=float(np.max(vals)); mn=float(np.min(vals)); span=mx-mn
                if span<=1e-18:
                    cand=remaining
                else:
                    tol=float(theta)*span
                    cand=remaining[(mx-vals)<=tol+1e-18]
                if cand.size>1:
                    action=p_action_score(seq,cand,P); guided+=1; cand_sum+=int(cand.size); cand_max=max(cand_max,int(cand.size))
                else:
                    action=int(cand[0])
            pos,bestins_c,append_c,_=best_insert_ff(seq,action,p)
            next_seq=insert_at(seq,action,pos)
            reward=1.0/float(append_c)+(float(append_c)-float(bestins_c))/float(append_c)
            rem2=remaining[remaining!=action]
            nextmax=0.0 if t==n-1 else float(np.max(Q[t+1,rem2]))
            Q[t,action]+=alpha*(reward+gamma*nextmax-Q[t,action])
            seq=next_seq; remaining=rem2
        c=int(cmax_numba(seq,p)); episodes+=1
        if c<best_c: best_c=c; best_seq=seq.copy()
    elapsed=time.perf_counter()-t0
    return {'algorithm':'Q-NEH+ContrastP-neartie','seed':int(seed),'time_limit_sec':float(time_limit_sec),'theta':float(theta),
            'cmax':int(best_c),'seq':best_seq,'elapsed_sec':float(elapsed),'episodes':int(episodes),
            'overrun_sec':max(0.,float(elapsed)-float(time_limit_sec)),'q_nonzero':int(np.count_nonzero(Q)),
            'guided_nearties':int(guided),'exploit_actions':int(exploit),'guided_fraction':float(guided/max(1,exploit)),
            'mean_candidate_size_when_guided':float(cand_sum/max(1,guided)),'max_candidate_size':int(cand_max)}

def qa(res,p,n):
    return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))

def load_pc(pid,rep):
    f=B2/'cache'/f'{pid}_r{rep:02d}_PC.npz'; z=np.load(f)
    return z['PC'],float(z['offline_sec'])

def dev_baseline(pid,rep):
    seed,ordn=r.seed_for(pid,rep)
    f=B1/'online_matched_baseline'/f'{ordn:02d}_{pid}_r{rep:02d}.json'; d=json.loads(f.read_text())
    return int(d['Q-NEH']['cmax']),float(d['g8_sec'])

def run_dev():
    out=HERE/'development'; out.mkdir(exist_ok=True)
    for pid in DEV50+DEV100:
      row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid)
      for rep in DEV_REPS:
        seed,ordn=r.seed_for(pid,rep); base_c,g8=dev_baseline(pid,rep); P,_=load_pc(pid,rep)
        for th in THETAS:
          fn=out/f'{ordn:02d}_{pid}_r{rep:02d}_th{int(round(th*100)):02d}.json'
          if fn.exists(): continue
          rr=qneh_neartie(p,seed,g8,P,th); ok=qa(rr,p,n)
          d={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'n':n,'reference_ub':ub,'g8_sec':g8,
             'theta':th,'baseline_cmax':base_c,'baseline_rpd':100*(base_c-ub)/ub,'cmax':int(rr['cmax']),
             'rpd':100*(rr['cmax']-ub)/ub,'delta_rpd':100*(rr['cmax']-base_c)/ub,'elapsed_sec':rr['elapsed_sec'],'qa':ok,
             'details':{k:v for k,v in rr.items() if k not in ('seq','cmax','elapsed_sec')}}
          fn.write_text(json.dumps(d,indent=2)); print('DEV',pid,rep,th,d['cmax'],d['delta_rpd'],rr['episodes'],flush=True)

def summarize_dev():
    data=[json.loads(f.read_text()) for f in sorted((HERE/'development').glob('*.json'))]
    rows=[]; select={}
    for stratum,pids in [('n50',DEV50),('n100',DEV100)]:
      rr=[]
      for th in THETAS:
        z=[x for x in data if x['problem'] in pids and abs(x['theta']-th)<1e-12]
        ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        rr.append({'stratum':stratum,'theta':th,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),
                   'wins':w,'ties':t,'losses':l,'mean_guided_fraction':float(np.mean([x['details']['guided_fraction'] for x in z])),
                   'mean_episodes':float(np.mean([x['details']['episodes'] for x in z]))})
      rr.sort(key=lambda x:(x['mean_delta_rpd'],-x['wins'],x['theta']))
      for i,x in enumerate(rr,1): x['rank']=i; x['selected']=i==1
      select[stratum]=rr[0]['theta']; rows.extend(rr)
    with open(HERE/'transfer11_development_summary.csv','w',newline='') as f:
      w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    (HERE/'transfer11_selection.json').write_text(json.dumps({'rule':'lowest mean delta RPD, ties -> more wins -> smaller theta','selected':select,'ranked':rows},indent=2))
    return select

def run_val(select):
    out=HERE/'validation'; out.mkdir(exist_ok=True)
    for pid in VAL:
      row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid)
      P,off=load_pc(pid,1); th=select['n50' if n==50 else 'n100']
      for rep in VAL_REPS:
        seed,ordn=r.seed_for(pid,rep); g8,_,_=r.external_comparator_max_guided(pid,rep); base_budget=g8+off/H
        fb=out/f'{ordn:02d}_{pid}_r{rep:02d}_base.json'; fg=out/f'{ordn:02d}_{pid}_r{rep:02d}_guided.json'
        if fb.exists(): bd=json.loads(fb.read_text())
        else:
          br=qneh_time(p,seed,base_budget); ok=qa(br,p,n); bd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'budget_sec':base_budget,'cmax':int(br['cmax']),'rpd':100*(br['cmax']-ub)/ub,'elapsed_sec':br['elapsed_sec'],'qa':ok,'episodes':br['episodes'],'overrun_sec':br['overrun_sec']}; fb.write_text(json.dumps(bd,indent=2)); print('VAL BASE',pid,rep,bd['cmax'],br['episodes'],flush=True)
        if not fg.exists():
          gr=qneh_neartie(p,seed,g8,P,th); ok=qa(gr,p,n); gd={'status':'GREEN' if ok else 'RED','problem':pid,'rep':rep,'seed':seed,'theta':th,'g8_sec':g8,'offline_sec':off,'amortized_offline_sec':off/H,
             'accounted_total_sec':g8+off/H,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(gr['cmax']),'rpd':100*(gr['cmax']-ub)/ub,'delta_rpd':100*(gr['cmax']-bd['cmax'])/ub,
             'elapsed_sec':gr['elapsed_sec'],'qa':ok,'details':{k:v for k,v in gr.items() if k not in ('seq','cmax','elapsed_sec')}}; fg.write_text(json.dumps(gd,indent=2)); print('VAL GUID',pid,rep,gd['cmax'],gd['delta_rpd'],gr['episodes'],flush=True)

def summarize_val(select):
    rows=[]
    for pid in VAL:
      z=[json.loads(f.read_text()) for f in sorted((HERE/'validation').glob(f'*_{pid}_r*_guided.json'))]
      assert len(z)==5,(pid,len(z)); ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=5-w-t
      rows.append({'problem':pid,'n':50 if pid.startswith('Ta50_') else 100,'theta':z[0]['theta'],'n_pairs':5,'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),
                   'wins':w,'ties':t,'losses':l,'mean_guided_rpd':float(np.mean([x['rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),
                   'guided_best_cmax':min(x['cmax'] for x in z),'baseline_best_cmax':min(x['baseline_cmax'] for x in z),'mean_offline_sec':float(np.mean([x['offline_sec'] for x in z])),
                   'amortized_offline_sec':float(np.mean([x['amortized_offline_sec'] for x in z])),'mean_guided_episodes':float(np.mean([x['details']['episodes'] for x in z])),
                   'mean_guided_fraction':float(np.mean([x['details']['guided_fraction'] for x in z]))})
    with open(HERE/'transfer11_validation_summary.csv','w',newline='') as f:
      w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    return rows

def finalize(select,rows):
    alljson=list((HERE/'development').glob('*.json'))+list((HERE/'validation').glob('*.json'))
    qa_all=all(json.loads(f.read_text()).get('status')=='GREEN' for f in alljson)
    report=['# transfer experiment 11 Report','',f'QA: {"GREEN" if qa_all else "RED"}','',f'Selected theta n=50: {select["n50"]}; n=100: {select["n100"]}.','', '## Validation']
    for x in rows: report.append(f'- {x["problem"]}: mean ΔRPD={x["mean_delta_rpd"]:.6f}, W/T/L={x["wins"]}/{x["ties"]}/{x["losses"]}, guided-best={x["guided_best_cmax"]}, baseline-best={x["baseline_best_cmax"]}.')
    (HERE/'transfer11_REPORT.md').write_text('\n'.join(report)+'\n')
    qa={'status':'GREEN' if qa_all else 'RED','development_json':len(list((HERE/'development').glob('*.json'))),'validation_json':len(list((HERE/'validation').glob('*.json'))),'selected_theta':select,'problems':len(rows),'all_permutation_cmax_qa':qa_all}
    (HERE/'transfer11_MASTER_QA.json').write_text(json.dumps(qa,indent=2))
    # hash manifest excluding itself/zip
    files=[p for p in HERE.rglob('*') if p.is_file() and p.name not in ('SHA256SUMS.txt',) and not p.name.endswith('.zip')]
    with open(HERE/'SHA256SUMS.txt','w') as f:
      for p in sorted(files): f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(HERE))+'\n')
    import zipfile
    zp=(Path(__file__).resolve().parent.parent/'PFSP_transfer11_QNEH_NearTie_GREEN.zip')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
      for p in sorted(HERE.rglob('*')):
        if p.is_file(): z.write(p,arcname=str(Path(HERE.name)/p.relative_to(HERE)))
    with zipfile.ZipFile(zp) as z: bad=z.testzip()
    print('FINAL',qa,'zip',zp,'bad',bad,flush=True)

def main():
    r.warmup(); run_dev(); sel=summarize_dev(); print('SELECT',sel,flush=True); run_val(sel); rows=summarize_val(sel); finalize(sel,rows)
if __name__=='__main__': main()
