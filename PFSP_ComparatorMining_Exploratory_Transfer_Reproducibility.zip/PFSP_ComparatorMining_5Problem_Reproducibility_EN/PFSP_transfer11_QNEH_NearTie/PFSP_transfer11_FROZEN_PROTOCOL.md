# PFSP transfer experiment 11 — Contrast-P Near-Tie Guidance for Q-NEH

Status: FROZEN BEFORE EXECUTION.
Nature: targeted exploratory train/validate pilot; does not replace the exploratory transfer analysis confirmatory comparator panel.

## Objective
Test whether already-mined Contrast precedence information can improve Q-NEH on the same five difficult comparator instances used in the QIG follow-up, while preserving the Q-NEH learning, reward, insertion objective, exploration probability, and time budget.

## Fixed mechanism
- Contrast-P only; R is not used.
- Exploration remains uniformly random exactly as in Q-NEH.
- During exploitation, let q_max and q_min be the maximum/minimum Q values among remaining jobs at the current scheduling analysis phase.
- A job is a near-tie candidate when `(q_max - q_j) <= theta * (q_max - q_min)`; if q_max=q_min, all remaining jobs are candidates.
- If one candidate remains, standard Q-NEH action is used. If multiple candidates remain, choose the candidate whose best-achievable Contrast-P insertion score over all positions is largest. Stable smallest job index breaks exact structural ties.
- The selected job is then inserted at the Cmax-best FF position exactly as in Q-NEH; reward/Q update is unchanged.

Thus P-information may only alter exploitation among Q-near-best actions. It does not alter exploration, insertion evaluation, reward, alpha, gamma, epsilon, or the Q update.

## Development grid
Theta in {0.02, 0.05, 0.10, 0.20}. No other parameter is searched.
Development problems/reps:
- n=50 stratum: Ta50_10_1 and Ta50_20_1, reps 1..3 (6 paired runs per theta).
- n=100 stratum: Ta100_20_1, reps 1..3 (3 paired runs per theta).
Rep-specific archived transfer experiment 02 S=10,000n Contrast-P matrices are used for development. Baseline Q-NEH values are the already-completed transfer experiment 01 equal-online baselines at the exact G8 budget.

Frozen selection rule separately by n stratum: lowest mean paired Delta RPD; ties -> more wins, then smaller theta.

## Independent validation
Problems:
1. Ta50_10_1
2. Ta50_20_1
3. Ta100_20_1
4. Ta100_20_10
5. VFR100_40_10

Evaluation reps: external-comparator analysis reps 6..10 (R=5/problem), disjoint from development reps.
For each problem, use the archived transfer experiment 02 replication-1 S=10,000n Contrast-P matrix and its measured fresh-mining wall time; source is fixed by replication number, not screened by solution quality.

## Equal-budget accounting
Reuse horizon H=10. For each evaluation replication r:
- guided Q-NEH receives G8_r online seconds;
- unguided Q-NEH receives G8_r + T_off_source/10 online seconds.
The guided scheme is therefore charged one tenth of its one-time mining cost per prospective use.

## Outcomes
Per problem report mean/median paired Delta RPD = guided - equal-budget baseline, W/T/L, mean RPD, batch-best Cmax, episode counts, near-tie guidance counts, and timer overrun. Negative Delta RPD favors mining.

## Interpretation
Exploratory selected-instance evidence only. No universal superiority claim. Both favorable and unfavorable results must be retained.
