# Data dictionary

## Common performance fields

- `cmax`, `guided_cmax`: best makespan returned by the mining-informed comparator.
- `baseline_cmax`: best makespan returned by the corresponding comparator without the added mining interface.
- `rpd`, `guided_rpd`: relative percentage deviation from the frozen reference UB.
- `baseline_rpd`: baseline relative percentage deviation.
- `delta_rpd`: guided RPD minus baseline RPD, in percentage points. **Negative values favor the mining-informed comparator.**
- `wins/ties/losses`: paired comparisons at the replication level, where a win means guided Cmax < baseline Cmax.

## Time/accounting fields

- `g8_sec`: frozen external-comparator analysis online comparator budget component for the corresponding problem/replication.
- `offline_sec`, `source_offline_sec`: measured time of the reusable mining source used by the follow-up experiment.
- `allocated_mining_sec`, `amortized_offline_sec`, `amortized_charge_sec`: per-run mining cost allocated under reuse horizon H=10.
- `guided_online_budget_sec`: wall-clock time available to the mining-informed online comparator.
- `equal_budget_baseline_sec`, `total_budget_sec`, `accounted_total_sec`: total budget/accounting fields used by the corresponding analysis phase protocol.

## Mining-interface fields

- `lambda`: soft structural-bias weight used in QIG destruction selection.
- `theta`: near-tie threshold used by Q-NEH.
- `D`: number of demonstration/order-prior passes used to initialize the Q-NEH Q-table.
- `reuse_horizon`: number of comparator runs over which mining cost is amortized.
- `warmstart_cmax`: Cmax of the archived mined FRB4-p1 Contrast schedule used as QIG initial solution in the n=50 warm-start experiment.

## QA fields

- `status=GREEN`: all analysis phase-specific validity checks passed.
- `qa`, `qa_guided`, `qa_baseline`: permutation validity and independent Cmax recomputation checks.
