# transfer experiment 16 Report — Combined Contrast-P prior + near-tie Q-NEH

QA: GREEN

Frozen interface: D=3 Contrast-P order prior + theta=0.05 optimized near-tie Contrast-P selection. No parameter tuning was performed in this analysis phase.

Equal-online validation: mean ΔRPD=-0.080821, median=0.031085, W/T/L=2/0/3, mean RPD guided/base=2.949953/3.030774, best Cmax guided/base=6612/6604.

Strict H=10 reusable-cost audit: mean ΔRPD=-0.015542, median=0.093255, W/T/L=2/0/3, mean RPD guided/base=2.906435/2.921977, best Cmax guided/base=6599/6610.
