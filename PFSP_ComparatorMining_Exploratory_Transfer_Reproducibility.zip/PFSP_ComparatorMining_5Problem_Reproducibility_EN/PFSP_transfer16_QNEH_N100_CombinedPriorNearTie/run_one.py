import sys,json,numpy as np
import transfer16_runner as x, transfer01_runner as r
from external_comparator_comparators import qneh_time
rep=int(sys.argv[1]); mode=sys.argv[2]
r.warmup(); s,Q0,prep,lastc=x.source(); p=s['p']; n=p.shape[0]; ub=s['ub']; B=float(s['budget_sec']); folder='strict_h10'; out=x.HERE/folder; out.mkdir(exist_ok=True)
seed,_=x.b13.seed_ext(x.PID,rep)
if mode=='base':
    br=qneh_time(p,seed,B); ok=x.qa(br,p,n); d={'status':'GREEN' if ok else 'RED','problem':x.PID,'rep':rep,'seed':seed,'budget_sec':B,'cmax':int(br['cmax']),'rpd':100*(br['cmax']-ub)/ub,'episodes':int(br['episodes']),'elapsed_sec':float(br['elapsed_sec']),'qa':ok}; (out/f'{x.PID}_r{rep:02d}_base.json').write_text(json.dumps(d,indent=2)); print(json.dumps(d))
elif mode=='guided':
    fb=out/f'{x.PID}_r{rep:02d}_base.json'; bd=json.loads(fb.read_text()); charge=(float(s['offline_sec'])+prep)/x.H; gB=B-charge
    x.b12.p_action_score_fast(np.empty(0,dtype=np.int64),np.array([0,1],dtype=np.int64),s['P'])
    gr=x.qneh_combined(p,seed,gB,Q0,s['P'],x.THETA); ok=x.qa(gr,p,n); d={'status':'GREEN' if ok else 'RED','problem':x.PID,'rep':rep,'seed':seed,'D':x.D,'theta':x.THETA,'total_budget_sec':B,'guided_online_budget_sec':gB,'source_offline_sec':float(s['offline_sec']),'prior_prepare_sec':prep,'amortized_charge_sec':charge,'accounted_total_sec':gB+charge,'prior_demo_constructed_cmax':lastc,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(gr['cmax']),'rpd':100*(gr['cmax']-ub)/ub,'delta_rpd':100*(gr['cmax']-bd['cmax'])/ub,'episodes':int(gr['episodes']),'elapsed_sec':float(gr['elapsed_sec']),'qa':ok,'details':{k:v for k,v in gr.items() if k not in ('seq','cmax','elapsed_sec')}}; (out/f'{x.PID}_r{rep:02d}_guided.json').write_text(json.dumps(d,indent=2)); print(json.dumps(d))
else: raise SystemExit('mode')
