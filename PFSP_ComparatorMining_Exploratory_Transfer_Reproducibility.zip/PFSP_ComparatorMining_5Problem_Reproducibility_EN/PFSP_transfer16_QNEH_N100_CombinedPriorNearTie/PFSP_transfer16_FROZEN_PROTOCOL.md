# PFSP transfer experiment 16 — Combined Contrast-P prior + near-tie Q-NEH on Ta100_20_10

Status: FROZEN BEFORE EXECUTION.
Nature: targeted exploratory comparator-integration study. No claim of generality is permitted from this single-problem experiment.

## Objective
Test whether combining the two already-defined mining interfaces can improve Q-NEH on the remaining difficult Ta100_20_10 case without altering the original Q-learning update, insertion operator, exploration probability, reward, alpha or gamma.

## Fixed mined source
Use the archived transfer experiment 02 S=10,000n Contrast-P matrix for Ta100_20_10, source replication 1. No source screening is performed using the present outcomes.

## Frozen combined interface
1. Build the Contrast-P net-strength job order exactly as transfer experiment 15.
2. Initialize Q using D=3 teacher passes, the value selected before transfer experiment 15 validation.
3. During online exploitation, apply the optimized transfer experiment 12 near-tie rule with theta=0.05, the previously frozen n=100 value. If more than one remaining job is within theta times the current Q-span of the maximum Q value, use the same Contrast-P insertion-compatible structural score to choose among those near-tied jobs.
4. Exploration, best insertion, reward, alpha=0.5, gamma=0.8, epsilon=0.5, Q update, and stopping rule remain unchanged.

No new parameter is tuned in transfer experiment 16.

## Equal-online validation
Target: Ta100_20_10 only.
Fresh seed extensions: 81..85.
Baseline Q-NEH and combined guided Q-NEH receive the same online wall-clock budget: the same fixed median external-comparator analysis comparator budget used in transfer experiment 15.
Primary paired outcome: Delta RPD = guided RPD - baseline RPD. Negative favors mining-informed Q-NEH.
Report W/T/L, mean and median Delta RPD, mean RPD, best Cmax, episodes, guidance usage, and permutation/Cmax QA.

## Strict reusable-cost audit
Only if equal-online mean Delta RPD < 0.
Fresh seed extensions: 86..90.
Reuse horizon H=10.
Baseline receives total budget B.
Guided online budget = B - (archived source mining time + measured prior-construction time)/10.
Report the same paired outcomes. This strict audit tests whether the benefit survives amortized mining/preparation cost.

## Stop rule
If equal-online validation is not favorable, do not run further parameter searches under this analysis phase. All outcomes are retained.
