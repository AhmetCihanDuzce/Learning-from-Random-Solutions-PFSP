from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,time,csv,hashlib,zipfile
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
B1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
B12=(Path(__file__).resolve().parent.parent/'PFSP_transfer12_QNEH_OptimizedNearTie')
B13=(Path(__file__).resolve().parent.parent/'PFSP_transfer13_QNEH_N50_DemoPrior')
B15=(Path(__file__).resolve().parent.parent/'PFSP_transfer15_QNEH_N100_POrderPrior')
sys.path.insert(0,str(B1)); sys.path.insert(0,str(B12)); sys.path.insert(0,str(B13)); sys.path.insert(0,str(B15))
import transfer01_runner as r
import transfer12_runner as b12
import transfer13_runner as b13
import transfer15_runner as b15
from external_comparator_comparators import qneh_time,cmax_numba,best_insert_ff,insert_at,validate_permutation
from run_pfsp_single import pfsp_cmax

PID='Ta100_20_10'; D=3; THETA=.05; H=10
VAL_REPS=range(81,86); STRICT_REPS=range(86,91)

def qa(x,p,n): return bool(validate_permutation(x['seq'],n) and int(pfsp_cmax(x['seq'],p))==int(x['cmax']))

def qneh_combined(p,seed,time_limit_sec,Q0,P,theta=THETA,epsilon=.5,alpha=.5,gamma=.8):
    n=p.shape[0]; rng=np.random.default_rng(seed); Q=np.asarray(Q0,dtype=np.float64).copy()
    best_c=2**63-1; best_seq=None; episodes=0; guided=0; exploit=0; cand_sum=0; cand_max=0
    t0=time.perf_counter()
    while episodes==0 or (time.perf_counter()-t0)<float(time_limit_sec):
        seq=np.empty(0,dtype=np.int64); remaining=np.arange(n,dtype=np.int64)
        for t in range(n):
            if rng.random()<epsilon:
                action=int(remaining[int(rng.integers(0,remaining.size))])
            else:
                exploit+=1; vals=Q[t,remaining]; mx=float(np.max(vals)); mn=float(np.min(vals)); span=mx-mn
                if span<=1e-18: cand=remaining
                else: cand=remaining[(mx-vals)<=float(theta)*span+1e-18]
                if cand.size>1:
                    cand=np.sort(cand.astype(np.int64))
                    action=int(b12.p_action_score_fast(seq,cand,P)); guided+=1; cand_sum+=int(cand.size); cand_max=max(cand_max,int(cand.size))
                else: action=int(cand[0])
            pos,bestins_c,append_c,_=best_insert_ff(seq,action,p)
            next_seq=insert_at(seq,action,pos)
            reward=1.0/float(append_c)+(float(append_c)-float(bestins_c))/float(append_c)
            rem2=remaining[remaining!=action]
            nextmax=0.0 if t==n-1 else float(np.max(Q[t+1,rem2]))
            Q[t,action]+=alpha*(reward+gamma*nextmax-Q[t,action])
            seq=next_seq; remaining=rem2
        c=int(cmax_numba(seq,p)); episodes+=1
        if c<best_c: best_c=c; best_seq=seq.copy()
    elapsed=time.perf_counter()-t0
    return {'algorithm':'Q-NEH+ContrastP-prior-neartie','seed':int(seed),'theta':float(theta),'D':int(D),'cmax':int(best_c),'seq':best_seq,
            'elapsed_sec':float(elapsed),'episodes':int(episodes),'overrun_sec':max(0.,float(elapsed)-float(time_limit_sec)),
            'guided_nearties':int(guided),'exploit_actions':int(exploit),'guided_fraction':float(guided/max(1,exploit)),
            'mean_candidate_size_when_guided':float(cand_sum/max(1,guided)),'max_candidate_size':int(cand_max),
            'q_nonzero_prior':int(np.count_nonzero(Q0)),'q_nonzero_final':int(np.count_nonzero(Q))}

def source():
    s=b15.source_info(); Q0,prep,lastc=b13.build_demo_prior(s['p'],s['order'],D)
    return s,Q0,float(prep),int(lastc)

def run_set(s,Q0,prep,lastc,reps,folder,strict=False):
    out=HERE/folder; out.mkdir(exist_ok=True); p=s['p']; n=p.shape[0]; ub=s['ub']; B=float(s['budget_sec'])
    charge=(float(s['offline_sec'])+prep)/H if strict else 0.0; gB=B-charge
    assert gB>0,(B,charge)
    for rep in reps:
        seed,_=b13.seed_ext(PID,rep)
        fb=out/f'{PID}_r{rep:02d}_base.json'; fg=out/f'{PID}_r{rep:02d}_guided.json'
        if fb.exists(): bd=json.loads(fb.read_text())
        else:
            br=qneh_time(p,seed,B); ok=qa(br,p,n)
            bd={'status':'GREEN' if ok else 'RED','problem':PID,'rep':rep,'seed':seed,'budget_sec':B,'cmax':int(br['cmax']),'rpd':100*(br['cmax']-ub)/ub,
                'episodes':int(br['episodes']),'elapsed_sec':float(br['elapsed_sec']),'qa':ok}
            fb.write_text(json.dumps(bd,indent=2)); print(folder,'BASE',rep,bd['cmax'],bd['rpd'],bd['episodes'],flush=True)
        if fg.exists(): continue
        gr=qneh_combined(p,seed,gB,Q0,s['P'],THETA); ok=qa(gr,p,n)
        gd={'status':'GREEN' if ok else 'RED','problem':PID,'rep':rep,'seed':seed,'D':D,'theta':THETA,'total_budget_sec':B,'guided_online_budget_sec':gB,
            'source_offline_sec':float(s['offline_sec']),'prior_prepare_sec':prep,'amortized_charge_sec':charge,'accounted_total_sec':gB+charge,
            'prior_demo_constructed_cmax':lastc,'baseline_cmax':bd['cmax'],'baseline_rpd':bd['rpd'],'cmax':int(gr['cmax']),'rpd':100*(gr['cmax']-ub)/ub,
            'delta_rpd':100*(gr['cmax']-bd['cmax'])/ub,'episodes':int(gr['episodes']),'elapsed_sec':float(gr['elapsed_sec']),'qa':ok,
            'details':{k:v for k,v in gr.items() if k not in ('seq','cmax','elapsed_sec')}}
        fg.write_text(json.dumps(gd,indent=2)); print(folder,'GUID',rep,gd['cmax'],gd['rpd'],gd['delta_rpd'],gd['episodes'],gd['details']['guided_fraction'],flush=True)

def summarize(folder,outname):
    z=[json.loads(f.read_text()) for f in sorted((HERE/folder).glob(f'{PID}_r*_guided.json'))]
    assert len(z)==5,(folder,len(z)); ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['cmax']<x['baseline_cmax'] for x in z); t=sum(x['cmax']==x['baseline_cmax'] for x in z); l=5-w-t
    row={'problem':PID,'n_pairs':5,'D':D,'theta':THETA,'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,
         'mean_guided_rpd':float(np.mean([x['rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),
         'guided_best_cmax':min(x['cmax'] for x in z),'baseline_best_cmax':min(x['baseline_cmax'] for x in z),
         'mean_guided_episodes':float(np.mean([x['episodes'] for x in z])),'mean_guided_fraction':float(np.mean([x['details']['guided_fraction'] for x in z])),
         'source_offline_sec':float(z[0]['source_offline_sec']),'prior_prepare_sec':float(z[0]['prior_prepare_sec']),'amortized_charge_sec':float(z[0]['amortized_charge_sec'])}
    with open(HERE/outname,'w',newline='') as f:
        ww=csv.DictWriter(f,fieldnames=list(row)); ww.writeheader(); ww.writerow(row)
    return row

def finalize(val,strict):
    qa_all=True
    for ddir in ['equal_online','strict_h10']:
        for f in (HERE/ddir).glob('*.json') if (HERE/ddir).exists() else []:
            d=json.loads(f.read_text()); qa_all=qa_all and d.get('status')=='GREEN'
    rep=['# transfer experiment 16 Report — Combined Contrast-P prior + near-tie Q-NEH','',f'QA: {"GREEN" if qa_all else "RED"}','',
         'Frozen interface: D=3 Contrast-P order prior + theta=0.05 optimized near-tie Contrast-P selection. No parameter tuning was performed in this analysis_phase.','',
         f'Equal-online validation: mean ΔRPD={val["mean_delta_rpd"]:.6f}, median={val["median_delta_rpd"]:.6f}, W/T/L={val["wins"]}/{val["ties"]}/{val["losses"]}, mean RPD guided/base={val["mean_guided_rpd"]:.6f}/{val["mean_baseline_rpd"]:.6f}, best Cmax guided/base={val["guided_best_cmax"]}/{val["baseline_best_cmax"]}.']
    if strict is not None:
        rep += ['',f'Strict H=10 reusable-cost audit: mean ΔRPD={strict["mean_delta_rpd"]:.6f}, median={strict["median_delta_rpd"]:.6f}, W/T/L={strict["wins"]}/{strict["ties"]}/{strict["losses"]}, mean RPD guided/base={strict["mean_guided_rpd"]:.6f}/{strict["mean_baseline_rpd"]:.6f}, best Cmax guided/base={strict["guided_best_cmax"]}/{strict["baseline_best_cmax"]}.']
    else:
        rep += ['','Strict H=10 audit was not run because the pre-frozen promotion gate (equal-online mean ΔRPD < 0) was not met.']
    (HERE/'transfer16_REPORT.md').write_text('\n'.join(rep)+'\n')
    qa={'status':'GREEN' if qa_all else 'RED','problem':PID,'D':D,'theta':THETA,'equal_online_favorable':val['mean_delta_rpd']<0,'strict_h10_run':strict is not None,'all_permutation_cmax_qa':qa_all}
    (HERE/'transfer16_MASTER_QA.json').write_text(json.dumps(qa,indent=2))
    files=[p for p in HERE.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt' and not p.name.endswith('.zip')]
    with open(HERE/'SHA256SUMS.txt','w') as f:
        for p in sorted(files): f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(HERE))+'\n')
    zp=(Path(__file__).resolve().parent.parent/'PFSP_transfer16_QNEH_N100_CombinedPriorNearTie_GREEN.zip')
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.rglob('*')):
            if p.is_file(): z.write(p,arcname=str(Path(HERE.name)/p.relative_to(HERE)))
    with zipfile.ZipFile(zp) as z: bad=z.testzip()
    print('FINAL',qa,'zip',zp,'bad',bad,flush=True)

def main():
    r.warmup(); s,Q0,prep,lastc=source()
    # warm numba function before timing
    b12.p_action_score_fast(np.empty(0,dtype=np.int64),np.array([0,1],dtype=np.int64),s['P'])
    run_set(s,Q0,prep,lastc,VAL_REPS,'equal_online',False)
    val=summarize('equal_online','transfer16_equal_online_summary.csv')
    strict=None
    if val['mean_delta_rpd']<0:
        run_set(s,Q0,prep,lastc,STRICT_REPS,'strict_h10',True)
        strict=summarize('strict_h10','transfer16_strict_h10_summary.csv')
    finalize(val,strict)

if __name__=='__main__': main()
