# PFSP transfer experiment 04 — Reusable 10,000n Contrast-P Mining for QIG

Status: **FROZEN BEFORE EXECUTION**.
Nature: exploratory efficiency follow-up to analyses 9B.2–9B.3. It does not replace the confirmatory exploratory transfer analysis results.

## Objective
transfer experiment 02 showed that QIG + Contrast-P soft bias can improve QIG under equal online time, while transfer experiment 03 showed that simply shrinking the mining pool weakens the useful signal. transfer experiment 04 therefore keeps the high-information `S=10,000n` mining protocol unchanged, but pays that mining cost once and reuses the resulting Contrast-P rule set across multiple independent QIG restarts of the same PFSP instance.

## Fixed guided mechanism
No QIG parameter is retuned.
- Contrast-P only; no R information.
- Always-active soft destruction bias.
- lambda = 0.25.
- Original QIG state/action definition, destruction-size policy, reconstruction, local search, acceptance, reward, epsilon schedule, and all remaining search logic unchanged.

## Shared mining source
For each problem, exactly one fresh `S=10,000n` random pool is generated and mined once.
- Elite = best 5%.
- Poor = worst 10%.
- Contrast precedence rules = top `3n` directional pairwise relations by absolute contrast score.
- The resulting `P_C` matrix is reused unchanged in all evaluation replications for that problem.
- Mining seed is independent of all QIG evaluation seeds and is fixed as `930000000 + ProblemOrdinal`.
- No candidate mining seed is screened or selected by solution performance.

## Development audit
Problem: `VFR100_40_10`.
Evaluation replications: frozen external-comparator analysis replications **6–10 only** (R=5). These evaluation seeds were not used in the transfer experiment 02 tuning/holdout calculations.

For replication r:
1. unguided QIG is run for frozen online budget `G8_r`;
2. guided QIG with the shared Contrast-P matrix is run for the same `G8_r`;
3. an amortized strict baseline is run for `G8_r + T_off_shared/5`.

The five guided runs together therefore pay exactly one mining cost:
`T_off_shared + sum_r G8_r`.
The five amortized strict baselines receive the same total budget:
`sum_r (G8_r + T_off_shared/5)`.

Primary strict endpoint is paired Delta RPD = RPD_guided - RPD_amortized_baseline; negative favors reusable mining. Paired W/T/L and batch best-of-five Cmax are also reported. Equal-online-time guided-vs-baseline results are reported as a mechanism view only.

## Frozen promotion gate
Proceed to the independent holdout only if all conditions hold on VFR100_40_10:
1. mean strict Delta RPD < 0;
2. strict wins >= strict losses;
3. guided batch best-of-five Cmax <= amortized-baseline batch best-of-five Cmax.

## Independent holdout if gate passes
Problem: `VFR100_60_10` (the holdout already pre-specified in transfer experiment 03 but never executed because the transfer experiment 03 gate failed).
Evaluation replications: external-comparator analysis replications 1–5 (R=5).
A new single `S=10,000n` pool is mined once for this holdout using the same independent mining-seed rule and its Contrast-P matrix is reused across all five runs. The same online-matched and amortized strict accounting is used. No further tuning is permitted.

## Interpretation restrictions
- This experiment tests **within-instance reuse/amortization**, not cross-instance transfer of job-specific P rules.
- Results are exploratory and apply to repeated restarts/uses of the same static instance.
- exploratory transfer analysis confirmatory comparator conclusions remain primary.
- A positive result supports only the claim that high-quality mined knowledge can become cost-effective when its one-time cost is amortized over repeated QIG runs; it does not establish universal superiority of guided QIG.

## Pre-result execution amendment (2026-09-13)
The first attempt to generate the independent dedicated 10,000n pool in the single-thread fallback runner did not complete within the execution window and produced **no QIG performance result**. Before observing any transfer experiment 04 solution result, the shared-source implementation was therefore changed to reuse the already archived transfer experiment 02 `S=10,000n` Contrast-P matrix from replication 1 and its directly measured fresh-mining wall time. This source was chosen by the fixed rule “first archived 10,000n replication,” not by solution performance. Development evaluation remains restricted to replications 6–10, which were not used to construct or evaluate that archived rule set in transfer experiment 02. The scientific question (one 10,000n mining cost amortized over five independent QIG restarts) is unchanged.
