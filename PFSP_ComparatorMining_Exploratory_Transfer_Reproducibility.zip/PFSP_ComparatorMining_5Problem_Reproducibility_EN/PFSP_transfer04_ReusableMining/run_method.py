from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1');os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('MKL_NUM_THREADS','1');os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json
from pathlib import Path
import numpy as np
HERE=(Path(__file__).resolve().parent.parent/'PFSP_transfer04_ReusableMining');S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias');S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(S2));sys.path.insert(0,str(S1))
import transfer02_runner as s2;r=s2.r
from run_pfsp_single import pfsp_cmax
from external_comparator_comparators import validate_permutation
pid=sys.argv[1];rep=int(sys.argv[2]);mode=sys.argv[3];H=5
seed,ordn=r.seed_for(pid,rep);row=r.load_manifest_row(r.PFSP_ROOT,pid);p,_=r.load_instance(r.PFSP_ROOT,row);n=p.shape[0];ub=r.ub_for(pid);g8,_,_=r.external_comparator_max_guided(pid,rep)
if pid=='VFR100_40_10':
 z=np.load(S2/'cache'/'VFR100_40_10_r01_PC.npz');PC=z['PC'];off=float(z['offline_sec']);source_seed=r.seed_for(pid,1)[0]
else: raise RuntimeError('not configured')
share=off/H
r.warmup()
if mode=='online_base': rr=r.qig_deadline(p,seed,g8)
elif mode=='guided': rr=s2.qig_soft_p(p,seed,g8,PC,.25,'always')
elif mode=='amort_base': rr=r.qig_deadline(p,seed,g8+share)
else: raise ValueError(mode)
ok=bool(validate_permutation(rr['seq'],n) and int(pfsp_cmax(rr['seq'],p))==int(rr['cmax']))
d={'problem':pid,'rep':rep,'mode':mode,'seed':seed,'ub':ub,'g8_sec':g8,'offline_sec':off,'share_sec':share,'source_seed':source_seed,'cmax':int(rr['cmax']),'rpd':100*(int(rr['cmax'])-ub)/ub,'elapsed_sec':float(rr['elapsed_sec']),'qa':ok}
out=HERE/'partials'/f'{pid}_r{rep:02d}_{mode}.json';out.write_text(json.dumps(d,indent=2));print(json.dumps(d),flush=True)
