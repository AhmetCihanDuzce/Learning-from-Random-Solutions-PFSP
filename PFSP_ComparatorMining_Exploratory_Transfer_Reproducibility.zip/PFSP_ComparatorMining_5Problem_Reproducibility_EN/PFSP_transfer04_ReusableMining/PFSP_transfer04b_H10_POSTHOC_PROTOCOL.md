# PFSP exploratory transfer analysis.4b — Post-hoc Ten-Use Amortization Probe

Status: **FROZEN BEFORE EXECUTION OF H=10 BASELINES**.
Nature: explicitly post-hoc efficiency probe following the H=5 transfer experiment 04 development result. It is not confirmatory and does not replace exploratory transfer analysis.

## Rationale
The H=5 reusable-mining audit on VFR100_40_10 (evaluation replications 6–10) was nearly break-even under strict accounting: mean strict Delta RPD = +0.0176 percentage points, while the guided batch best was better than the amortized-baseline batch best. The original external-comparator analysis comparator design uses R=10 replications. Therefore exactly one additional reuse horizon is examined: **H=10**. No horizon grid is searched.

## Frozen mechanism and information source
- Same archived S=10,000n Contrast-P matrix used in transfer experiment 04: VFR100_40_10 transfer experiment 02 replication-1 P_C.
- Same measured one-time mining wall cost: 64.510529287 s.
- QIG + Contrast-P soft bias remains always active with lambda=0.25.
- Existing guided and equal-online baseline results for evaluation replications 6–10 are reused unchanged.
- Only the amortized unguided baselines are rerun at `G8_r + T_off/10`.

## Evaluation
Problem: VFR100_40_10.
Replications: external-comparator analysis replications 6–10, unchanged.
Per-use mining allocation: 6.451052929 s.
Primary descriptive quantities: mean/median strict Delta RPD, W/T/L, and batch-best Cmax.

## Interpretation
H=10 is a prospective-use accounting scenario, not an observed ten-run batch in this five-replication probe. A favorable result supports only the statement that the observed one-time mining cost would become competitive if the same high-quality mined rules were reused over approximately ten QIG uses. It does not establish a universal break-even count, and no further reuse horizons will be searched in this analysis phase.
