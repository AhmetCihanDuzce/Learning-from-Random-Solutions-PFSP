from __future__ import annotations
import sys,json,time
from pathlib import Path
import numpy as np
HERE=(Path(__file__).resolve().parent.parent/'PFSP_transfer04_ReusableMining')
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias'); S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(S2));sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from run_pfsp_single import pfsp_cmax
from external_comparator_comparators import validate_permutation
pid='VFR100_40_10'; rep=int(sys.argv[1]); H=5
z=np.load(S2/'cache'/'VFR100_40_10_r01_PC.npz'); PC=z['PC']; off=float(z['offline_sec']); share=off/H
seed,ordn=r.seed_for(pid,rep); row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid); g8,_,_=r.external_comparator_max_guided(pid,rep)
def qa(x):return bool(validate_permutation(x['seq'],n) and int(pfsp_cmax(x['seq'],p))==int(x['cmax']))
r.warmup(); print('rep',rep,'seed',seed,'g8',g8,'offshare',share,flush=True)
b0=r.qig_deadline(p,seed,g8); print('base',b0['cmax'],b0['elapsed_sec'],flush=True)
gr=s2.qig_soft_p(p,seed,g8,PC,.25,'always'); print('guided',gr['cmax'],gr['elapsed_sec'],flush=True)
B=g8+share; ba=r.qig_deadline(p,seed,B); print('amortbase',ba['cmax'],ba['elapsed_sec'],flush=True)
d={'status':'GREEN' if qa(b0) and qa(gr) and qa(ba) else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,
   'shared_source_replication':1,'shared_mining_seed':r.seed_for(pid,1)[0],'shared_offline_sec':off,'amortization_horizon':H,'amortized_offline_share_sec':share,
   'g8_sec':g8,'amortized_equal_budget_sec':B,'lambda':.25,'trigger':'always',
   'online_baseline_cmax':int(b0['cmax']),'online_baseline_rpd':100*(int(b0['cmax'])-ub)/ub,'online_baseline_elapsed_sec':float(b0['elapsed_sec']),
   'guided_cmax':int(gr['cmax']),'guided_rpd':100*(int(gr['cmax'])-ub)/ub,'guided_elapsed_sec':float(gr['elapsed_sec']),'online_delta_rpd':100*(int(gr['cmax'])-int(b0['cmax']))/ub,
   'amortized_baseline_cmax':int(ba['cmax']),'amortized_baseline_rpd':100*(int(ba['cmax'])-ub)/ub,'amortized_baseline_elapsed_sec':float(ba['elapsed_sec']),'strict_delta_rpd':100*(int(gr['cmax'])-int(ba['cmax']))/ub,
   'qa_online_base':qa(b0),'qa_guided':qa(gr),'qa_amortized_base':qa(ba),'guided_details':{k:v for k,v in gr.items() if k not in ('seq','cmax','elapsed_sec')}}
out=HERE/'raw'/f'{pid}_r{rep:02d}.json';out.write_text(json.dumps(d,indent=2));print('saved',out,d['status'],'online_delta',d['online_delta_rpd'],'strict_delta',d['strict_delta_rpd'],flush=True)
