import subprocess,time,os,sys
from pathlib import Path
HERE=(Path(__file__).resolve().parent.parent/'PFSP_transfer04_ReusableMining')
for rep in [6,7,8,9,10]:
    for mode in ['online_base','guided','amort_base']:
        f=HERE/'partials'/f'VFR100_40_10_r{rep:02d}_{mode}.json'
        if f.exists():
            print('SKIP',rep,mode,flush=True); continue
        print('START',rep,mode,flush=True)
        p=subprocess.Popen([sys.executable,str(HERE/'run_method.py'),'VFR100_40_10',str(rep),mode],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        while p.poll() is None:
            print('  heartbeat',rep,mode,'t',round(time.time()%100000,1),flush=True)
            time.sleep(5)
        out=p.stdout.read() if p.stdout else ''
        if out: print(out,end='',flush=True)
        if p.returncode!=0: raise SystemExit(p.returncode)
print('ALL_DONE',flush=True)
