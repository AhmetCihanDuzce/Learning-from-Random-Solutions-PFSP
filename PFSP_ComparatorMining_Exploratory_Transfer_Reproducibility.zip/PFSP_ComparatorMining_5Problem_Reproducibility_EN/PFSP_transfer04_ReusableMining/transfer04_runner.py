from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys, json, csv, time, hashlib
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias')
S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(S2)); sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from run_pfsp_single import generate_pool_to_memmap, cmax_memmap, selection_indices, mine_pr_rules, pfsp_cmax
from external_comparator_comparators import validate_permutation

DEV='VFR100_40_10'; DEV_REPS=range(6,11)
HOLD='VFR100_60_10'; HOLD_REPS=range(1,6)
LAM=0.25; TRIGGER='always'; H=5
TMP=HERE/'tmp'; RAW=HERE/'raw'; CACHE=HERE/'cache'
TMP.mkdir(exist_ok=True); RAW.mkdir(exist_ok=True); CACHE.mkdir(exist_ok=True)

def qa(res,p,n):
    return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))

def mine_seed(pid):
    _,ordn=r.seed_for(pid,1)
    return 930000000 + int(ordn)

def mine_shared(pid,p):
    # Pre-result feasibility amendment: fixed first archived 10,000n rule set.
    # Development uses transfer experiment 02 rep1 cache; no performance-based source selection.
    if pid==DEV:
        f=S2/'cache'/f'{pid}_r01_PC.npz'
        z=np.load(f,allow_pickle=False)
        PC=z['PC']; off=float(z['offline_sec']); stats=json.loads(str(z['stats_json']))
        seed,_=r.seed_for(pid,1)
        stats=dict(stats); stats['source']='transfer02 archived 10,000n rep1'; stats['source_replication']=1
        return PC,off,seed,stats
    # Holdout: use first archived structural-stability analysis 10,000n structure only if explicitly materialized later.
    raise RuntimeError('Holdout shared source not configured yet; stop after development gate.')

def support_jaccard(A,B):
    a=np.asarray(A)!=0; b=np.asarray(B)!=0
    u=np.logical_or(a,b).sum(); inter=np.logical_and(a,b).sum()
    return 1.0 if u==0 else float(inter/u)

def old_rule_jaccards(pid,PC,reps):
    out=[]
    for rep in reps:
        f=S2/'cache'/f'{pid}_r{rep:02d}_PC.npz'
        if f.exists(): out.append(support_jaccard(PC,np.load(f)['PC']))
    return out

def run_problem(pid,reps):
    row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; ub=r.ub_for(pid)
    PC,off,mseed,mstats=mine_shared(pid,p)
    share=off/float(H)
    print('SHARED MINING',pid,'seed',mseed,'off',off,'share',share,flush=True)
    rec=[]
    for rep in reps:
        seed,ordn=r.seed_for(pid,rep); g8,_,_=r.external_comparator_max_guided(pid,rep)
        fn=RAW/f'{pid}_r{rep:02d}.json'
        if fn.exists():
            d=json.loads(fn.read_text()); rec.append(d); print('SKIP',pid,rep,flush=True); continue
        print('START ONLINE BASE',pid,rep,'G8',g8,flush=True)
        b0=r.qig_deadline(p,seed,g8); ok0=qa(b0,p,n)
        print('DONE ONLINE BASE',b0['cmax'],flush=True)
        print('START GUIDED',pid,rep,'G8',g8,flush=True)
        gr=s2.qig_soft_p(p,seed,g8,PC,LAM,TRIGGER); okg=qa(gr,p,n)
        print('DONE GUIDED',gr['cmax'],flush=True)
        B=g8+share
        print('START AMORTIZED BASE',pid,rep,'B',B,flush=True)
        ba=r.qig_deadline(p,seed,B); oka=qa(ba,p,n)
        print('DONE AMORTIZED BASE',ba['cmax'],flush=True)
        d={'status':'GREEN' if (ok0 and okg and oka) else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,
           'shared_mining_seed':mseed,'shared_offline_sec':off,'amortization_horizon':H,'amortized_offline_share_sec':share,
           'g8_sec':g8,'amortized_equal_budget_sec':B,'lambda':LAM,'trigger':TRIGGER,'mining_stats':mstats,
           'online_baseline_cmax':int(b0['cmax']),'online_baseline_rpd':100*(int(b0['cmax'])-ub)/ub,'online_baseline_elapsed_sec':float(b0['elapsed_sec']),
           'guided_cmax':int(gr['cmax']),'guided_rpd':100*(int(gr['cmax'])-ub)/ub,'guided_elapsed_sec':float(gr['elapsed_sec']),
           'online_delta_rpd':100*(int(gr['cmax'])-int(b0['cmax']))/ub,
           'amortized_baseline_cmax':int(ba['cmax']),'amortized_baseline_rpd':100*(int(ba['cmax'])-ub)/ub,'amortized_baseline_elapsed_sec':float(ba['elapsed_sec']),
           'strict_delta_rpd':100*(int(gr['cmax'])-int(ba['cmax']))/ub,
           'qa_online_base':bool(ok0),'qa_guided':bool(okg),'qa_amortized_base':bool(oka),
           'guided_details':{k:v for k,v in gr.items() if k not in ('seq','cmax','elapsed_sec')}}
        fn.write_text(json.dumps(d,indent=2)); rec.append(d)
    return rec,PC,off

def summarize(pid,records,PC,off,outname,reps):
    assert len(records)==5,len(records)
    od=np.array([x['online_delta_rpd'] for x in records],float); sd=np.array([x['strict_delta_rpd'] for x in records],float)
    ow=sum(x['guided_cmax']<x['online_baseline_cmax'] for x in records); ot=sum(x['guided_cmax']==x['online_baseline_cmax'] for x in records); ol=5-ow-ot
    sw=sum(x['guided_cmax']<x['amortized_baseline_cmax'] for x in records); st=sum(x['guided_cmax']==x['amortized_baseline_cmax'] for x in records); sl=5-sw-st
    jacs=old_rule_jaccards(pid,PC,reps)
    row={'problem':pid,'n_pairs':5,'shared_mining_seed':mine_seed(pid),'shared_offline_sec':off,'amortization_horizon':H,'amortized_offline_share_sec':off/H,
         'mean_jaccard_shared_vs_prior_10k_rules':float(np.mean(jacs)) if jacs else float('nan'),'n_prior_rule_sets_compared':len(jacs),
         'mean_online_delta_rpd':float(od.mean()),'median_online_delta_rpd':float(np.median(od)),'online_wins':ow,'online_ties':ot,'online_losses':ol,
         'mean_strict_delta_rpd':float(sd.mean()),'median_strict_delta_rpd':float(np.median(sd)),'strict_wins':sw,'strict_ties':st,'strict_losses':sl,
         'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in records])),'mean_online_baseline_rpd':float(np.mean([x['online_baseline_rpd'] for x in records])),
         'mean_amortized_baseline_rpd':float(np.mean([x['amortized_baseline_rpd'] for x in records])),
         'guided_batch_best_cmax':int(min(x['guided_cmax'] for x in records)),'online_baseline_batch_best_cmax':int(min(x['online_baseline_cmax'] for x in records)),
         'amortized_baseline_batch_best_cmax':int(min(x['amortized_baseline_cmax'] for x in records)),
         'guided_accounted_batch_budget_sec':float(off+sum(x['g8_sec'] for x in records)),
         'amortized_baseline_batch_budget_sec':float(sum(x['amortized_equal_budget_sec'] for x in records)),
         'all_qa_green':all(x['status']=='GREEN' for x in records)}
    with open(HERE/outname,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(row.keys())); w.writeheader(); w.writerow(row)
    return row

def main():
    r.warmup()
    dev,PC,off=run_problem(DEV,DEV_REPS)
    s=summarize(DEV,dev,PC,off,'transfer04_development_summary.csv',DEV_REPS)
    gate=(s['mean_strict_delta_rpd']<0 and s['strict_wins']>=s['strict_losses'] and s['guided_batch_best_cmax']<=s['amortized_baseline_batch_best_cmax'])
    sel={'gate_passed':bool(gate),'development_summary':s,'gate':'mean strict delta<0 AND wins>=losses AND guided batch-best<=amortized baseline batch-best'}
    (HERE/'transfer04_selection.json').write_text(json.dumps(sel,indent=2))
    print('SELECTION',json.dumps(sel,indent=2),flush=True)
    if gate:
        print('GATE PASSED; HOLDOUT AUTHORIZED BUT NOT AUTO-RUN UNTIL SOURCE/TIMING IS FROZEN',flush=True)
    else:
        print('GATE FAILED; HOLDOUT NOT RUN',flush=True)

if __name__=='__main__': main()
