# transfer experiment 04 Report — Reusable 10,000n Contrast-P Mining for QIG

## Status
**QA: GREEN.** Exploratory efficiency follow-up; exploratory transfer analysis confirmatory conclusions remain unchanged.

## Design
The transfer experiment 02 QIG mechanism was kept fixed: Contrast-P only, always-active soft destruction bias, lambda=0.25. Instead of reducing the pool size, one high-quality S=10,000n Contrast-P rule set was reused across independent QIG restarts of the same instance. The shared source was fixed to the first archived transfer experiment 02 10,000n rule set before any transfer experiment 04 solution result was observed. Evaluation used VFR100_40_10 external-comparator analysis seeds 6–10, which were not used in the transfer experiment 02 development/holdout calculations.

The one-time measured mining cost was **64.511 s**. The shared P support contains 300 pair rules (600 symmetric matrix entries). Its mean support Jaccard against the other four archived 10,000n rule sets is **0.863**.

## H=5 observed equal-total-budget batch
Mining was paid once and divided over five QIG uses: **12.902 s per use**. The guided batch and the amortized unguided batch had exactly the same accounted total budget (194.717 s).

- Mean equal-online Delta RPD: **-0.1836** percentage points; W/T/L = 3/0/2.
- Mean strict amortized Delta RPD: **+0.0176** percentage points; W/T/L = 2/0/3.
- Guided batch-best Cmax: **7964** versus amortized-baseline batch-best **7970**.

Thus five-use amortization was nearly break-even but did **not** pass the frozen promotion gate: the mean strict difference remained slightly baseline-favoring (+0.0176 RPD points) and strict W/T/L was 2/0/3, despite the better guided batch-best.

## H=10 post-hoc reuse probe
Because the main external-comparator analysis design itself uses R=10, one additional reuse horizon was frozen after H=5: **H=10 only**; no horizon grid was searched. Existing guided results were retained and the unguided comparator was rerun with `G8 + T_off/10`, corresponding to **6.451 s** of mining cost per intended use.

- Mean strict Delta RPD: **-0.0679** percentage points.
- Median strict Delta RPD: **-0.1258** percentage points.
- W/T/L: **3/0/2**.
- Mean guided RPD: **0.5332%** versus H=10 baseline **0.6011%**.
- Guided batch-best Cmax: **7964** versus H=10 baseline batch-best **7982**.

The sign therefore changes at the ten-use accounting horizon in this exploratory probe: reusable Contrast-P guided QIG is better on average by about **0.068 RPD percentage points**, with 3/0/2 W/T/L and a better batch-best solution.

## Interpretation
The earlier experiments showed that (i) high-quality Contrast-P information can improve QIG search, (ii) fresh 10,000n mining largely consumes the gain, and (iii) reducing the pool weakens the signal. transfer experiment 04 adds that **reusing the same high-quality mined information can recover cost-effectiveness**. Five uses are approximately break-even; a ten-use allocation is directionally favorable on the held VFR100_40_10 seeds.

However, H=10 is explicitly post-hoc and was evaluated on five held seeds as a ten-use cost-allocation scenario, not as a complete ten-run batch. It should therefore be reported as a mechanism/efficiency finding, not as a confirmatory superiority claim. Independent validation on another problem would be required before making a broader amortization claim.
