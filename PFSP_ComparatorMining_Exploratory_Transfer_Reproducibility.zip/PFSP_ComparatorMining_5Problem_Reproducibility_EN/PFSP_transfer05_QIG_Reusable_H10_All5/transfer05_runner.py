from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys, json, csv, time, shutil
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias')
S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
S4=(Path(__file__).resolve().parent.parent/'PFSP_transfer04_ReusableMining')
sys.path.insert(0,str(S2)); sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from run_pfsp_single import pfsp_cmax
from external_comparator_comparators import validate_permutation

PROBLEMS=['Ta50_10_1','Ta50_20_1','Ta100_20_1','Ta100_20_10','VFR100_40_10']
REPS=range(6,11)
LAM=0.25; TRIGGER='always'; H=10
RAW=HERE/'raw'; RAW.mkdir(exist_ok=True)

def qa(res,p,n):
    return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))

def source(pid):
    f=S2/'cache'/f'{pid}_r01_PC.npz'
    if not f.exists(): raise FileNotFoundError(f)
    z=np.load(f,allow_pickle=False)
    PC=z['PC']; off=float(z['offline_sec']); stats=json.loads(str(z['stats_json']))
    seed,_=r.seed_for(pid,1)
    return PC,off,seed,stats

def maybe_reuse_vfr(pid,rep,off):
    if pid!='VFR100_40_10': return None
    gf=S4/'partials'/f'{pid}_r{rep:02d}_guided.json'
    bf=S4/'partials'/f'h10_amort_{rep}.json'
    if not (gf.exists() and bf.exists()): return None
    g=json.loads(gf.read_text()); b=json.loads(bf.read_text())
    if abs(float(g['offline_sec'])-off)>1e-6 or abs(float(b['offline_sec'])-off)>1e-6: return None
    return g,b

def run_pair(pid,rep):
    fn=RAW/f'{pid}_r{rep:02d}.json'
    if fn.exists():
        d=json.loads(fn.read_text()); print('SKIP',pid,rep,flush=True); return d
    row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]
    seed,ordn=r.seed_for(pid,rep); ub=r.ub_for(pid); g8,_,_=r.external_comparator_max_guided(pid,rep)
    PC,off,source_seed,stats=source(pid); share=off/H; B=g8+share
    reused=maybe_reuse_vfr(pid,rep,off)
    if reused is not None:
        g,b=reused
        guided={'cmax':int(g['cmax']),'elapsed_sec':float(g['elapsed_sec']),'qa':bool(g['qa'])}
        base={'cmax':int(b['cmax']),'elapsed_sec':float(b['elapsed_sec']),'qa':bool(b['qa'])}
        reuse_flag=True
        print('REUSE',pid,rep,'guided',guided['cmax'],'base',base['cmax'],flush=True)
    else:
        print('START GUIDED',pid,rep,'G8',g8,flush=True)
        gr=s2.qig_soft_p(p,seed,g8,PC,LAM,TRIGGER); okg=qa(gr,p,n)
        guided={'cmax':int(gr['cmax']),'elapsed_sec':float(gr['elapsed_sec']),'qa':bool(okg),
                'details':{k:v for k,v in gr.items() if k not in ('seq','cmax','elapsed_sec')}}
        print('DONE GUIDED',pid,rep,guided['cmax'],flush=True)
        print('START BASE',pid,rep,'B',B,flush=True)
        br=r.qig_deadline(p,seed,B); okb=qa(br,p,n)
        base={'cmax':int(br['cmax']),'elapsed_sec':float(br['elapsed_sec']),'qa':bool(okb),
              'details':{k:v for k,v in br.items() if k not in ('seq','cmax','elapsed_sec')}}
        print('DONE BASE',pid,rep,base['cmax'],flush=True)
        reuse_flag=False
    d={'status':'GREEN' if (guided['qa'] and base['qa']) else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,
       'source_replication':1,'source_seed':source_seed,'source_offline_sec':off,'reuse_horizon':H,'allocated_mining_sec':share,
       'g8_sec':g8,'equal_budget_baseline_sec':B,'lambda':LAM,'trigger':TRIGGER,'reused_archived_vfr_output':reuse_flag,
       'guided_cmax':guided['cmax'],'guided_rpd':100*(guided['cmax']-ub)/ub,'guided_elapsed_sec':guided['elapsed_sec'],
       'baseline_cmax':base['cmax'],'baseline_rpd':100*(base['cmax']-ub)/ub,'baseline_elapsed_sec':base['elapsed_sec'],
       'delta_rpd':100*(guided['cmax']-base['cmax'])/ub,'qa_guided':guided['qa'],'qa_baseline':base['qa'],
       'source_stats':stats}
    fn.write_text(json.dumps(d,indent=2),encoding='utf-8')
    return d

def summarize(allrows):
    out=[]
    for pid in PROBLEMS:
        z=[x for x in allrows if x['problem']==pid]
        assert len(z)==5,(pid,len(z))
        ds=np.array([x['delta_rpd'] for x in z],float)
        w=sum(x['guided_cmax']<x['baseline_cmax'] for x in z); t=sum(x['guided_cmax']==x['baseline_cmax'] for x in z); l=5-w-t
        out.append({'problem':pid,'n_pairs':5,'source_offline_sec':z[0]['source_offline_sec'],'reuse_horizon':H,'allocated_mining_sec':z[0]['allocated_mining_sec'],
                    'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,
                    'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),
                    'guided_batch_best_cmax':int(min(x['guided_cmax'] for x in z)),'baseline_batch_best_cmax':int(min(x['baseline_cmax'] for x in z)),
                    'all_qa_green':all(x['status']=='GREEN' for x in z)})
    z=allrows; ds=np.array([x['delta_rpd'] for x in z],float); w=sum(x['guided_cmax']<x['baseline_cmax'] for x in z); t=sum(x['guided_cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
    out.append({'problem':'ALL_5_DESCRIPTIVE','n_pairs':len(z),'source_offline_sec':'','reuse_horizon':H,'allocated_mining_sec':'',
                'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,
                'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),
                'guided_batch_best_cmax':'','baseline_batch_best_cmax':'','all_qa_green':all(x['status']=='GREEN' for x in z)})
    with open(HERE/'transfer05_summary.csv','w',newline='',encoding='utf-8') as f:
        wri=csv.DictWriter(f,fieldnames=list(out[0].keys())); wri.writeheader(); wri.writerows(out)
    return out

def main():
    r.warmup(); allrows=[]
    for pid in PROBLEMS:
        for rep in REPS:
            allrows.append(run_pair(pid,rep))
    s=summarize(allrows)
    qa={'status':'GREEN' if all(x['status']=='GREEN' for x in allrows) else 'RED','n_problems':5,'n_pairs':25,'n_green':sum(x['status']=='GREEN' for x in allrows),
        'protocol_frozen_before_execution':True,'mechanism':'QIG+Contrast-P soft bias, always, lambda=0.25, H=10 reusable mining','evaluation_reps':'6-10'}
    (HERE/'transfer05_MASTER_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
    print('SUMMARY',json.dumps(s,indent=2),flush=True); print('QA',json.dumps(qa,indent=2),flush=True)
if __name__=='__main__': main()
