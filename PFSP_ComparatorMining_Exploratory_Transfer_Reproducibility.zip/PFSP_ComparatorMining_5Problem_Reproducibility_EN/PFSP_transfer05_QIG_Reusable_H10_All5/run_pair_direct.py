from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json
from pathlib import Path
import numpy as np
HERE=(Path(__file__).resolve().parent.parent/'PFSP_transfer05_QIG_Reusable_H10_All5')
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias'); S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot'); S4=(Path(__file__).resolve().parent.parent/'PFSP_transfer04_ReusableMining')
sys.path.insert(0,str(S2)); sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from run_pfsp_single import pfsp_cmax
from external_comparator_comparators import validate_permutation
pid=sys.argv[1]; rep=int(sys.argv[2]); H=10; lam=.25; trigger='always'
fn=HERE/'raw'/f'{pid}_r{rep:02d}.json'
if fn.exists(): print('SKIP',fn); raise SystemExit
row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]
seed,ordn=r.seed_for(pid,rep); ub=r.ub_for(pid); g8,_,_=r.external_comparator_max_guided(pid,rep)
z=np.load(S2/'cache'/f'{pid}_r01_PC.npz',allow_pickle=False); PC=z['PC']; off=float(z['offline_sec']); stats=json.loads(str(z['stats_json'])); source_seed,_=r.seed_for(pid,1); share=off/H; B=g8+share
if pid=='VFR100_40_10':
    gf=S4/'partials'/f'{pid}_r{rep:02d}_guided.json'; bf=S4/'partials'/f'h10_amort_{rep}.json'
    g=json.loads(gf.read_text()); b=json.loads(bf.read_text())
    gc,ge,gq=int(g['cmax']),float(g['elapsed_sec']),bool(g['qa']); bc,be,bq=int(b['cmax']),float(b['elapsed_sec']),bool(b['qa'])
    reused=True
else:
    print('GUIDED START',pid,rep,flush=True); gr=s2.qig_soft_p(p,seed,g8,PC,lam,trigger); print('GUIDED DONE',gr['cmax'],gr['elapsed_sec'],flush=True)
    gc,ge,gq=int(gr['cmax']),float(gr['elapsed_sec']),bool(validate_permutation(gr['seq'],n) and int(pfsp_cmax(gr['seq'],p))==int(gr['cmax']))
    print('BASE START',pid,rep,flush=True); br=r.qig_deadline(p,seed,B); print('BASE DONE',br['cmax'],br['elapsed_sec'],flush=True)
    bc,be,bq=int(br['cmax']),float(br['elapsed_sec']),bool(validate_permutation(br['seq'],n) and int(pfsp_cmax(br['seq'],p))==int(br['cmax']))
    reused=False
d={'status':'GREEN' if (gq and bq) else 'RED','problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,'source_replication':1,'source_seed':source_seed,'source_offline_sec':off,'reuse_horizon':H,'allocated_mining_sec':share,'g8_sec':g8,'equal_budget_baseline_sec':B,'lambda':lam,'trigger':trigger,'reused_archived_vfr_output':reused,'guided_cmax':gc,'guided_rpd':100*(gc-ub)/ub,'guided_elapsed_sec':ge,'baseline_cmax':bc,'baseline_rpd':100*(bc-ub)/ub,'baseline_elapsed_sec':be,'delta_rpd':100*(gc-bc)/ub,'qa_guided':gq,'qa_baseline':bq,'source_stats':stats}
fn.write_text(json.dumps(d,indent=2),encoding='utf-8'); print('WROTE',fn,'delta',d['delta_rpd'],flush=True)
