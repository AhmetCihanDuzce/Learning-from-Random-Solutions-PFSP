# transfer experiment 05 Report — Five-Problem Replication of Reusable Contrast-P QIG (H=10)

## Design
The exact exploratory transfer analysis.4b configuration was applied without retuning to all five previously studied difficult problems: QIG + Contrast-P only, always-active soft destruction bias, lambda=0.25, reuse horizon H=10, and external-comparator analysis replications 6–10. Each problem used the first archived transfer experiment 02 S=10,000n Contrast-P matrix (replication 1) as a fixed reusable mining source. The strict comparator received G8 + T_off/10 while guided QIG received G8.

## Results
Negative Delta RPD favors reusable mining.

| Problem | Mean Delta RPD (pp) | W/T/L | Guided mean RPD | Baseline mean RPD | Guided best | Baseline best |
|---|---:|---:|---:|---:|---:|---:|
| Ta50_10_1 | +0.0669 | 1/2/2 | 1.3240 | 1.2571 | 3025 | 3025 |
| Ta50_20_1 | +0.2701 | 0/1/4 | 1.3403 | 1.0701 | 3893 | 3880 |
| Ta100_20_1 | -0.0677 | 3/0/2 | 0.8868 | 0.9545 | 6244 | 6254 |
| Ta100_20_10 | -0.1119 | 3/0/2 | 0.6062 | 0.7181 | 6449 | 6477 |
| VFR100_40_10 | -0.0679 | 3/0/2 | 0.5332 | 0.6011 | 7964 | 7982 |

Across the five problems, three show a favorable mean strict equal-budget result and two do not. The aggregate 25-run descriptive mean Delta RPD is +0.0179 percentage points with W/T/L = 10/3/12; this aggregate is descriptive only because replications nested within a problem are not independent problem instances.

## Interpretation
The exact reusable H=10 QIG configuration therefore does **not** support a 5/5 improvement claim. It transfers successfully to the three 100-job/VFR cases but not to the two 50-job Taillard cases, with Ta50_20_1 showing a clear unfavorable result. This suggests a size- or search-dynamics interaction rather than a universally beneficial fixed guidance strength. No parameter was changed after observing these outcomes.

## QA
25/25 paired evaluations are GREEN. All stored permutations/Cmax values passed validation. The protocol was frozen before execution.
