# PFSP transfer experiment 05 — Five-Problem Replication of Reusable Contrast-P QIG (H=10)

Status: **FROZEN BEFORE EXECUTION**.
Nature: targeted exploratory replication of the exploratory transfer analysis.4b efficiency mechanism across the five previously studied difficult problems. It does not replace the confirmatory exploratory transfer analysis comparator panel.

## Objective
Test whether the exact last successful equal-budget reusable-mining configuration from exploratory transfer analysis.4b generalizes across all five previously used problems, without any additional tuning.

## Fixed QIG mechanism
- Comparator: QIG.
- Contrast-P only; no R information.
- Always-active soft destruction bias.
- lambda = 0.25.
- Original QIG state/action definition, destruction-size policy, reconstruction, local search, acceptance, reward, epsilon schedule, and all remaining search logic unchanged.

## Problems
1. Ta50_10_1
2. Ta50_20_1
3. Ta100_20_1
4. Ta100_20_10
5. VFR100_40_10

## Reusable mining source
For each problem, use the **first archived transfer experiment 02 S=10,000n Contrast-P matrix (replication 1)** and its directly measured fresh-mining wall time. The source is fixed by replication index, never screened by solution quality. Evaluation uses external-comparator analysis replications 6–10, so the source replication is disjoint from evaluation replications.

## Equal-budget accounting
Reuse horizon H=10 exactly as in exploratory transfer analysis.4b. For each evaluation replication r:
- guided QIG receives online budget G8_r;
- unguided QIG receives G8_r + T_off/10.

Thus the reusable guided scheme is charged one tenth of its one-time mining cost per prospective use. H=10 is not re-tuned per problem.

## Evaluation
- external-comparator analysis evaluation replications: 6–10 (R=5) for every problem.
- Primary endpoint per problem: mean paired Delta RPD = RPD_guided - RPD_equal-budget-baseline; negative favors mining.
- Also report median Delta RPD, W/T/L, mean RPDs, and batch-best Cmax.
- Aggregate across all 25 paired runs is descriptive only because runs within a problem are not treated as independent problem instances.

## Interpretation restrictions
- No positive result is guaranteed or required by the protocol.
- This is a targeted exploratory stress test on five previously studied difficult problems, not a new confirmatory benchmark panel.
- A favorable result supports the claim that reusable mined P-information can improve QIG under amortized equal-budget accounting on selected hard instances.
- It does not establish universal superiority over QIG or across PFSP instances.
- No parameter, reuse horizon, mining source, or problem is changed after results are observed.
