# PFSP transfer experiment 07 — n=50 Implementation-Efficiency Check

Status: **FROZEN BEFORE EXECUTION**.
Nature: targeted implementation-efficiency check after transfer experiment 06 early-guidance failed independent validation.

## Motivation
The n=50 online budgets are very short (~1–2 s). The transfer experiment 05 soft Contrast-P implementation recomputes positive P edges with `np.where` and accumulates violation scores in a Python loop at every destruction. This is algorithmically unnecessary overhead and can consume a nontrivial share of short online budgets.

## Fixed scientific mechanism
No scientific parameter is changed from transfer experiment 05:
- QIG comparator
- Contrast-P only
- always-active soft destruction bias
- lambda=0.25
- S=10,000n archived P source, replication 1
- reuse horizon H=10
- guided online budget G8_r
- equal-budget QIG baseline budget G8_r + T_off/10

Only implementation changes:
- positive P-edge indices and weights are precomputed once;
- the exact same per-job violation accumulation is executed by a compiled loop.

## Semantic regression gate
Before timed experiments, fast and reference P-violation vectors must match to numerical precision on 100 random permutations for both n=50 problems. If not, experiment stops.

## Evaluation
Problems: Ta50_10_1 and Ta50_20_1.
Replications: external-comparator analysis reps 6–10.
No tuning grid and no post-result parameter change.
Primary endpoint per problem: mean paired Delta RPD = guided - equal-budget QIG.
Also report W/T/L, median Delta RPD, mean RPD, batch-best Cmax, and algorithmic iteration counts.

## Interpretation
This checks whether the n=50 failure was partly caused by avoidable implementation overhead, not whether a new guidance mechanism can be tuned to these instances.
