from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,csv,time,math
from pathlib import Path
import numpy as np
from numba import njit
HERE=Path(__file__).resolve().parent
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias'); S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(S2)); sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from external_comparator_comparators import cmax_numba,best_insert_ff,insert_at,neh_ff,validate_permutation
from run_pfsp_single import pfsp_cmax
PROBLEMS=['Ta50_10_1','Ta50_20_1']; REPS=range(6,11); LAM=.25; H=10
@njit(cache=True)
def pvio_fast(seq,ii,jj,ww,n):
    pos=np.empty(n,np.int64)
    for k in range(seq.size): pos[seq[k]]=k
    v=np.zeros(n,np.float64)
    for k in range(ii.size):
        i=ii[k]; j=jj[k]
        if pos[i]>pos[j]:
            w=ww[k]; v[i]+=w; v[j]+=w
    return v

def source(pid):
    z=np.load(S2/'cache'/f'{pid}_r01_PC.npz',allow_pickle=False); P=z['PC']; off=float(z['offline_sec']); ii,jj=np.where(P>0); ww=P[ii,jj].astype(float)
    return P,off,ii.astype(np.int64),jj.astype(np.int64),ww

def ref_v(seq,P):
    return s2.p_violation(seq,P)

def semantic_gate():
    rng=np.random.default_rng(20260913); detail={}
    for pid in PROBLEMS:
        row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; P,off,ii,jj,ww=source(pid)
        pvio_fast(np.arange(n,dtype=np.int64),ii,jj,ww,n)
        maxerr=0.0
        for _ in range(100):
            seq=rng.permutation(n).astype(np.int64); a=ref_v(seq,P); b=pvio_fast(seq,ii,jj,ww,n); maxerr=max(maxerr,float(np.max(np.abs(a-b))))
        detail[pid]={'max_abs_error':maxerr,'pass':maxerr<=1e-12,'n_cases':100}
    ok=all(x['pass'] for x in detail.values()); (HERE/'semantic_regression.json').write_text(json.dumps({'status':'GREEN' if ok else 'RED','detail':detail},indent=2));
    if not ok: raise RuntimeError('semantic regression failed')

def qig_fast(p,seed,time_limit_sec,ii,jj,ww,lam=.25,tau=.7,epsilon=.8,beta=.996,alpha=.6,gamma=.8,E=6,eta=.3,max_ls_passes=100):
    n,m=p.shape; rng=np.random.default_rng(seed); start=time.perf_counter(); deadline=start+float(time_limit_sec)
    seq,_=neh_ff(p); best_seq=seq.copy(); best_c=int(cmax_numba(seq,p)); seq,curr_c,init_passes,_=r.insertion_local_search_deadline(seq,p,rng,deadline,max_ls_passes)
    if curr_c<best_c: best_c=int(curr_c); best_seq=seq.copy()
    Q=np.zeros((2,3),float); state=0; d=int(rng.integers(1,4)); temp=float(tau)*float(p.sum())/float(n*m*10.0); episodes=iterations=accepts=guided=0; eps=float(epsilon)
    while time.perf_counter()<deadline:
        Cprev=int(curr_c); Cbest_prev=int(best_c); C_ep=int(curr_c); used_d=d
        for _ in range(E):
            if time.perf_counter()>=deadline: break
            iterations+=1; v=pvio_fast(seq,ii,jj,ww,n); sv=float(v.sum())
            if sv>0:
                probs=(1.0-float(lam))/float(n)+float(lam)*(v[seq]/sv); probs=probs/float(probs.sum()); idxs=rng.choice(seq.size,size=d,replace=False,p=probs); guided+=1
            else: idxs=rng.choice(seq.size,size=d,replace=False)
            removed=seq[idxs].copy(); mask=np.ones(seq.size,bool); mask[idxs]=False; partial=seq[mask].copy(); partial,_,_,_=r.insertion_local_search_deadline(partial,p,rng,deadline,max_ls_passes)
            if time.perf_counter()>=deadline: break
            cand=partial
            for job in removed:
                if time.perf_counter()>=deadline: break
                pos,_,_,_=best_insert_ff(cand,int(job),p); cand=insert_at(cand,int(job),pos)
            if cand.size!=n or time.perf_counter()>=deadline: break
            cand,cand_c,_,_=r.insertion_local_search_deadline(cand,p,rng,deadline,max_ls_passes)
            accept=cand_c<=curr_c
            if not accept and temp>0: accept=rng.random()<math.exp((float(curr_c)-float(cand_c))/temp)
            if accept:
                seq=cand; curr_c=int(cand_c); accepts+=1
                if curr_c<C_ep:C_ep=curr_c
            if cand_c<best_c: best_c=int(cand_c); best_seq=cand.copy()
            if time.perf_counter()>=deadline: break
        rlocal=max(Cprev-C_ep,0)/float(Cprev); rglobal=max(Cbest_prev-best_c,0)/float(Cbest_prev); reward=eta*rlocal+(1-eta)*rglobal; improved=best_c<Cbest_prev; ns=1 if improved else 0
        Q[state,used_d-1]+=alpha*(reward+gamma*float(np.max(Q[ns]))-Q[state,used_d-1]); eps*=beta; d=(int(np.argmax(Q[ns]))+1) if rng.random()>=eps else int(rng.integers(1,4)); state=ns; episodes+=1
    return {'cmax':int(best_c),'seq':best_seq,'elapsed_sec':time.perf_counter()-start,'episodes':episodes,'iterations':iterations,'accepts':accepts,'guided_destructions':guided,'init_ls_passes':init_passes}

def qa(x,p,n): return bool(validate_permutation(x['seq'],n) and int(pfsp_cmax(x['seq'],p))==int(x['cmax']))
def run_one(pid,rep):
    fn=HERE/'raw'/f'{pid}_r{rep:02d}.json'
    if fn.exists(): return json.loads(fn.read_text())
    row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]; seed,ordn=r.seed_for(pid,rep); ub=r.ub_for(pid); g8,_,_=r.external_comparator_max_guided(pid,rep); P,off,ii,jj,ww=source(pid); share=off/H; B=g8+share
    print('GUIDED',pid,rep,flush=True); g=qig_fast(p,seed,g8,ii,jj,ww); okg=qa(g,p,n)
    print('BASE',pid,rep,flush=True); b=r.qig_deadline(p,seed,B); okb=qa(b,p,n)
    d={'status':'GREEN' if okg and okb else 'RED','problem':pid,'rep':rep,'seed':seed,'reference_ub':ub,'g8_sec':g8,'source_offline_sec':off,'share_sec':share,'baseline_budget_sec':B,'guided_cmax':g['cmax'],'baseline_cmax':b['cmax'],'guided_rpd':100*(g['cmax']-ub)/ub,'baseline_rpd':100*(b['cmax']-ub)/ub,'delta_rpd':100*(g['cmax']-b['cmax'])/ub,'guided_elapsed_sec':g['elapsed_sec'],'baseline_elapsed_sec':b['elapsed_sec'],'guided_iterations':g['iterations'],'guided_episodes':g['episodes'],'baseline_iterations':b['iterations'],'baseline_episodes':b['episodes'],'qa_guided':okg,'qa_baseline':okb}
    fn.write_text(json.dumps(d,indent=2)); return d

def main():
    r.warmup(); semantic_gate(); rows=[]
    for pid in PROBLEMS:
        for rep in REPS: rows.append(run_one(pid,rep))
    out=[]
    for pid in PROBLEMS:
        z=[x for x in rows if x['problem']==pid]; ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['guided_cmax']<x['baseline_cmax'] for x in z); t=sum(x['guided_cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        out.append({'problem':pid,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),'guided_batch_best_cmax':min(x['guided_cmax'] for x in z),'baseline_batch_best_cmax':min(x['baseline_cmax'] for x in z),'mean_guided_iterations':float(np.mean([x['guided_iterations'] for x in z])),'mean_baseline_iterations':float(np.mean([x['baseline_iterations'] for x in z])),'all_green':all(x['status']=='GREEN' for x in z)})
    with open(HERE/'transfer07_summary.csv','w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(out[0].keys())); wr.writeheader(); wr.writerows(out)
    qaobj={'status':'GREEN' if all(x['status']=='GREEN' for x in rows) else 'RED','semantic_regression':'GREEN','n_pairs':len(rows),'no_scientific_parameter_change':True}; (HERE/'transfer07_MASTER_QA.json').write_text(json.dumps(qaobj,indent=2)); print(json.dumps(out,indent=2)); print(json.dumps(qaobj,indent=2))
if __name__=='__main__': main()
