# transfer experiment 07 Report — n=50 Optimized Contrast-P Implementation

QA: GREEN. Semantic regression gate: GREEN (100 random permutations per problem; optimized and reference P-violation vectors matched to numerical precision).

No scientific parameter was changed from transfer experiment 05: Contrast-P only, always-active soft bias, lambda=0.25, H=10 reuse. Only P-score implementation overhead was reduced by precomputing positive edges and using a compiled accumulation loop.

Results (reps 6–10):
- Ta50_10_1: mean Delta RPD +0.066867; W/T/L 1/2/2; guided best 3025, baseline best 3025.
- Ta50_20_1: mean Delta RPD +0.259740; W/T/L 0/1/4; guided best 3893, baseline best 3880.

Conclusion: avoidable P-scoring overhead is not the main reason for the n=50 equal-budget failures. Even with the optimized implementation, equal-budget QIG remains stronger on these two instances.
