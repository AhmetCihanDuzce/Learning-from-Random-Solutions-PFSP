# PFSP transfer experiment 08 — n=50-specific reusable Contrast-P QIG calibration

Status: EXPLORATORY CALIBRATION. Frozen before execution.

## Motivation
Earlier equal-online transfer experiment 02 development runs showed that Contrast-P soft guidance could improve QIG on both n=50 targets, but the fixed n=100-oriented reusable H=10 configuration did not remain favorable after equal end-to-end budget accounting. This analysis phase explicitly allows n=50-specific calibration; it does not claim a single universal parameterization.

## Development targets
- Ta50_10_1
- Ta50_20_1
- external-comparator analysis replications 1–3 only for screening.

## Fixed mechanism
- Comparator: frozen QIG.
- Guidance: Contrast-P only; always-active soft destruction bias.
- One archived S=10,000n Contrast-P source per problem (transfer experiment 02 replication 1), reused without reming.
- No R rules.
- QIG learning, acceptance, local search, destruction-size learning, and all other parameters unchanged.

## n=50 calibration grid
Guidance strength lambda: {0.15, 0.25}
P-rule support retained from the archived top-3n set: {top 1n, top 2n, top 3n strongest rules}
Reuse horizon H for cost accounting: {10, 20, 50}

Guided online budget = frozen G8(k,r).
Unguided QIG online budget = G8(k,r) + T_off/H.
Thus every pair has the same amortized end-to-end budget.

Because H changes only cost accounting, not the guided search trajectory, each (lambda, topK) guided trajectory is run once per problem/replication and compared with three separately timed QIG baselines.

## Selection
Select one configuration separately for Ta50_10_1 and Ta50_20_1 by:
1. lowest mean paired Delta RPD (guided - baseline),
2. then more wins,
3. then smaller H,
4. then smaller lambda,
5. then larger retained P support.

No pooling across the two n=50 groups is required.

## Validation
After selection, validate each selected configuration on five fresh seeds r=11..15, not used in external-comparator analysis or prior analysis phase-9 tuning. Fixed online budget for each target is the median external-comparator analysis G8 over replications 1..10. Seed formula extends the frozen external-comparator analysis rule: 820260000 + 100*problem_ordinal + replication.

For validation:
- guided online time = fixed median G8;
- baseline QIG online time = fixed median G8 + T_off/H;
- same seed within each pair.

Primary validation criterion per problem: negative mean Delta RPD. Report W/T/L, mean and median Delta RPD, mean RPD, and batch-best Cmax. No significance claim from five pairs.
