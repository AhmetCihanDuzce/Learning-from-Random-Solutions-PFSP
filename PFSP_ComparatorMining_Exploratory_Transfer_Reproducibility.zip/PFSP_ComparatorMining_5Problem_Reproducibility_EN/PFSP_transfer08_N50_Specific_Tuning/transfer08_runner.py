from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,csv,time,math
from pathlib import Path
import numpy as np
from numba import njit
HERE=Path(__file__).resolve().parent
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias'); S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(S2)); sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from external_comparator_comparators import cmax_numba,best_insert_ff,insert_at,neh_ff,validate_permutation
from run_pfsp_single import pfsp_cmax
PROBLEMS=['Ta50_10_1','Ta50_20_1']; DEV_REPS=range(1,4); VAL_REPS=range(11,16)
LAMBDAS=[0.15,0.25]; KFACT=[1,2,3]; HORIZONS=[10,20,50]

@njit(cache=True)
def pvio_fast(seq,ii,jj,ww,n):
    pos=np.empty(n,np.int64)
    for k in range(seq.size): pos[seq[k]]=k
    v=np.zeros(n,np.float64)
    for k in range(ii.size):
        i=ii[k]; j=jj[k]
        if pos[i]>pos[j]:
            w=ww[k]; v[i]+=w; v[j]+=w
    return v

def full_source(pid):
    z=np.load(S2/'cache'/f'{pid}_r01_PC.npz',allow_pickle=False)
    P=z['PC']; off=float(z['offline_sec']); ii,jj=np.where(P>0); ww=P[ii,jj].astype(float)
    order=np.argsort(-ww,kind='stable')
    return P,off,ii[order].astype(np.int64),jj[order].astype(np.int64),ww[order]

def subset_source(pid,kfac):
    P,off,ii,jj,ww=full_source(pid); n=P.shape[0]; k=min(int(kfac*n),len(ww))
    return off,ii[:k].copy(),jj[:k].copy(),ww[:k].copy()

def qig_guided(p,seed,time_limit_sec,ii,jj,ww,lam,tau=.7,epsilon=.8,beta=.996,alpha=.6,gamma=.8,E=6,eta=.3,max_ls_passes=100):
    n,m=p.shape; rng=np.random.default_rng(seed); start=time.perf_counter(); deadline=start+float(time_limit_sec)
    seq,_=neh_ff(p); best_seq=seq.copy(); best_c=int(cmax_numba(seq,p)); seq,curr_c,init_passes,_=r.insertion_local_search_deadline(seq,p,rng,deadline,max_ls_passes)
    if curr_c<best_c: best_c=int(curr_c); best_seq=seq.copy()
    Q=np.zeros((2,3),float); state=0; d=int(rng.integers(1,4)); temp=float(tau)*float(p.sum())/float(n*m*10.0); episodes=iterations=accepts=guided=0; eps=float(epsilon)
    while time.perf_counter()<deadline:
        Cprev=int(curr_c); Cbest_prev=int(best_c); C_ep=int(curr_c); used_d=d
        for _ in range(E):
            if time.perf_counter()>=deadline: break
            iterations+=1; v=pvio_fast(seq,ii,jj,ww,n); sv=float(v.sum())
            if sv>0:
                probs=(1.0-float(lam))/float(n)+float(lam)*(v[seq]/sv); probs=probs/float(probs.sum()); idxs=rng.choice(seq.size,size=d,replace=False,p=probs); guided+=1
            else: idxs=rng.choice(seq.size,size=d,replace=False)
            removed=seq[idxs].copy(); mask=np.ones(seq.size,bool); mask[idxs]=False; partial=seq[mask].copy(); partial,_,_,_=r.insertion_local_search_deadline(partial,p,rng,deadline,max_ls_passes)
            if time.perf_counter()>=deadline: break
            cand=partial
            for job in removed:
                if time.perf_counter()>=deadline: break
                pos,_,_,_=best_insert_ff(cand,int(job),p); cand=insert_at(cand,int(job),pos)
            if cand.size!=n or time.perf_counter()>=deadline: break
            cand,cand_c,_,_=r.insertion_local_search_deadline(cand,p,rng,deadline,max_ls_passes)
            accept=cand_c<=curr_c
            if not accept and temp>0: accept=rng.random()<math.exp((float(curr_c)-float(cand_c))/temp)
            if accept:
                seq=cand; curr_c=int(cand_c); accepts+=1
                if curr_c<C_ep:C_ep=curr_c
            if cand_c<best_c: best_c=int(cand_c); best_seq=cand.copy()
            if time.perf_counter()>=deadline: break
        rlocal=max(Cprev-C_ep,0)/float(Cprev); rglobal=max(Cbest_prev-best_c,0)/float(Cbest_prev); reward=eta*rlocal+(1-eta)*rglobal; improved=best_c<Cbest_prev; ns=1 if improved else 0
        Q[state,used_d-1]+=alpha*(reward+gamma*float(np.max(Q[ns]))-Q[state,used_d-1]); eps*=beta; d=(int(np.argmax(Q[ns]))+1) if rng.random()>=eps else int(rng.integers(1,4)); state=ns; episodes+=1
    return {'cmax':int(best_c),'seq':best_seq,'elapsed_sec':time.perf_counter()-start,'episodes':episodes,'iterations':iterations,'accepts':accepts,'guided_destructions':guided}

def qa(x,p,n): return bool(validate_permutation(x['seq'],n) and int(pfsp_cmax(x['seq'],p))==int(x['cmax']))
def seed_ext(pid,rep):
    # ordinal from any historical rep
    _,ordn=r.seed_for(pid,1); return 820260000+100*ordn+rep,ordn

def problem_data(pid):
    row=r.load_manifest_row(r.PFSP_ROOT,pid); return r.load_instance(r.PFSP_ROOT,row)[0],r.ub_for(pid)

def warm_sources():
    for pid in PROBLEMS:
        p,_=problem_data(pid); n=p.shape[0]; off,ii,jj,ww=subset_source(pid,1); pvio_fast(np.arange(n,dtype=np.int64),ii,jj,ww,n)

def run_dev():
    (HERE/'raw_dev').mkdir(exist_ok=True)
    rows=[]
    for pid in PROBLEMS:
        p,ub=problem_data(pid); n=p.shape[0]; _,off,_,_,_=full_source(pid)
        # baselines by H and rep
        bases={}
        for rep in DEV_REPS:
            seed,ordn=r.seed_for(pid,rep); g8,_,_=r.external_comparator_max_guided(pid,rep)
            for H in HORIZONS:
                fn=HERE/'raw_dev'/f'{pid}_r{rep:02d}_BASE_H{H}.json'
                if fn.exists(): d=json.loads(fn.read_text())
                else:
                    b=r.qig_deadline(p,seed,g8+off/H); ok=qa(b,p,n); d={'problem':pid,'rep':rep,'H':H,'seed':seed,'g8':g8,'off':off,'budget':g8+off/H,'cmax':b['cmax'],'rpd':100*(b['cmax']-ub)/ub,'elapsed':b['elapsed_sec'],'qa':ok}; fn.write_text(json.dumps(d,indent=2))
                bases[(rep,H)]=d
        guided={}
        for rep in DEV_REPS:
            seed,ordn=r.seed_for(pid,rep); g8,_,_=r.external_comparator_max_guided(pid,rep)
            for kf in KFACT:
                off2,ii,jj,ww=subset_source(pid,kf)
                for lam in LAMBDAS:
                    tag=f'K{kf}n_L{int(round(lam*100)):02d}'
                    fn=HERE/'raw_dev'/f'{pid}_r{rep:02d}_{tag}.json'
                    if fn.exists(): d=json.loads(fn.read_text())
                    else:
                        g=qig_guided(p,seed,g8,ii,jj,ww,lam); ok=qa(g,p,n); d={'problem':pid,'rep':rep,'seed':seed,'g8':g8,'kfac':kf,'lambda':lam,'cmax':g['cmax'],'rpd':100*(g['cmax']-ub)/ub,'elapsed':g['elapsed_sec'],'iterations':g['iterations'],'qa':ok}; fn.write_text(json.dumps(d,indent=2))
                    guided[(rep,kf,lam)]=d
        for H in HORIZONS:
            for kf in KFACT:
                for lam in LAMBDAS:
                    zz=[]
                    for rep in DEV_REPS:
                        g=guided[(rep,kf,lam)]; b=bases[(rep,H)]; delta=100*(g['cmax']-b['cmax'])/ub; zz.append((delta,g,b))
                    ds=np.array([x[0] for x in zz]); w=sum(x[1]['cmax']<x[2]['cmax'] for x in zz); t=sum(x[1]['cmax']==x[2]['cmax'] for x in zz); l=len(zz)-w-t
                    rows.append({'problem':pid,'H':H,'kfac':kf,'lambda':lam,'n_pairs':len(zz),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,'mean_guided_rpd':float(np.mean([x[1]['rpd'] for x in zz])),'mean_baseline_rpd':float(np.mean([x[2]['rpd'] for x in zz]))})
    # ranks per problem
    selected={}
    for pid in PROBLEMS:
        z=[x for x in rows if x['problem']==pid]
        z.sort(key=lambda x:(x['mean_delta_rpd'],-x['wins'],x['H'],x['lambda'],-x['kfac']))
        for rank,x in enumerate(z,1): x['rank']=rank; x['selected']=rank==1
        selected[pid]=z[0]
    rows.sort(key=lambda x:(x['problem'],x['rank']))
    with open(HERE/'transfer08_development_summary.csv','w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)
    (HERE/'transfer08_selection.json').write_text(json.dumps(selected,indent=2))
    return selected

def run_validation(selected):
    (HERE/'raw_val').mkdir(exist_ok=True); rows=[]
    for pid in PROBLEMS:
        p,ub=problem_data(pid); n=p.shape[0]; cfg=selected[pid]; H=int(cfg['H']); kf=int(cfg['kfac']); lam=float(cfg['lambda']); off,ii,jj,ww=subset_source(pid,kf)
        gs=[r.external_comparator_max_guided(pid,rep)[0] for rep in range(1,11)]; gfix=float(np.median(gs)); share=off/H; bfix=gfix+share
        for rep in VAL_REPS:
            seed,ordn=seed_ext(pid,rep); fn=HERE/'raw_val'/f'{pid}_r{rep:02d}.json'
            if fn.exists(): d=json.loads(fn.read_text()); rows.append(d); continue
            g=qig_guided(p,seed,gfix,ii,jj,ww,lam); b=r.qig_deadline(p,seed,bfix); okg=qa(g,p,n); okb=qa(b,p,n)
            d={'status':'GREEN' if okg and okb else 'RED','problem':pid,'rep':rep,'seed':seed,'H':H,'kfac':kf,'lambda':lam,'gfix_sec':gfix,'source_offline_sec':off,'share_sec':share,'equal_total_budget_sec':bfix,'guided_cmax':g['cmax'],'baseline_cmax':b['cmax'],'guided_rpd':100*(g['cmax']-ub)/ub,'baseline_rpd':100*(b['cmax']-ub)/ub,'delta_rpd':100*(g['cmax']-b['cmax'])/ub,'guided_elapsed_sec':g['elapsed_sec'],'baseline_elapsed_sec':b['elapsed_sec'],'qa_guided':okg,'qa_baseline':okb}; fn.write_text(json.dumps(d,indent=2)); rows.append(d)
    out=[]
    for pid in PROBLEMS:
        z=[x for x in rows if x['problem']==pid]; ds=np.array([x['delta_rpd'] for x in z]); w=sum(x['guided_cmax']<x['baseline_cmax'] for x in z); t=sum(x['guided_cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        out.append({'problem':pid,'n_pairs':len(z),'H':z[0]['H'],'kfac':z[0]['kfac'],'lambda':z[0]['lambda'],'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),'guided_batch_best_cmax':min(x['guided_cmax'] for x in z),'baseline_batch_best_cmax':min(x['baseline_cmax'] for x in z),'all_green':all(x['status']=='GREEN' for x in z)})
    with open(HERE/'transfer08_validation_summary.csv','w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(out[0].keys())); wr.writeheader(); wr.writerows(out)
    return out

def main():
    r.warmup(); warm_sources(); sel=run_dev(); print('SELECTED',json.dumps(sel,indent=2),flush=True); out=run_validation(sel); print('VALIDATION',json.dumps(out,indent=2),flush=True)
if __name__=='__main__': main()
