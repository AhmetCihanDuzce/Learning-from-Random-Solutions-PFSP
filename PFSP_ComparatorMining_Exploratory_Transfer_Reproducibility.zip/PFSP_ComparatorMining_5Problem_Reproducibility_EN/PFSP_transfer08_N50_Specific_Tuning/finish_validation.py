import json,sys
from pathlib import Path
D=(Path(__file__).resolve().parent.parent/'PFSP_transfer08_N50_Specific_Tuning')
sys.path.insert(0,str(D))
import transfer08_runner as s
sel=json.loads((D/'transfer08_selection.json').read_text())
s.r.warmup(); s.warm_sources(); out=s.run_validation(sel); print(json.dumps(out,indent=2))
