import json,sys,csv
from pathlib import Path
import numpy as np
S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot'); sys.path.insert(0,str(S1)); import transfer01_runner as r
D=(Path(__file__).resolve().parent.parent/'PFSP_transfer08_N50_Specific_Tuning'); OUT=D/'raw_val_equal_online'; OUT.mkdir(exist_ok=True)
for pid in ['Ta50_10_1','Ta50_20_1']:
    row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); ub=r.ub_for(pid)
    gfix=float(np.median([r.external_comparator_max_guided(pid,rep)[0] for rep in range(1,11)]))
    _,ordn=r.seed_for(pid,1)
    for rep in range(11,16):
        seed=820260000+100*ordn+rep
        fn=OUT/f'{pid}_r{rep:02d}.json'
        if fn.exists(): continue
        b=r.qig_deadline(p,seed,gfix)
        fn.write_text(json.dumps({'problem':pid,'rep':rep,'seed':seed,'gfix_sec':gfix,'cmax':b['cmax'],'rpd':100*(b['cmax']-ub)/ub,'elapsed_sec':b['elapsed_sec']},indent=2))
rows=[]
for pid in ['Ta50_10_1','Ta50_20_1']:
    ub=r.ub_for(pid); ds=[]; w=t=l=0; gr=[]; br=[]
    for rep in range(11,16):
        g=json.loads((D/'raw_val'/f'{pid}_r{rep:02d}.json').read_text()); b=json.loads((OUT/f'{pid}_r{rep:02d}.json').read_text())
        delta=100*(g['guided_cmax']-b['cmax'])/ub; ds.append(delta); gr.append(g['guided_rpd']); br.append(b['rpd'])
        if g['guided_cmax']<b['cmax']: w+=1
        elif g['guided_cmax']==b['cmax']: t+=1
        else:l+=1
    rows.append({'problem':pid,'mean_delta_rpd':float(np.mean(ds)),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,'mean_guided_rpd':float(np.mean(gr)),'mean_equal_online_baseline_rpd':float(np.mean(br))})
with open(D/'transfer08_equal_online_validation_summary.csv','w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=list(rows[0])); wr.writeheader(); wr.writerows(rows)
print(json.dumps(rows,indent=2))
