#!/usr/bin/env python3
"""Small end-to-end translation check using Ta20_5_1 (five repetitions)."""
from math import isclose
from run_pfsp_single import Config, run_pfsp_single

cfg = Config(verbose=False, write_outputs=False, audit_historical=True)
r = run_pfsp_single("Ta20_5_1", cfg)

assert r["base_cmax"].tolist() == [1286, 1299, 1329, 1289, 1297]
assert r["pool_best"][0] == 1303
assert isclose(r["pool_mean"][0], 1515.62061, rel_tol=0.0, abs_tol=1e-12)
assert isclose(r["pool_sd_sample"][0], 60.14196786362575, rel_tol=0.0, abs_tol=1e-12)
assert r["pool_worst"][0] == 1784

print("CORE TRANSLATION SELF-TEST: PASS")
audit = r["historical_reference_audit"]
if audit and audit["mismatches"] == 0:
    print(f"HISTORICAL REFERENCE AUDIT: PASS ({audit['matched']}/{audit['checked']})")
else:
    print("HISTORICAL REFERENCE AUDIT: NOT IDENTICAL on this environment")
    print("This may reflect equal-Cmax quicksort tie ordering; see README Section 7.")
