Generated result folders appear here.
