from run_pfsp_single import Config, run_pfsp_single

# Default: NumPy PCG64 pools + NumPy quicksort boundary ordering.
cfg = Config(audit_detail=True)
results = run_pfsp_single("Ta20_5_1", cfg)

print("\nElite Mean-of-Five:", results["elite_mean_cmax"])
print("Contrast Mean-of-Five:", results["contrast_mean_cmax"])
