Temporary pool files are created here and normally deleted after each repetition.
