#!/usr/bin/env python3
"""Pure-Python/NumPy single-instance runner for the 140-instance PFSP study.

The program reproduces the computational protocol used in the accompanying
study for one selected benchmark instance:

    random permutation pool -> Elite/Poor -> P/R mining ->
    Base / Elite-only / Contrast heuristic runs -> validation -> summary

Runtime dependencies
--------------------
Python 3 and NumPy only.  No MATLAB, SciPy, pandas, Numba, external solver,
or compiled user extension is required.

Historical stochastic layer
---------------------------
The original pool generator used NumPy default_rng (PCG64).  This runner uses
that generator directly.  The five problem-specific seed values are read from
seed_manifest.csv.  Pool Cmax values are ranked with NumPy quicksort by
default because that is the sorting convention used in the archived experiment.
Equal-Cmax rows at an Elite/Poor cutoff can be ordered differently by another
NumPy/CPU implementation; therefore the optional historical-reference check is
an ex-post audit, not an input to the algorithm.

No benchmark UB/LB value or best-known permutation is used in pool generation,
mining, guidance, reinsertion, or acceptance decisions.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import shutil
import sys
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np


FAMILIES = ["NEH", "NEH-TBKK2", "KK2-style-NEH", "FRB4-p1", "INEH-inspired"]


@dataclass
class Config:
    """Runtime controls; scientific protocol parameters are frozen in code."""

    verbose: bool = True
    write_outputs: bool = True
    keep_intermediate: bool = False
    pool_generation_batch: int = 25_000
    pool_read_batch: int = 50_000
    boundary_tie_mode: str = "numpy_quicksort"  # or "deterministic"
    audit_historical: bool = True
    audit_detail: bool = False
    temp_dir: str | None = None
    output_dir: str | None = None


# ============================================================================
# CSV helpers and instance loading
# ============================================================================


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def load_manifest_row(root: Path, problem_id: str) -> dict[str, str]:
    rows = read_csv_rows(root / "instance_manifest.csv")
    matches = [r for r in rows if r["ProblemID"] == problem_id]
    if len(matches) != 1:
        valid = ", ".join(r["ProblemID"] for r in rows[:8])
        raise ValueError(
            f"Unknown ProblemID {problem_id!r}. Use an ID in instance_manifest.csv "
            f"(examples: {valid}, ...)."
        )
    return matches[0]


def parse_taillard(path: Path, target_idx: int) -> tuple[np.ndarray, dict]:
    text = path.read_text(encoding="utf-8", errors="replace")
    marker = "number of jobs, number of machines, initial seed, upper bound and lower bound :"
    starts = [m.start() for m in re.finditer(re.escape(marker), text)]
    if target_idx < 1 or target_idx > len(starts):
        raise ValueError(f"Invalid Taillard instance index {target_idx} in {path}")

    s = starts[target_idx - 1]
    e = starts[target_idx] if target_idx < len(starts) else len(text)
    block = text[s:e]

    header_nums = [int(x) for x in re.findall(r"-?\d+", block[len(marker) :])[:5]]
    if len(header_nums) < 5:
        raise ValueError(f"Cannot parse Taillard header in {path}")
    n, m, initial_seed, ub, lb = header_nums

    pt_marker = "processing times :"
    pos = block.find(pt_marker)
    if pos < 0:
        raise ValueError(f"Processing-time marker missing in {path}")
    raw = [int(x) for x in re.findall(r"-?\d+", block[pos + len(pt_marker) :])]
    if len(raw) < n * m:
        raise ValueError(f"Not enough processing times in {path}")

    # Taillard file: m machine rows x n jobs.  Internal form: n jobs x m machines.
    p = np.asarray(raw[: n * m], dtype=np.int64).reshape(m, n).T.copy()
    meta = {
        "source": "Taillard",
        "initial_seed": initial_seed,
        "reported_UB": ub,
        "reported_LB": lb,
    }
    return p, meta


def parse_vfr(path: Path) -> tuple[np.ndarray, dict]:
    with path.open("r", encoding="utf-8", errors="replace") as f:
        first = f.readline().strip().split()
        if len(first) < 2:
            raise ValueError(f"Malformed VFR header in {path}")
        n, m = int(first[0]), int(first[1])
        p = np.zeros((n, m), dtype=np.int64)
        for i in range(n):
            line = f.readline()
            if not line:
                raise ValueError(f"Unexpected end of VFR file at job row {i+1}: {path}")
            vals = [int(x) for x in line.split()]
            if len(vals) != 2 * m:
                raise ValueError(f"Malformed VFR row {i+1} in {path}")
            machines = vals[0::2]
            times = vals[1::2]
            if machines != list(range(m)):
                raise ValueError(f"Unexpected VFR machine indices in row {i+1}: {path}")
            p[i, :] = times
    return p, {"source": "VFR", "reported_UB": None, "reported_LB": None}


def load_instance(root: Path, row: dict[str, str]) -> tuple[np.ndarray, dict]:
    path = root / row["DataFile"]
    source = row["SourceType"].lower()
    if source == "taillard":
        p, meta = parse_taillard(path, int(row["InstanceIndex"]))
    elif source == "vfr":
        p, meta = parse_vfr(path)
    else:
        raise ValueError(f"Unknown SourceType: {row['SourceType']}")

    expected = (int(row["n"]), int(row["m"]))
    if p.shape != expected:
        raise AssertionError(f"Loaded matrix shape {p.shape} differs from manifest {expected}")
    return p, meta


def load_seed_rows(root: Path, problem_id: str) -> list[dict[str, str]]:
    rows = [r for r in read_csv_rows(root / "seed_manifest.csv") if r["ProblemID"] == problem_id]
    rows.sort(key=lambda r: int(r["Replication"]))
    if len(rows) != 5:
        raise AssertionError(f"Expected exactly five historical seeds for {problem_id}; found {len(rows)}")
    return rows


# ============================================================================
# PFSP objective and random pools
# ============================================================================


def pfsp_cmax(seq: Sequence[int], p: np.ndarray) -> int:
    """PFSP makespan for a 0-based job sequence."""
    m = p.shape[1]
    comp = np.zeros(m, dtype=np.int64)
    for job in seq:
        jjob = int(job)
        for machine in range(m):
            left = 0 if machine == 0 else int(comp[machine - 1])
            comp[machine] = max(int(comp[machine]), left) + int(p[jjob, machine])
    return int(comp[-1])


def cmax_pool(pool: np.ndarray, p: np.ndarray) -> np.ndarray:
    """Vectorized Cmax for a batch of 0-based permutations."""
    b, n = pool.shape
    m = p.shape[1]
    comp = np.zeros((b, m), dtype=np.int64)
    for t in range(n):
        jobs = pool[:, t].astype(np.intp, copy=False)
        for machine in range(m):
            proc = p[jobs, machine]
            left = 0 if machine == 0 else comp[:, machine - 1]
            comp[:, machine] = np.maximum(comp[:, machine], left) + proc
    return comp[:, -1].copy()


def all_insert_cmax(seq: Sequence[int], job: int, p: np.ndarray) -> np.ndarray:
    seq = list(map(int, seq))
    out = np.empty(len(seq) + 1, dtype=np.int64)
    for pos in range(len(seq) + 1):
        cand = seq[:pos] + [int(job)] + seq[pos:]
        out[pos] = pfsp_cmax(cand, p)
    return out


def generate_pool_to_memmap(
    seed: int,
    pool_size: int,
    n: int,
    path: Path,
    batch_size: int,
    verbose: bool,
) -> np.memmap:
    """Generate uniform random permutations using NumPy default_rng / PCG64.

    Each permutation is obtained by sorting n independent U(0,1) keys, matching
    the historical pool-generation mechanism.  Jobs are stored 0-based as uint16.
    """
    rng = np.random.default_rng(seed)
    pool = np.memmap(path, dtype=np.uint16, mode="w+", shape=(pool_size, n))
    done = 0
    while done < pool_size:
        b = min(batch_size, pool_size - done)
        keys = rng.random((b, n), dtype=np.float64)
        # Ties between continuous random keys are extraordinarily rare; quicksort
        # is specified to mirror the historical implementation convention.
        perms = np.argsort(keys, axis=1, kind="quicksort").astype(np.uint16, copy=False)
        pool[done : done + b, :] = perms
        done += b
        if verbose:
            print(f"  PCG64 pool generation: {done:,} / {pool_size:,} rows")
    pool.flush()
    return pool


def cmax_memmap(pool: np.memmap, p: np.ndarray, batch_size: int, verbose: bool) -> np.ndarray:
    s = pool.shape[0]
    cs = np.empty(s, dtype=np.int64)
    done = 0
    while done < s:
        b = min(batch_size, s - done)
        cs[done : done + b] = cmax_pool(np.asarray(pool[done : done + b]), p)
        done += b
        if verbose:
            print(f"  Cmax evaluation:       {done:,} / {s:,} rows")
    return cs


def selection_indices(cs: np.ndarray, elite_n: int, poor_n: int, mode: str) -> tuple[np.ndarray, np.ndarray]:
    """Return 0-based pool row indices for Elite and Poor sets."""
    mode = mode.lower()
    if mode == "numpy_quicksort":
        idx = np.argsort(cs, kind="quicksort")
    elif mode == "deterministic":
        # Portable tie rule: objective first, original row index second.
        idx = np.lexsort((np.arange(cs.size, dtype=np.int64), cs))
    else:
        raise ValueError("boundary_tie_mode must be 'numpy_quicksort' or 'deterministic'")
    return idx[:elite_n].astype(np.int64), idx[-poor_n:].astype(np.int64)


# ============================================================================
# Orders and base heuristic mechanisms
# ============================================================================


def tpt_order(p: np.ndarray) -> np.ndarray:
    n = p.shape[0]
    # Primary: descending total processing time. Secondary: ascending job id.
    return np.lexsort((np.arange(n), -p.sum(axis=1))).astype(np.int64)


def kk2_ab(job: int, p: np.ndarray) -> tuple[float, float]:
    m = p.shape[1]
    constant = (m - 1) * (m - 2) / 2
    a = 0.0
    b = 0.0
    for r in range(m):
        a += (constant + (m - (r + 1))) * float(p[job, r])
        b += (constant + r) * float(p[job, r])
    return a, b


def kk2_style_order(p: np.ndarray) -> np.ndarray:
    n = p.shape[0]
    a = np.zeros(n, dtype=float)
    b = np.zeros(n, dtype=float)
    for job in range(n):
        a[job], b[job] = kk2_ab(job, p)

    front = np.flatnonzero(a <= b)
    back = np.flatnonzero(a > b)
    if front.size:
        front = front[np.lexsort((front, a[front]))]
    if back.size:
        back = back[np.lexsort((back, -b[back]))]
    return np.concatenate((front, back)).astype(np.int64)


def fallback_position(candidates: np.ndarray, job: int, p: np.ndarray, tie_rule: int) -> int:
    if tie_rule == 0:  # earliest
        return int(candidates[0])
    if tie_rule == 1:  # latest
        return int(candidates[-1])
    a, b = kk2_ab(job, p)
    return int(candidates[0] if a >= b else candidates[-1])


def choose_insert(seq: Sequence[int], job: int, p: np.ndarray, tie_rule: int) -> tuple[int, int]:
    vals = all_insert_cmax(seq, job, p)
    best = int(vals.min())
    cand = np.flatnonzero(vals == best)
    return fallback_position(cand, job, p, tie_rule), best


def construct_neh_base(order: Sequence[int], p: np.ndarray, tie_rule: int) -> tuple[list[int], int]:
    order = list(map(int, order))
    seq = [order[0]]
    for job in order[1:]:
        pos, _ = choose_insert(seq, job, p, tie_rule)
        seq = seq[:pos] + [job] + seq[pos:]
    return seq, pfsp_cmax(seq, p)


def strict_best_reinsert(seq: Sequence[int], job: int, p: np.ndarray, tie_rule: int) -> tuple[list[int], int]:
    red = list(map(int, seq))
    red.remove(int(job))
    vals = all_insert_cmax(red, int(job), p)
    best = int(vals.min())
    cand = np.flatnonzero(vals == best)
    pos = fallback_position(cand, int(job), p, tie_rule)
    return red[:pos] + [int(job)] + red[pos:], best


def construct_frb4_base(
    order: Sequence[int], p: np.ndarray, p_neigh: int, tie_rule: int
) -> tuple[list[int], int]:
    order = list(map(int, order))
    seq = [order[0]]
    for job in order[1:]:
        pos, _ = choose_insert(seq, job, p, tie_rule)
        seq = seq[:pos] + [job] + seq[pos:]

        neigh: list[int] = []
        for d in range(1, p_neigh + 1):
            if pos - d >= 0:
                neigh.append(seq[pos - d])
            if pos + d < len(seq):
                neigh.append(seq[pos + d])

        current = pfsp_cmax(seq, p)
        for j2 in neigh:
            cand, cc = strict_best_reinsert(seq, j2, p, tie_rule)
            if cc < current:
                seq, current = cand, cc
    return seq, pfsp_cmax(seq, p)


# ============================================================================
# P/R mining
# ============================================================================


def group_stats(seqs: np.ndarray, n: int, regions: int) -> tuple[np.ndarray, np.ndarray]:
    """Pairwise precedence and relative-position frequencies for one group."""
    g = seqs.shape[0]
    # uint16 is sufficient for n<=200 and limits memory use.
    pos = np.empty((g, n), dtype=np.uint16)
    rows = np.arange(g, dtype=np.int64)[:, None]
    pos[rows, seqs.astype(np.intp, copy=False)] = np.arange(n, dtype=np.uint16)

    P = np.zeros((n, n), dtype=np.float64)
    for i in range(n - 1):
        pi = pos[:, i]
        for j in range(i + 1, n):
            v = np.count_nonzero(pi < pos[:, j]) / g
            P[i, j] = v
            P[j, i] = 1.0 - v

    R = np.zeros((n, regions), dtype=np.float64)
    for job in range(n):
        rg = np.minimum((pos[:, job].astype(np.int64) * regions) // n, regions - 1)
        R[job, :] = np.bincount(rg, minlength=regions) / g
    return P, R


def filter_precedence(M: np.ndarray, k: int) -> np.ndarray:
    n = M.shape[0]
    pairs: list[tuple[float, int, int, int]] = []
    z = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            z += 1
            pairs.append((-abs(float(M[i, j])), z, i, j))
    pairs.sort(key=lambda x: (x[0], x[1]))

    out = np.zeros_like(M)
    for _, _, i, j in pairs[: min(k, len(pairs))]:
        out[i, j] = M[i, j]
        out[j, i] = M[j, i]
    return out


def mine_pr_rules(
    elite: np.ndarray, poor: np.ndarray, n: int, regions: int, top_p: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    ep, er = group_stats(elite, n, regions)
    bp, br = group_stats(poor, n, regions)
    PE_full = ep - 0.5
    PC_full = ep - bp
    RE = er - 1.0 / regions
    RC = er - br
    return filter_precedence(PE_full, top_p), RE, filter_precedence(PC_full, top_p), RC


# ============================================================================
# Information-guided insertion and reinsertion
# ============================================================================


def insertion_score(partial: Sequence[int], job: int, pos: int, P: np.ndarray, R: np.ndarray) -> float:
    before = list(partial[:pos])
    after = list(partial[pos:])
    ps = 0.0
    if before:
        ps += float(np.sum(P[np.asarray(before, dtype=np.intp), job]))
    if after:
        ps += float(np.sum(P[job, np.asarray(after, dtype=np.intp)]))
    ps /= max(1, len(partial))

    k = len(partial) + 1
    regions = R.shape[1]
    reg = min((pos * regions) // k, regions - 1)
    return 0.65 * ps + 0.35 * float(R[job, reg])


def info_best_insert(
    seq: Sequence[int], job: int, p: np.ndarray, P: np.ndarray, R: np.ndarray, fallback_tie_rule: int
) -> tuple[int, int]:
    vals = all_insert_cmax(seq, job, p)
    best = int(vals.min())
    cand = np.flatnonzero(vals == best)
    if cand.size == 1:
        return int(cand[0]), best

    scores = np.asarray([insertion_score(seq, job, int(k), P, R) for k in cand], dtype=float)
    mx = float(scores.max())
    top = np.flatnonzero(scores == mx)
    pref = fallback_position(cand, job, p, fallback_tie_rule)
    for ix in top:
        if int(cand[ix]) == pref:
            return pref, best
    return int(cand[top[0]]), best


def construct_info_neh(
    order: Sequence[int], p: np.ndarray, P: np.ndarray, R: np.ndarray, fallback_tie_rule: int
) -> tuple[list[int], int]:
    order = list(map(int, order))
    seq = [order[0]]
    for job in order[1:]:
        pos, _ = info_best_insert(seq, job, p, P, R, fallback_tie_rule)
        seq = seq[:pos] + [job] + seq[pos:]
    return seq, pfsp_cmax(seq, p)


def current_violation(seq: Sequence[int], P: np.ndarray, R: np.ndarray) -> np.ndarray:
    N = P.shape[0]
    nseq = len(seq)
    pos = np.zeros(N, dtype=np.int64)
    present = np.zeros(N, dtype=bool)
    for k, job in enumerate(seq):
        pos[job] = k
        present[job] = True

    v = np.zeros(N, dtype=float)
    ii, jj = np.where(P > 0)
    for i, j in zip(ii.tolist(), jj.tolist()):
        if present[i] and present[j] and pos[i] > pos[j]:
            w = 0.65 * float(P[i, j])
            v[i] += w
            v[j] += w

    regions = R.shape[1]
    mx = R.max(axis=1)
    for k, job in enumerate(seq):
        rg = min((k * regions) // nseq, regions - 1)
        v[job] += 0.35 * max(0.0, float(mx[job] - R[job, rg]))
    return v


def construct_info_frb4(
    order: Sequence[int],
    p: np.ndarray,
    P: np.ndarray,
    R: np.ndarray,
    p_neigh: int,
    q_info: int,
    fallback_tie_rule: int,
) -> tuple[list[int], int]:
    order = list(map(int, order))
    seq = [order[0]]

    for job in order[1:]:
        pos, _ = info_best_insert(seq, job, p, P, R, fallback_tie_rule)
        seq = seq[:pos] + [job] + seq[pos:]

        neigh: list[int] = []
        for d in range(1, p_neigh + 1):
            if pos - d >= 0:
                neigh.append(seq[pos - d])
            if pos + d < len(seq):
                neigh.append(seq[pos + d])

        current = pfsp_cmax(seq, p)
        for j2 in neigh:
            cand, cc = strict_best_reinsert(seq, j2, p, fallback_tie_rule)
            if cc < current:
                seq, current = cand, cc

        v = current_violation(seq, P, R)
        # Descending violation; preserve current sequence order on ties.
        ordered_jobs = [x for _, x in sorted(enumerate(seq), key=lambda t: (-v[t[1]], t[0]))]
        info_jobs: list[int] = []
        for j2 in ordered_jobs:
            if j2 != job and j2 not in neigh:
                info_jobs.append(j2)
                if len(info_jobs) >= q_info:
                    break

        for j2 in info_jobs:
            cand, cc = strict_best_reinsert(seq, j2, p, fallback_tie_rule)
            if cc < current:
                seq, current = cand, cc

    return seq, pfsp_cmax(seq, p)


# ============================================================================
# Validation, reporting, and serialization
# ============================================================================


def validate_solution(seq: Sequence[int], cmax: int, p: np.ndarray, n: int) -> None:
    if len(seq) != n:
        raise AssertionError("Wrong sequence length")
    if sorted(seq) != list(range(n)):
        raise AssertionError("Sequence is not a permutation of jobs 0..n-1")
    check = pfsp_cmax(seq, p)
    if check != int(cmax):
        raise AssertionError(f"Stored Cmax {cmax} differs from recomputed Cmax {check}")


def validate_historical(
    root: Path,
    problem_id: str,
    seeds: list[int],
    base_cmax: np.ndarray,
    elite_cmax: np.ndarray,
    contrast_cmax: np.ndarray,
    detail: bool,
) -> dict:
    rows = [r for r in read_csv_rows(root / "historical_reference.csv") if r["ProblemID"] == problem_id]
    lookup = {(int(r["Replication"]), r["Mining"], r["Family"]): r for r in rows}
    mismatches: list[dict] = []
    checked = 0

    for rep in range(5):
        for f, fam in enumerate(FAMILIES):
            for mining, got in (
                ("Elite-only", int(elite_cmax[f, rep])),
                ("Contrast", int(contrast_cmax[f, rep])),
            ):
                checked += 1
                q = lookup.get((rep + 1, mining, fam))
                ok = (
                    q is not None
                    and int(q["Seed"]) == seeds[rep]
                    and int(q["RawCmax"]) == got
                    and int(q["BaseCmax"]) == int(base_cmax[f])
                )
                if not ok:
                    item = {
                        "replication": rep + 1,
                        "mining": mining,
                        "family": fam,
                        "got": got,
                        "expected": None if q is None else int(q["RawCmax"]),
                    }
                    mismatches.append(item)
                    if detail:
                        print("  MISMATCH", item)
    return {
        "checked": checked,
        "matched": checked - len(mismatches),
        "mismatches": len(mismatches),
        "details": mismatches if detail else [],
    }


def json_safe(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, dict):
        return {k: json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    return obj


def write_outputs(root: Path, cfg: Config, results: dict) -> Path:
    output_root = Path(cfg.output_dir) if cfg.output_dir else root / "results"
    outdir = output_root / results["problem_id"]
    outdir.mkdir(parents=True, exist_ok=True)
    pid = results["problem_id"]

    summary_path = outdir / f"{pid}_summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(
            [
                "Family",
                "Base_Cmax",
                "Elite_MeanOfFive",
                "Elite_BestOfFive",
                "Elite_MeanGainPct",
                "Contrast_MeanOfFive",
                "Contrast_BestOfFive",
                "Contrast_MeanGainPct",
            ]
        )
        for i, fam in enumerate(FAMILIES):
            w.writerow(
                [
                    fam,
                    int(results["base_cmax"][i]),
                    float(results["elite_mean_cmax"][i]),
                    int(results["elite_best_cmax"][i]),
                    float(results["elite_mean_gain_pct"][i]),
                    float(results["contrast_mean_cmax"][i]),
                    int(results["contrast_best_cmax"][i]),
                    float(results["contrast_mean_gain_pct"][i]),
                ]
            )

    raw_path = outdir / f"{pid}_raw_repetitions.csv"
    with raw_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Replication", "Seed", "Mining", "Family", "Base", "Cmax"])
        for rep in range(5):
            for i, fam in enumerate(FAMILIES):
                w.writerow([rep + 1, results["pool_seed"][rep], "Elite-only", fam, int(results["base_cmax"][i]), int(results["elite_cmax"][i, rep])])
                w.writerow([rep + 1, results["pool_seed"][rep], "Contrast", fam, int(results["base_cmax"][i]), int(results["contrast_cmax"][i, rep])])

    json_path = outdir / f"{pid}_results.json"
    json_path.write_text(json.dumps(json_safe(results), indent=2, ensure_ascii=False), encoding="utf-8")
    return outdir


# ============================================================================
# Main experiment
# ============================================================================


def run_pfsp_single(problem_id: str | None = None, cfg: Config | None = None) -> dict:
    root = Path(__file__).resolve().parent
    cfg = cfg or Config()
    cfg.boundary_tie_mode = cfg.boundary_tie_mode.lower()
    if cfg.boundary_tie_mode not in {"numpy_quicksort", "deterministic"}:
        raise ValueError("boundary_tie_mode must be 'numpy_quicksort' or 'deterministic'")

    if problem_id is None or not str(problem_id).strip():
        print("PFSP pure-Python single-instance runner")
        print("Examples: Ta20_5_1, Ta50_20_7, Ta200_20_10, VFR100_60_3")
        problem_id = input("Which problem do you want to solve? Enter ProblemID: ").strip()
    problem_id = str(problem_id).strip()

    row = load_manifest_row(root, problem_id)
    p, meta = load_instance(root, row)
    n, m = p.shape
    seed_rows = load_seed_rows(root, problem_id)
    seeds = [int(r["Seed"]) for r in seed_rows]
    pool_sizes = [int(r["PoolSize"]) for r in seed_rows]
    if len(set(pool_sizes)) != 1:
        raise AssertionError("Pool size differs across repetitions")
    pool_size = pool_sizes[0]
    if pool_size != 10_000 * n:
        raise AssertionError(f"Manifest pool size {pool_size} differs from frozen S=10000*n={10_000*n}")

    regions = 4
    elite_n = round(0.05 * pool_size)
    poor_n = round(0.10 * pool_size)
    top_p = 3 * n
    q_info = 4

    if cfg.verbose:
        print("\n============================================================")
        print(f"Problem: {problem_id}   Group: {row['Group']}   n={n}   m={m}")
        print(f"Pool S={pool_size:,} | Elite={elite_n:,} (5%) | Poor={poor_n:,} (10%) | reps=5")
        print(f"Seeds: {seeds}")
        print(f"NumPy: {np.__version__} | Python: {sys.version.split()[0]}")
        print(f"Boundary tie mode: {cfg.boundary_tie_mode}")
        print("============================================================")

    # 1) Deterministic Base methods
    tpt = tpt_order(p)
    kk = kk2_style_order(p)
    base_seq: list[list[int]] = []
    base_vals: list[int] = []
    for seq, c in (
        construct_neh_base(tpt, p, 0),
        construct_neh_base(tpt, p, 2),
        construct_neh_base(kk, p, 2),
        construct_frb4_base(tpt, p, 1, 2),
        construct_frb4_base(kk, p, 1, 2),
    ):
        validate_solution(seq, c, p, n)
        base_seq.append(seq)
        base_vals.append(c)
    base_cmax = np.asarray(base_vals, dtype=np.int64)

    if cfg.verbose:
        print("\nBase results")
        for fam, c in zip(FAMILIES, base_cmax):
            print(f"  {fam:<18} {int(c)}")

    # 2) Five random-pool repetitions
    nf, nr = len(FAMILIES), 5
    elite_cmax = np.zeros((nf, nr), dtype=np.int64)
    contrast_cmax = np.zeros((nf, nr), dtype=np.int64)
    elite_seq: list[list[list[int] | None]] = [[None] * nr for _ in range(nf)]
    contrast_seq: list[list[list[int] | None]] = [[None] * nr for _ in range(nf)]

    pool_best = np.zeros(nr, dtype=np.int64)
    pool_mean = np.zeros(nr, dtype=float)
    pool_sd = np.zeros(nr, dtype=float)
    pool_worst = np.zeros(nr, dtype=np.int64)
    elite_pool_mean = np.zeros(nr, dtype=float)
    poor_pool_mean = np.zeros(nr, dtype=float)

    tmp_root = Path(cfg.temp_dir) if cfg.temp_dir else root / "tmp_python"
    tmp_root.mkdir(parents=True, exist_ok=True)

    run_start = time.time()
    for rep, seed in enumerate(seeds):
        if cfg.verbose:
            print(f"\nReplication {rep+1}/5, seed={seed}")
        pool_file = tmp_root / f"{problem_id}_rep{rep+1}_pool.uint16"
        if pool_file.exists():
            pool_file.unlink()

        pool = generate_pool_to_memmap(
            seed, pool_size, n, pool_file, cfg.pool_generation_batch, cfg.verbose
        )
        cs = cmax_memmap(pool, p, cfg.pool_read_batch, cfg.verbose)

        pool_best[rep] = cs.min()
        pool_mean[rep] = cs.mean()
        pool_sd[rep] = cs.std(ddof=1)
        pool_worst[rep] = cs.max()

        eidx, bidx = selection_indices(cs, elite_n, poor_n, cfg.boundary_tie_mode)
        elite = np.asarray(pool[eidx, :], dtype=np.uint16)
        poor = np.asarray(pool[bidx, :], dtype=np.uint16)
        elite_pool_mean[rep] = cs[eidx].mean()
        poor_pool_mean[rep] = cs[bidx].mean()

        PE, RE, PC, RC = mine_pr_rules(elite, poor, n, regions, top_p)

        elite_runs = [
            construct_info_neh(tpt, p, PE, RE, 0),
            construct_info_neh(tpt, p, PE, RE, 2),
            construct_info_neh(kk, p, PE, RE, 2),
            construct_info_frb4(tpt, p, PE, RE, 1, q_info, 2),
            construct_info_frb4(kk, p, PE, RE, 1, q_info, 2),
        ]
        contrast_runs = [
            construct_info_neh(tpt, p, PC, RC, 0),
            construct_info_neh(tpt, p, PC, RC, 2),
            construct_info_neh(kk, p, PC, RC, 2),
            construct_info_frb4(tpt, p, PC, RC, 1, q_info, 2),
            construct_info_frb4(kk, p, PC, RC, 1, q_info, 2),
        ]

        for f, (seq, c) in enumerate(elite_runs):
            validate_solution(seq, c, p, n)
            elite_seq[f][rep] = seq
            elite_cmax[f, rep] = c
        for f, (seq, c) in enumerate(contrast_runs):
            validate_solution(seq, c, p, n)
            contrast_seq[f][rep] = seq
            contrast_cmax[f, rep] = c

        if cfg.verbose:
            print(
                f"  Pool best/mean/sd/worst: {int(pool_best[rep])} / "
                f"{pool_mean[rep]:.6f} / {pool_sd[rep]:.6f} / {int(pool_worst[rep])}"
            )
            print("  Elite-only:", elite_cmax[:, rep].tolist())
            print("  Contrast:  ", contrast_cmax[:, rep].tolist())

        # Close memmap before deletion.
        del elite, poor, cs, PE, RE, PC, RC
        del pool
        if not cfg.keep_intermediate and pool_file.exists():
            pool_file.unlink()

    # 3) Summary
    elite_mean = elite_cmax.mean(axis=1)
    elite_best = elite_cmax.min(axis=1)
    contrast_mean = contrast_cmax.mean(axis=1)
    contrast_best = contrast_cmax.min(axis=1)
    elite_gain_pct = 100.0 * (base_cmax - elite_mean) / base_cmax
    contrast_gain_pct = 100.0 * (base_cmax - contrast_mean) / base_cmax

    if cfg.verbose:
        print("\n======================= SUMMARY ===========================")
        print(f"{'Method':<18} {'Base':>8} {'Elite mean':>12} {'Elite best':>12} {'Contr. mean':>12} {'Contr. best':>12}")
        for f, fam in enumerate(FAMILIES):
            print(
                f"{fam:<18} {int(base_cmax[f]):>8} {elite_mean[f]:>12.1f} "
                f"{int(elite_best[f]):>12} {contrast_mean[f]:>12.1f} {int(contrast_best[f]):>12}"
            )
        print("\nMean gain over Base (%)")
        for f, fam in enumerate(FAMILIES):
            print(f"  {fam:<18} Elite={elite_gain_pct[f]:8.4f}%   Contrast={contrast_gain_pct[f]:8.4f}%")

    validation = None
    if cfg.audit_historical:
        validation = validate_historical(
            root,
            problem_id,
            seeds,
            base_cmax,
            elite_cmax,
            contrast_cmax,
            cfg.audit_detail,
        )
        if cfg.verbose:
            if validation["mismatches"] == 0:
                print(f"\nHISTORICAL REFERENCE AUDIT: PASS ({validation['matched']}/{validation['checked']} guided cells matched)")
            else:
                print(
                    f"\nHISTORICAL REFERENCE AUDIT: {validation['mismatches']}/{validation['checked']} mismatches. "
                    "This can occur at equal-Cmax Elite/Poor boundaries when unstable quicksort tie order differs."
                )

    results = {
        "problem_id": problem_id,
        "group": row["Group"],
        "processing_times": p,
        "family": FAMILIES,
        # Store output sequences 1-based for human readability.
        "base_sequence": [[x + 1 for x in seq] for seq in base_seq],
        "base_cmax": base_cmax,
        "elite_sequence": [[[x + 1 for x in seq] for seq in fam] for fam in elite_seq],
        "elite_cmax": elite_cmax,
        "contrast_sequence": [[[x + 1 for x in seq] for seq in fam] for fam in contrast_seq],
        "contrast_cmax": contrast_cmax,
        "elite_mean_cmax": elite_mean,
        "elite_best_cmax": elite_best,
        "contrast_mean_cmax": contrast_mean,
        "contrast_best_cmax": contrast_best,
        "elite_mean_gain_pct": elite_gain_pct,
        "contrast_mean_gain_pct": contrast_gain_pct,
        "pool_seed": seeds,
        "pool_best": pool_best,
        "pool_mean": pool_mean,
        "pool_sd_sample": pool_sd,
        "pool_worst": pool_worst,
        "elite_pool_mean": elite_pool_mean,
        "poor_pool_mean": poor_pool_mean,
        "historical_reference_audit": validation,
        "protocol": {
            "pool_size_rule": "S=10000*n",
            "pool_size": pool_size,
            "elite_fraction": 0.05,
            "poor_fraction": 0.10,
            "repetitions": 5,
            "top_precedence": top_p,
            "position_regions": regions,
            "P_weight": 0.65,
            "R_weight": 0.35,
            "q_extra_reinsertion_jobs": q_info,
            "adjacency_used": False,
            "post_local_search_used": False,
            "rng": "numpy.random.default_rng / PCG64",
            "boundary_tie_policy": cfg.boundary_tie_mode,
        },
        "environment": {
            "python": sys.version,
            "numpy": np.__version__,
            "platform": sys.platform,
        },
        "instance_metadata": meta,
        "elapsed_seconds": time.time() - run_start,
    }

    if cfg.write_outputs:
        outdir = write_outputs(root, cfg, results)
        if cfg.verbose:
            print(f"Result files written to: {outdir}")
    return results


# ============================================================================
# CLI
# ============================================================================


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Run the 140-instance PFSP experiment for one selected benchmark instance."
    )
    p.add_argument("problem_id", nargs="?", help="e.g. Ta20_5_1 or VFR100_60_3")
    p.add_argument(
        "--tie-mode",
        choices=["numpy_quicksort", "deterministic"],
        default="numpy_quicksort",
        help="Elite/Poor boundary tie policy (default: numpy_quicksort)",
    )
    p.add_argument("--no-audit", action="store_true", help="Do not compare with historical_reference.csv")
    p.add_argument("--audit-detail", action="store_true", help="Print every historical-reference mismatch")
    p.add_argument("--keep-pool", action="store_true", help="Keep temporary uint16 pool files")
    p.add_argument("--quiet", action="store_true", help="Reduce console output")
    p.add_argument("--pool-batch", type=int, default=25_000, help="Pool generation batch size")
    p.add_argument("--cmax-batch", type=int, default=50_000, help="Pool Cmax evaluation batch size")
    p.add_argument("--output-dir", default=None, help="Optional output root directory")
    p.add_argument("--temp-dir", default=None, help="Optional temporary pool directory")
    return p


def main() -> int:
    args = build_arg_parser().parse_args()
    cfg = Config(
        verbose=not args.quiet,
        write_outputs=True,
        keep_intermediate=args.keep_pool,
        pool_generation_batch=args.pool_batch,
        pool_read_batch=args.cmax_batch,
        boundary_tie_mode=args.tie_mode,
        audit_historical=not args.no_audit,
        audit_detail=args.audit_detail,
        temp_dir=args.temp_dir,
        output_dir=args.output_dir,
    )
    run_pfsp_single(args.problem_id, cfg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
