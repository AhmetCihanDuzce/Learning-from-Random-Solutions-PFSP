#!/usr/bin/env python3
from __future__ import annotations
import csv
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent


def read_rows(name):
    with (ROOT / name).open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def main():
    required = [
        "run_pfsp_single.py",
        "instance_manifest.csv",
        "seed_manifest.csv",
        "historical_reference.csv",
        "data/taillard/tai20_5.txt",
        "data/vfr/VFR100_60_10_Gap.txt",
    ]
    for rel in required:
        assert (ROOT / rel).is_file(), f"Missing required file: {rel}"

    inst = read_rows("instance_manifest.csv")
    seeds = read_rows("seed_manifest.csv")
    ref = read_rows("historical_reference.csv")
    assert len(inst) == 140, f"Expected 140 instances, found {len(inst)}"
    assert len(seeds) == 700, f"Expected 700 seed rows, found {len(seeds)}"
    assert len(ref) == 7000, f"Expected 7000 historical result rows, found {len(ref)}"

    for r in inst:
        ss = [x for x in seeds if x["ProblemID"] == r["ProblemID"]]
        assert len(ss) == 5, f"{r['ProblemID']} does not have five seed rows"
        assert all(int(x["PoolSize"]) == 10_000 * int(r["n"]) for x in ss), r["ProblemID"]

    print("PACKAGE INTEGRITY CHECK: PASS")
    print(f"  Python: {__import__('sys').version.split()[0]}")
    print(f"  NumPy:  {np.__version__}")
    print(f"  Instances: {len(inst)}")
    print(f"  Seed rows: {len(seeds)}")
    print(f"  Historical-reference rows: {len(ref)}")


if __name__ == "__main__":
    main()
