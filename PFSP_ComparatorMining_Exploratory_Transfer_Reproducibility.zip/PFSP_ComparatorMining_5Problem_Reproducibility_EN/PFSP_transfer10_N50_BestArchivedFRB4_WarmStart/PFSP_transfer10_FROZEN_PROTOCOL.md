# PFSP transfer experiment 10 — n=50 best-archived FRB4-Contrast warm-start QIG

Status: EXPLORATORY TRAIN/VALIDATE PILOT. Frozen before execution.

## Motivation
transfer experiment 09 showed that a fixed replication-1 FRB4-p1 Contrast warm start clearly improved QIG on Ta50_20_1 but was essentially neutral on Ta50_10_1. Because the study already contains multiple independent mining replications, this analysis phase tests whether an offline archive can select a stronger reusable mined schedule before future QIG runs.

## Offline archive rule
For each n=50 target separately, inspect only the already-completed external-comparator analysis replications 1..10 and select the lowest-Cmax schedule among `FRB4-p1 | Contrast` outputs. No QIG result is used in this selection and no method-family portfolio is formed.

Selected archive sources are therefore determined entirely from historical mined FRB4-p1 Contrast outputs.

## Targets
- Ta50_10_1
- Ta50_20_1

## Independent validation seeds
Use fresh r=21..25 with seed extension `820260000 + 100*problem_ordinal + r`. These seeds are not used in external-comparator analysis or earlier analysis phase-9 experiments.

## Search budget
Standard QIG and warm-start QIG receive exactly the same online wall-clock budget: the median original external-comparator analysis comparator budget over replications 1..10 for that problem.

Mining and archive construction are explicitly offline reusable work and are reported separately; this pilot tests whether mined knowledge can improve the comparator once available.

## Mechanism
Warm-start QIG differs from standard QIG only in the initial permutation. Q-learning, destruction-size adaptation, acceptance, local search, temperature and all remaining search logic are unchanged.

## Primary descriptive endpoint
Mean paired Delta RPD = warm-start QIG minus standard QIG. Negative is favorable. Also report W/T/L, median Delta RPD, mean RPD and batch-best Cmax. Five pairs per target; no confirmatory significance claim.
