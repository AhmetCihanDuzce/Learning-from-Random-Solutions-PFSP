# transfer experiment 10 Report — n=50 best-archived FRB4-p1 Contrast warm-start QIG

## Status
Exploratory train/validate pilot completed. QA GREEN.

## Rationale
Earlier equal-online soft Contrast-P guidance showed favorable development signals on both n=50 targets, but direct soft-bias guidance did not remain favorable under later strict reusable-budget validation. transfer experiment 10 therefore changed the interface rather than the QIG core: mined knowledge is used only to provide a reusable initial permutation. QIG's Q-learning, destruction-size adaptation, acceptance, local search, and all other search logic remain unchanged.

## Offline archive selection
For each target, the best Cmax among the ten already-completed external-comparator analysis `FRB4-p1 | Contrast` schedules was selected before the new validation seeds were run.

- Ta50_10_1: source replication 4, warm-start Cmax = 3090.
- Ta50_20_1: source replication 7, warm-start Cmax = 4003.

No QIG result was used in this archive selection and no multi-family portfolio was formed.

## Independent validation
Fresh seeds r=21..25 were used. Standard QIG and warm-start QIG received exactly the same online wall-clock budget, defined as the median original external-comparator analysis comparator budget over replications 1..10.

| Problem | Online budget (s) | Mean Delta RPD (pp) | W/T/L | Warm-start QIG mean RPD | Standard QIG mean RPD | Warm-start best | Standard best |
|---|---:|---:|---:|---:|---:|---:|---:|
| Ta50_10_1 | 2.3882 | -0.05349 | 1/3/1 | 1.16349 | 1.21698 | 3025 | 3025 |
| Ta50_20_1 | 4.3578 | -0.07792 | 2/3/0 | 1.05455 | 1.13247 | 3881 | 3893 |

Negative Delta RPD favors the mining-informed warm-start QIG.

## Interpretation
The n=50 results now show a favorable mean effect on both selected hard comparator instances under equal online search time. The effect is modest for Ta50_10_1 and clearer for Ta50_20_1. This supports the limited claim that previously mined Contrast information can improve a strong comparator when injected through a problem-appropriate interface (here, a reusable mined FRB4-p1 warm start), rather than the stronger claim that one universal guidance parameterization improves QIG at every scale.

This is an auxiliary exploratory demonstration, not a new universal algorithm. Mining/archive construction is offline reusable work and must be reported separately in the computational-cost discussion; transfer experiment 10 is not a strict fresh-mining end-to-end superiority test.
