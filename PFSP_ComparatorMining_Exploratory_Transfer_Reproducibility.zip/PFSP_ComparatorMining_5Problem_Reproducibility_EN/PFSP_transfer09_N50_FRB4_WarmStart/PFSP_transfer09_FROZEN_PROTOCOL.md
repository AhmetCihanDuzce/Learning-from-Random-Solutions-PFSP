# PFSP transfer experiment 09 — n=50 mining-guided FRB4 warm-start for QIG

Status: EXPLORATORY TARGETED PILOT. Frozen before execution.

## Motivation
The paper studies whether mined Elite/Contrast structure can improve constructive NEH-family methods. For the n=50 comparator cases, direct soft-bias guidance did not replicate under strict reusable equal-budget accounting. This pilot tests a different, minimally invasive interface: use one previously mined FRB4-p1 Contrast schedule as the initial solution of QIG, while leaving QIG's learning, destruction-size control, acceptance, local search, and all remaining search logic unchanged.

## Targets
- Ta50_10_1
- Ta50_20_1

## Warm start
For each problem, use the archived external-comparator analysis replication-1 `FRB4-p1 | Contrast` permutation as a fixed reusable warm start. The warm start is fixed before the new QIG seeds are generated. No best-of-10 guided portfolio is used.

## Independent validation seeds
r = 16..20 using the external-comparator analysis seed rule extension:
`seed = 820260000 + 100*problem_ordinal + r`.
These seeds were not used in earlier external-comparator analysis or analysis phase-9 runs.

## Budget
Same online wall-clock budget for standard QIG and warm-start QIG.
Per problem, use the median original external-comparator analysis comparator budget over replications 1..10.
The mining/warm-start schedule is treated as offline reusable knowledge; its computational cost is reported separately and is not hidden in the main paper's runtime accounting.

## Primary comparison
Paired standard QIG vs QIG initialized from FRB4-p1 Contrast, same seed and same online time.
Report mean/median Delta RPD (warm-start minus standard), W/T/L, mean RPD and batch-best Cmax.
No confirmatory significance claim from five pairs.
