from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys,json,csv,time,math,zipfile
from pathlib import Path
import numpy as np
S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot'); sys.path.insert(0,str(S1)); import transfer01_runner as r
from external_comparator_comparators import cmax_numba,best_insert_ff,insert_at,validate_permutation
from run_pfsp_single import pfsp_cmax
HERE=Path(__file__).resolve().parent
ZPATH=(Path(__file__).resolve().parent.parent/'PFSP_external_comparator_FINAL_280of280_GREEN.zip')
PROBLEMS=['Ta50_10_1','Ta50_20_1']; REPS=range(16,21)

def seed_ext(pid,rep):
    _,ordn=r.seed_for(pid,1); return 820260000+100*ordn+rep,ordn

def load_problem(pid):
    row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); return p,r.ub_for(pid)

def external_comparator_payload(pid,rep):
    with zipfile.ZipFile(ZPATH) as z:
        name=[n for n in z.namelist() if '/native_runs/' in n and f'_{pid}_r{rep:02d}.json' in n]
        assert len(name)==1
        return json.loads(z.read(name[0]))

def warm_start(pid):
    d=external_comparator_payload(pid,1)
    a=[x for x in d['framework']['variants'] if x['family']=='FRB4-p1' and x['mining']=='Contrast']
    assert len(a)==1
    return np.asarray(a[0]['seq'],dtype=np.int64),int(a[0]['cmax']),float(d['framework']['offline_sec']),float(a[0]['guided_sec'])

def fixed_budget(pid):
    vals=[float(external_comparator_payload(pid,rep)['framework']['budget_sec']) for rep in range(1,11)]
    return float(np.median(vals))

def qig_from_start(p,seed,time_limit_sec,start_seq,tau=.7,epsilon=.8,beta=.996,alpha=.6,gamma=.8,E=6,eta=.3,max_ls_passes=100):
    n,m=p.shape; rng=np.random.default_rng(seed); start=time.perf_counter(); deadline=start+float(time_limit_sec)
    seq=np.asarray(start_seq,dtype=np.int64).copy(); best_seq=seq.copy(); best_c=int(cmax_numba(seq,p))
    seq,curr_c,init_passes,_=r.insertion_local_search_deadline(seq,p,rng,deadline,max_ls_passes)
    if curr_c<best_c: best_c=int(curr_c); best_seq=seq.copy()
    Q=np.zeros((2,3),dtype=float); state=0; d=int(rng.integers(1,4)); temp=float(tau)*float(p.sum())/float(n*m*10.0)
    episodes=iterations=accepts=0; eps=float(epsilon)
    while time.perf_counter()<deadline:
        Cprev=int(curr_c); Cbest_prev=int(best_c); C_ep=int(curr_c); used_d=d
        for _ in range(E):
            if time.perf_counter()>=deadline: break
            iterations+=1; idxs=rng.choice(seq.size,size=d,replace=False); removed=seq[idxs].copy(); mask=np.ones(seq.size,bool); mask[idxs]=False; partial=seq[mask].copy()
            partial,_,_,_=r.insertion_local_search_deadline(partial,p,rng,deadline,max_ls_passes)
            if time.perf_counter()>=deadline: break
            cand=partial
            for job in removed:
                if time.perf_counter()>=deadline: break
                pos,_,_,_=best_insert_ff(cand,int(job),p); cand=insert_at(cand,int(job),pos)
            if cand.size!=n or time.perf_counter()>=deadline: break
            cand,cand_c,_,_=r.insertion_local_search_deadline(cand,p,rng,deadline,max_ls_passes)
            accept=cand_c<=curr_c
            if not accept and temp>0: accept=rng.random()<math.exp((float(curr_c)-float(cand_c))/temp)
            if accept:
                seq=cand; curr_c=int(cand_c); accepts+=1
                if curr_c<C_ep: C_ep=curr_c
            if cand_c<best_c: best_c=int(cand_c); best_seq=cand.copy()
            if time.perf_counter()>=deadline: break
        rlocal=max(Cprev-C_ep,0)/float(Cprev); rglobal=max(Cbest_prev-best_c,0)/float(Cbest_prev); reward=eta*rlocal+(1-eta)*rglobal; ns=1 if best_c<Cbest_prev else 0
        Q[state,used_d-1]+=alpha*(reward+gamma*float(np.max(Q[ns]))-Q[state,used_d-1]); eps*=beta; d=(int(np.argmax(Q[ns]))+1) if rng.random()>=eps else int(rng.integers(1,4)); state=ns; episodes+=1
    return {'cmax':int(best_c),'seq':best_seq,'elapsed_sec':time.perf_counter()-start,'episodes':episodes,'iterations':iterations,'accepts':accepts,'init_ls_passes':init_passes}

def qa(x,p,n): return bool(validate_permutation(x['seq'],n) and int(pfsp_cmax(x['seq'],p))==int(x['cmax']))

def main():
    r.warmup(); rows=[]
    for pid in PROBLEMS:
        p,ub=load_problem(pid); n=p.shape[0]; wseq,wc,off,wsec=warm_start(pid); B=fixed_budget(pid)
        assert int(pfsp_cmax(wseq,p))==wc
        for rep in REPS:
            fn=HERE/'raw'/f'{pid}_r{rep:02d}.json'
            if fn.exists(): rows.append(json.loads(fn.read_text())); continue
            seed,ordn=seed_ext(pid,rep)
            b=r.qig_deadline(p,seed,B); g=qig_from_start(p,seed,B,wseq)
            okb=qa(b,p,n); okg=qa(g,p,n)
            d={'status':'GREEN' if okb and okg else 'RED','problem':pid,'rep':rep,'seed':seed,'budget_sec':B,'offline_source_sec':off,'warmstart_original_guided_sec':wsec,'warmstart_cmax':wc,'baseline_cmax':b['cmax'],'guided_cmax':g['cmax'],'baseline_rpd':100*(b['cmax']-ub)/ub,'guided_rpd':100*(g['cmax']-ub)/ub,'delta_rpd':100*(g['cmax']-b['cmax'])/ub,'baseline_elapsed_sec':b['elapsed_sec'],'guided_elapsed_sec':g['elapsed_sec'],'qa_baseline':okb,'qa_guided':okg}; fn.write_text(json.dumps(d,indent=2)); rows.append(d)
    out=[]
    for pid in PROBLEMS:
        z=[x for x in rows if x['problem']==pid]; ds=np.asarray([x['delta_rpd'] for x in z]); w=sum(x['guided_cmax']<x['baseline_cmax'] for x in z); t=sum(x['guided_cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        out.append({'problem':pid,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,'mean_guided_rpd':float(np.mean([x['guided_rpd'] for x in z])),'mean_baseline_rpd':float(np.mean([x['baseline_rpd'] for x in z])),'guided_batch_best_cmax':min(x['guided_cmax'] for x in z),'baseline_batch_best_cmax':min(x['baseline_cmax'] for x in z),'all_green':all(x['status']=='GREEN' for x in z)})
    with open(HERE/'transfer09_summary.csv','w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(out[0])); wr.writeheader(); wr.writerows(out)
    print(json.dumps(out,indent=2))
if __name__=='__main__': main()
