# Run order

## A. Selected-interface reproduction

Create a clean copy first:

```bash
python make_clean_selected_rerun.py --dest ./rerun_selected
cd rerun_selected
```

Run:

```bash
# QIG, n=50: mined FRB4-p1 Contrast warm start
python PFSP_transfer10_N50_BestArchivedFRB4_WarmStart/transfer10_runner.py

# QIG, reusable Contrast-P soft bias, H=10 accounting
# The final selected rows are Ta100_20_1, Ta100_20_10, VFR100_40_10.
python PFSP_transfer05_QIG_Reusable_H10_All5/transfer05_runner.py

# Q-NEH, optimized Contrast-P near-tie, H=10 accounting
# The final selected rows are Ta100_20_1 and VFR100_40_10.
python PFSP_transfer12_QNEH_OptimizedNearTie/transfer12_runner.py

# Q-NEH, n=50 Contrast-P order prior; includes equal-online validation and strict H=10 audit
python PFSP_transfer14_QNEH_N50_POrderPrior/transfer14_runner.py

# Q-NEH, Ta100_20_10 combined order prior + near-tie; includes equal-online and strict H=10
python PFSP_transfer16_QNEH_N100_CombinedPriorNearTie/transfer16_runner.py
```

## B. Complete exploratory lineage

The scientific lineage is transfer experiment 01 -> 9B.16. To reproduce every exploratory branch, execute the corresponding analysis phase runners sequentially after removing archived outputs from a working copy. The frozen protocol in each analysis phase folder states the exact decision rule, development/validation split, promotion gate, and budget accounting.

The main analysis phase runner files are:

1. `PFSP_transfer01_PR_Comparator_Pilot/transfer01_runner.py`
2. `PFSP_transfer02_QIG_ContrastP_SoftBias/transfer02_runner.py`
3. `PFSP_transfer03_CheapMining/transfer03_runner.py`
4. `PFSP_transfer04_ReusableMining/transfer04_runner.py`
5. `PFSP_transfer05_QIG_Reusable_H10_All5/transfer05_runner.py`
6. `PFSP_transfer06_N50_EarlyGuidance/transfer06_runner.py`
7. `PFSP_transfer07_N50_OptimizedContrastP/transfer07_runner.py`
8. `PFSP_transfer08_N50_Specific_Tuning/transfer08_runner.py`
9. `PFSP_transfer09_N50_FRB4_WarmStart/transfer09_runner.py`
10. `PFSP_transfer10_N50_BestArchivedFRB4_WarmStart/transfer10_runner.py`
11. `PFSP_transfer11_QNEH_NearTie/transfer11_runner.py`
12. `PFSP_transfer12_QNEH_OptimizedNearTie/transfer12_runner.py`
13. `PFSP_transfer13_QNEH_N50_DemoPrior/transfer13_runner.py`
14. `PFSP_transfer14_QNEH_N50_POrderPrior/transfer14_runner.py`
15. `PFSP_transfer15_QNEH_N100_POrderPrior/transfer15_runner.py`
16. `PFSP_transfer16_QNEH_N100_CombinedPriorNearTie/transfer16_runner.py`

Helper scripts in some analysis phase folders are part of the archived execution history and are retained for completeness.
