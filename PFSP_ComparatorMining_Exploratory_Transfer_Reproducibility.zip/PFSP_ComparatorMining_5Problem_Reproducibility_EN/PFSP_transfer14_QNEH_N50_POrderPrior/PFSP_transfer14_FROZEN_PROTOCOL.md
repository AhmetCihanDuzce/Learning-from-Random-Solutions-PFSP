# PFSP transfer experiment 14 — n=50 Contrast-P order prior for Q-NEH

Status: FROZEN BEFORE EXECUTION.
Nature: targeted exploratory n=50 comparator-integration study.

## Objective
Test a Q-NEH-specific, low-overhead interface for mined precedence information on Ta50_10_1 and Ta50_20_1. Unlike transfer experiment 13, the prior is derived directly from the mined Contrast-P matrix rather than from a mined heuristic solution.

## Fixed mined source
For each target use the already archived transfer experiment 02 S=10,000n Contrast-P matrix from source replication 1. The source is fixed by replication number and is not screened using Q-NEH performance.

## P-order demonstration prior
For a Contrast-P matrix P, compute each job's net precedence strength as the row sum of P. Sort jobs by descending net strength (stable smaller job index for exact ties) to obtain a deterministic mined action order.

Starting from Q=0, replay this action order through the original Q-NEH best-insertion, reward, and Q-update equations for D teacher passes. The resulting Q table is stored and reused as the initial Q table of online Q-NEH. During online search, epsilon-greedy selection, reward, insertion, alpha=0.5, gamma=0.8 and all remaining Q-NEH logic are unchanged. No P score is evaluated online.

## Development
Targets: Ta50_10_1 and Ta50_20_1.
Teacher passes D in {1,3,5}.
Fresh seed extensions 41..43.
Standard and prior-seeded Q-NEH receive the same online wall-clock budget, equal to the median original external-comparator analysis comparator budget for that target.
One common D is selected across the two n=50 targets by lowest mean paired Delta RPD; ties -> more wins -> smaller D.

## Independent validation
Fresh seed extensions 46..50, five pairs per target. The selected D is frozen before validation. Same equal-online budget.

## Strict reusable-cost audit
If both validation targets have favorable mean Delta RPD, perform H=10 equal-total-budget validation on fresh extensions 51..55. Baseline receives total budget B. Guided receives B - (source mining time + one prior-construction time)/10 online seconds. Thus the reusable mining/preparation cost is charged to the guided method.

## Outcomes
Report mean/median paired Delta RPD, W/T/L, mean RPD, batch-best Cmax, episodes, mining/preparation cost, and permutation/Cmax QA. Negative Delta RPD favors mining-informed Q-NEH. All results are retained.
