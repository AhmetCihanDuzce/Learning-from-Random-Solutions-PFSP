# transfer experiment 14 Report — n=50 Contrast-P order prior Q-NEH

QA: GREEN

Selected D=1.

## Equal-online validation
- Ta50_10_1: mean ΔRPD=-0.113674, W/T/L=3/0/2, best 3075 vs 3083.
- Ta50_20_1: mean ΔRPD=-0.041558, W/T/L=2/1/2, best 3987 vs 3989.

## Strict H=10 audit
- Ta50_10_1: mean ΔRPD=-0.060181, W/T/L=3/0/2, best 3072 vs 3071.
- Ta50_20_1: mean ΔRPD=0.270130, W/T/L=1/0/4, best 3992 vs 3974.
