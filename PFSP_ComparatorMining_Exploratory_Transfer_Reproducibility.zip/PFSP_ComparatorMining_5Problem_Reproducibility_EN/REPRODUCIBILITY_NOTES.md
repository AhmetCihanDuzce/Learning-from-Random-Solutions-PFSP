# Reproducibility notes

## Why the five-problem experiment is exploratory

The five instances were selected as difficult comparator cases after the primary 28-problem external-comparator panel. The follow-up asks whether the mined structural information can transfer into the stronger comparator architectures; it is not a replacement for the primary 28-problem benchmark comparison.

## Interface selection

The final selected interfaces are architecture- and scale-specific:

- QIG, n=50: best archived `FRB4-p1 | Contrast` schedule used only as a reusable warm start.
- QIG, larger instances: reusable Contrast-P soft destruction bias, `lambda=0.25`, `H=10`.
- Q-NEH, n=50: Contrast-P order prior, `D=1`.
- Q-NEH, Ta100_20_1 and VFR100_40_10: optimized Contrast-P near-tie guidance, `theta=0.05`.
- Q-NEH, Ta100_20_10: combined order prior `D=3` + near-tie guidance `theta=0.05`.

The full transfer experiment 01-9B.16 lineage is retained so that unsuccessful mechanisms and tuning instability are visible.

## Budget-label provenance note

The frozen transfer synthesis selected-interface table is retained unchanged under `transfer_synthesis_Synthesis/`. One row requires a reporting-label clarification: the Q-NEH value `-0.0808206403` for `Ta100_20_10` is the **equal-online** transfer experiment 16 result; the strict H=10 result is `-0.0155424308`. The Supplementary Material package therefore includes both the original transfer synthesis table for provenance and a source-semantics-corrected selected-interface table. No numerical result is altered.

## Exact-output caveat

The search algorithms are wall-clock stopped. On different hardware, a fixed seed does not guarantee identical Cmax because the number of completed episodes may differ. Archived outputs are therefore included as the manuscript reference results.
