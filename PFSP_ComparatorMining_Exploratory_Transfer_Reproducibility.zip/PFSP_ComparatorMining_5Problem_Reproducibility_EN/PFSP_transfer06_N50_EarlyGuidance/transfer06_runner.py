from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1'); os.environ.setdefault('MKL_NUM_THREADS','1'); os.environ.setdefault('NUMBA_NUM_THREADS','1')
import sys, json, csv, time, math, hashlib
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
S2=(Path(__file__).resolve().parent.parent/'PFSP_transfer02_QIG_ContrastP_SoftBias')
S1=(Path(__file__).resolve().parent.parent/'PFSP_transfer01_PR_Comparator_Pilot')
sys.path.insert(0,str(S2)); sys.path.insert(0,str(S1))
import transfer02_runner as s2
r=s2.r
from external_comparator_comparators import cmax_numba, best_insert_ff, insert_at, neh_ff, validate_permutation
from run_pfsp_single import pfsp_cmax

PROBLEMS=['Ta50_10_1','Ta50_20_1']
DEV_REPS=range(1,4); VAL_REPS=range(6,11)
FRACS=[0.25,0.50,0.75]; LAM=0.25; H=10
(HERE/'raw_dev').mkdir(exist_ok=True); (HERE/'raw_val').mkdir(exist_ok=True)

def qa(res,p,n):
    return bool(validate_permutation(res['seq'],n) and int(pfsp_cmax(res['seq'],p))==int(res['cmax']))

def source(pid):
    f=S2/'cache'/f'{pid}_r01_PC.npz'
    if not f.exists(): raise FileNotFoundError(f)
    z=np.load(f,allow_pickle=False)
    return z['PC'],float(z['offline_sec']),json.loads(str(z['stats_json']))

def p_violation(seq,P):
    seq=np.asarray(seq,dtype=np.int64); n=P.shape[0]
    pos=np.empty(n,dtype=np.int64); pos[seq]=np.arange(seq.size,dtype=np.int64)
    v=np.zeros(n,dtype=float)
    ii,jj=np.where(P>0)
    for i,j in zip(ii.tolist(),jj.tolist()):
        if pos[i]>pos[j]:
            w=float(P[i,j]); v[i]+=w; v[j]+=w
    return v

def qig_early_p(p,seed,time_limit_sec,P,lam,early_frac,tau=.7,epsilon=.8,beta=.996,alpha=.6,gamma=.8,E=6,eta=.3,max_ls_passes=100):
    n,m=p.shape; rng=np.random.default_rng(seed); start=time.perf_counter(); deadline=start+float(time_limit_sec); guide_deadline=start+float(time_limit_sec)*float(early_frac)
    seq,_=neh_ff(p); best_seq=seq.copy(); best_c=int(cmax_numba(seq,p))
    seq,curr_c,init_passes,_=r.insertion_local_search_deadline(seq,p,rng,deadline,max_ls_passes)
    if curr_c<best_c: best_c=int(curr_c); best_seq=seq.copy()
    Q=np.zeros((2,3),dtype=float); state=0; d=int(rng.integers(1,4)); temp=float(tau)*float(p.sum())/float(n*m*10.0)
    episodes=iterations=accepts=0; eps=float(epsilon); guided_destructions=0; total_destructions=0
    while time.perf_counter()<deadline:
        Cprev=int(curr_c); Cbest_prev=int(best_c); C_ep=int(curr_c); used_d=d
        for _ in range(E):
            now=time.perf_counter()
            if now>=deadline: break
            iterations+=1; total_destructions+=1
            active = now < guide_deadline
            if active:
                v=p_violation(seq,P); sv=float(v.sum())
                if sv>0:
                    probs=(1.0-float(lam))/float(n) + float(lam)*(v[seq]/sv)
                    probs=probs/float(probs.sum())
                    idxs=rng.choice(seq.size,size=d,replace=False,p=probs); guided_destructions+=1
                else:
                    idxs=rng.choice(seq.size,size=d,replace=False)
            else:
                idxs=rng.choice(seq.size,size=d,replace=False)
            removed=seq[idxs].copy(); keepmask=np.ones(seq.size,dtype=bool); keepmask[idxs]=False
            partial=seq[keepmask].copy(); partial,_,_,_=r.insertion_local_search_deadline(partial,p,rng,deadline,max_ls_passes)
            if time.perf_counter()>=deadline: break
            cand=partial
            for job in removed:
                if time.perf_counter()>=deadline: break
                pos,_,_,_=best_insert_ff(cand,int(job),p); cand=insert_at(cand,int(job),pos)
            if cand.size!=n or time.perf_counter()>=deadline: break
            cand,cand_c,_,_=r.insertion_local_search_deadline(cand,p,rng,deadline,max_ls_passes)
            accept=cand_c<=curr_c
            if not accept and temp>0: accept=rng.random()<math.exp((float(curr_c)-float(cand_c))/temp)
            if accept:
                seq=cand; curr_c=int(cand_c); accepts+=1
                if curr_c<C_ep: C_ep=curr_c
            if cand_c<best_c: best_c=int(cand_c); best_seq=cand.copy()
            if time.perf_counter()>=deadline: break
        rlocal=max(Cprev-C_ep,0)/float(Cprev); rglobal=max(Cbest_prev-best_c,0)/float(Cbest_prev)
        reward=eta*rlocal+(1-eta)*rglobal; improved=best_c<Cbest_prev; new_state=1 if improved else 0
        Q[state,used_d-1]+=alpha*(reward+gamma*float(np.max(Q[new_state]))-Q[state,used_d-1])
        eps*=beta; d=(int(np.argmax(Q[new_state]))+1) if rng.random()>=eps else int(rng.integers(1,4)); state=new_state; episodes+=1
    elapsed=time.perf_counter()-start
    return {'algorithm':'QIG+ContrastP-early','seed':seed,'cmax':int(best_c),'seq':best_seq,'elapsed_sec':elapsed,'episodes':episodes,'iterations':iterations,'accepts':accepts,'guided_destructions':guided_destructions,'total_destructions':total_destructions,'guided_fraction':guided_destructions/max(1,total_destructions),'init_ls_passes':init_passes,'lambda':float(lam),'early_frac':float(early_frac)}

def run_pair(pid,rep,frac,phase):
    outdir=HERE/('raw_dev' if phase=='dev' else 'raw_val'); tag=f'F{int(frac*100):02d}'
    fn=outdir/f'{pid}_r{rep:02d}_{tag}.json'
    if fn.exists(): return json.loads(fn.read_text())
    row=r.load_manifest_row(r.PFSP_ROOT,pid); p,_=r.load_instance(r.PFSP_ROOT,row); n=p.shape[0]
    seed,ordn=r.seed_for(pid,rep); ub=r.ub_for(pid); g8,_,_=r.external_comparator_max_guided(pid,rep); P,off,stats=source(pid); share=off/H; B=g8+share
    print('GUIDED',phase,pid,rep,tag,'g8',g8,flush=True)
    gr=qig_early_p(p,seed,g8,P,LAM,frac); okg=qa(gr,p,n)
    print('BASE',phase,pid,rep,'B',B,flush=True)
    br=r.qig_deadline(p,seed,B); okb=qa(br,p,n)
    d={'status':'GREEN' if okg and okb else 'RED','phase':phase,'problem':pid,'ordinal':ordn,'rep':rep,'seed':seed,'reference_ub':ub,'g8_sec':g8,'source_offline_sec':off,'reuse_horizon':H,'allocated_mining_sec':share,'equal_budget_baseline_sec':B,'lambda':LAM,'early_frac':frac,'variant':tag,'guided_cmax':int(gr['cmax']),'baseline_cmax':int(br['cmax']),'guided_rpd':100*(gr['cmax']-ub)/ub,'baseline_rpd':100*(br['cmax']-ub)/ub,'delta_rpd':100*(gr['cmax']-br['cmax'])/ub,'guided_elapsed_sec':float(gr['elapsed_sec']),'baseline_elapsed_sec':float(br['elapsed_sec']),'guided_fraction':float(gr['guided_fraction']),'guided_destructions':int(gr['guided_destructions']),'total_destructions':int(gr['total_destructions']),'qa_guided':okg,'qa_baseline':okb,'source_stats':stats}
    fn.write_text(json.dumps(d,indent=2),encoding='utf-8'); return d

def summarize(rows,phase):
    out=[]
    fracs=sorted(set(x['early_frac'] for x in rows))
    for frac in fracs:
        z=[x for x in rows if x['early_frac']==frac]; ds=np.array([x['delta_rpd'] for x in z],float)
        w=sum(x['guided_cmax']<x['baseline_cmax'] for x in z); t=sum(x['guided_cmax']==x['baseline_cmax'] for x in z); l=len(z)-w-t
        out.append({'scope':'ALL','early_frac':frac,'n_pairs':len(z),'mean_delta_rpd':float(ds.mean()),'median_delta_rpd':float(np.median(ds)),'wins':w,'ties':t,'losses':l,'mean_guided_fraction':float(np.mean([x['guided_fraction'] for x in z])),'all_green':all(x['status']=='GREEN' for x in z)})
        for pid in PROBLEMS:
            q=[x for x in z if x['problem']==pid]; dd=np.array([x['delta_rpd'] for x in q],float); ww=sum(x['guided_cmax']<x['baseline_cmax'] for x in q); tt=sum(x['guided_cmax']==x['baseline_cmax'] for x in q); ll=len(q)-ww-tt
            out.append({'scope':pid,'early_frac':frac,'n_pairs':len(q),'mean_delta_rpd':float(dd.mean()),'median_delta_rpd':float(np.median(dd)),'wins':ww,'ties':tt,'losses':ll,'mean_guided_fraction':float(np.mean([x['guided_fraction'] for x in q])),'all_green':all(x['status']=='GREEN' for x in q)})
    with open(HERE/f'transfer06_{phase}_summary.csv','w',newline='',encoding='utf-8') as f:
        wri=csv.DictWriter(f,fieldnames=list(out[0].keys())); wri.writeheader(); wri.writerows(out)
    return out

def main():
    r.warmup(); dev=[]
    for frac in FRACS:
        for pid in PROBLEMS:
            for rep in DEV_REPS: dev.append(run_pair(pid,rep,frac,'dev'))
    sm=summarize(dev,'development')
    allrows=[x for x in sm if x['scope']=='ALL']
    allrows.sort(key=lambda x:(x['mean_delta_rpd'],-x['wins'],x['early_frac']))
    chosen=float(allrows[0]['early_frac'])
    sel={'selection_rule':'minimum pooled mean delta RPD; then more wins; then smaller early fraction','chosen_early_frac':chosen,'ranked':allrows}
    (HERE/'transfer06_selection.json').write_text(json.dumps(sel,indent=2),encoding='utf-8')
    print('CHOSEN',chosen,flush=True)
    val=[]
    for pid in PROBLEMS:
        for rep in VAL_REPS: val.append(run_pair(pid,rep,chosen,'val'))
    vsm=summarize(val,'validation')
    qaobj={'status':'GREEN' if all(x['status']=='GREEN' for x in dev+val) else 'RED','protocol_frozen_before_execution':True,'n_dev_pairs':len(dev),'n_validation_pairs':len(val),'chosen_early_frac':chosen,'mechanism':'QIG+Contrast-P early-only, lambda=0.25, H=10 reusable mining','problems':PROBLEMS}
    (HERE/'transfer06_MASTER_QA.json').write_text(json.dumps(qaobj,indent=2),encoding='utf-8')
    print('VALIDATION',json.dumps(vsm,indent=2),flush=True); print('QA',json.dumps(qaobj,indent=2),flush=True)

if __name__=='__main__': main()
