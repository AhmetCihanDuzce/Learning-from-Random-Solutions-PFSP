# transfer experiment 06 Report — n=50 Early-Guidance QIG

QA: GREEN.

Development grid (reps 1–3, both n=50 problems) selected F50 by the frozen rule. All three fractions looked favorable in development, but the promoted F50 did not replicate on reps 6–10.

Validation:
- Ta50_10_1: mean Delta RPD +0.066867; W/T/L 1/2/2.
- Ta50_20_1: mean Delta RPD +0.280519; W/T/L 0/0/5.
- Pooled descriptive: +0.173693; W/T/L 1/2/7.

Conclusion: early-only P guidance does not repair the equal-budget n=50 failures; the development signal was not stable out of sample.
