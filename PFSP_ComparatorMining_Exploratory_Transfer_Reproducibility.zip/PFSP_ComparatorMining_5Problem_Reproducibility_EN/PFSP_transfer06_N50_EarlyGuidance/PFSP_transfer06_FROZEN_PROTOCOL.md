# PFSP transfer experiment 06 — n=50 Early-Guidance QIG Pilot

Status: **FROZEN BEFORE EXECUTION**.
Nature: targeted exploratory repair of the two n=50 cases where the previously frozen reusable Contrast-P QIG (H=10, always-active, lambda=0.25) did not beat equal-budget QIG.

## Objective
Test whether using the same mined Contrast-P information only during the early part of QIG search preserves the initial guidance benefit while avoiding later interference and repeated P-scoring overhead on short n=50 runs.

## Problems
- Ta50_10_1
- Ta50_20_1

No other problem is used for tuning.

## Fixed mechanism
- Comparator: QIG.
- Contrast-P only; no R information.
- Same archived S=10,000n Contrast-P matrix from transfer experiment 02 replication 1 for each problem.
- Reuse horizon H=10.
- Soft destruction bias lambda=0.25.
- QIG state/action definition, destruction size, reconstruction, insertion local search, acceptance, reward, epsilon schedule, and all other logic unchanged.
- Only change relative to transfer experiment 05: the P-bias is active only during an initial fraction of the online QIG time, then QIG continues unguided.

## Frozen development grid
Three early-guidance fractions are tested:
- F25: first 25% of online time
- F50: first 50% of online time
- F75: first 75% of online time

Development replications: external-comparator analysis replications 1–3 on both problems (6 paired problem-replication units per variant).

Selection rule, fixed before results:
1. smallest pooled mean paired Delta RPD (guided minus equal-budget QIG; negative is better),
2. then more wins,
3. then smaller guidance fraction.
Exactly one fraction is promoted.

## Equal-budget accounting
For each problem and replication:
- guided QIG online budget = G8_r;
- equal-budget baseline QIG budget = G8_r + T_off/10,
where T_off is the archived fresh S=10,000n mining time for the fixed reusable P source.

Thus one tenth of the one-time mining cost is charged per prospective use.

## Validation
The single promoted fraction is evaluated without retuning on external-comparator analysis replications 6–10 for both n=50 problems (5 pairs per problem; 10 total).
Primary per-problem endpoint: mean paired Delta RPD.
Also report median Delta RPD, W/T/L, mean RPD, batch-best Cmax, guided-use fraction, and QA.

## Interpretation restrictions
- This is exploratory mechanism development prompted by known n=50 failures; it is not a confirmatory benchmark panel.
- Success is not required by the protocol and no further fraction/lambda/source change is permitted after seeing this grid.
- Results must be reported even if one or both n=50 problems remain unfavorable.
