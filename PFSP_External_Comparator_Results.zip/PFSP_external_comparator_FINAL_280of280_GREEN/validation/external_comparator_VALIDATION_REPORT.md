# external-comparator analysis Comparator Validation Gate

**MASTER QA: GREEN**

Validation results are diagnostic only and are excluded from the official 28×10 fair-comparison panel. Published values below are group-level reference behavior from the comparator papers and are not exact targets for a single selected instance.

## Q-NEH — native n×m episodes, R=5 per gate instance

| Problem | Our mean RPD (%) | Our best RPD (%) | Published group mean context (%) | QA |
|---|---:|---:|---:|---|
| Ta20_5_1 | 0.313 | 0.000 | 0.500 | PASS |
| Ta50_10_1 | 3.276 | 3.009 | 2.670 | PASS |
| Ta100_10_1 | 0.735 | 0.624 | 1.050 | PASS |
| Ta50_20_1 | 3.948 | 3.740 | 3.970 | PASS |

## QIG — native t=60 time scale, one gate run per instance

| Problem | Our RPD (%) | Published group mean context (%) | Elapsed (s) | QA |
|---|---:|---:|---:|---|
| Ta20_5_1 | 0.000 | 0.034 | 3.000 | PASS |
| Ta50_10_1 | 1.137 | 0.446 | 15.001 | PASS |
| Ta100_10_1 | 0.000 | 0.087 | 30.001 | PASS |
| Ta50_20_1 | 0.286 | 0.599 | 30.002 | PASS |
| VFR100_20_1 | -0.129 | 0.380 | 60.012 | PASS |

## Primitive/regression QA

- 250 independent insertion cases: Cmax mismatches = 0; FF-score mismatches = 0; selected-position mismatches = 0.
- Q-learning update absolute error = 0.0; epsilon-decay absolute error = 0.0.
- External search functions receive no UB/BKS argument; references are used only ex post for RPD.

## Gate decision

Both comparators pass the frozen validation gate. Official external-comparator analysis production runs are authorized.
