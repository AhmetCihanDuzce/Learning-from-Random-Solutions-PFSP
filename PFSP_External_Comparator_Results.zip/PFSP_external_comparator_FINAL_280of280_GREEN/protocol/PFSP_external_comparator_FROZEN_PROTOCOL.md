# PFSP external-comparator analysis — External Comparator Protocol (FROZEN)

**Frozen date:** 2026-09-11  
**Protocol revision:** Rev.1 — method-wise comparator reporting clarification, frozen 2026-09-11  
**Status:** FROZEN; execution semantics unchanged from the pre-production freeze  
**Purpose:** provide recent external absolute-quality context for the data-mining-guided PFSP framework without redefining the manuscript as a state-of-the-art solver competition.

## 1. Scientific purpose and claim boundary

external-comparator analysis does **not** test the hypothesis that the proposed framework is the best PFSP solver. The framework was deliberately designed to isolate and quantify the incremental value of interpretable structural information mined from solution populations, while keeping the underlying heuristic architectures controlled.

The external comparators are included for two reasons only:
1. to position the achieved solution quality against recent learning-assisted PFSP methods; and
2. to make clear the difference between **improving a solver for absolute Cmax quality** and **measuring the algorithmic contribution of mined structural information**.

The following claims are explicitly prohibited:
- state-of-the-art superiority;
- superiority over QIG or Q-NEH unless directly supported by the frozen fair-comparison panel;
- interpreting a lower Cmax of an external solver as evidence against the usefulness of mined information;
- excluding the proposed framework's offline mining cost from the primary fair-comparison budget.

## 2. Frozen external comparators

### Comparator A — Q-NEH
Guo, D., Liu, S., Ling, S., Li, M., Jiang, Y., Li, M., & Huang, G. Q. (2024). **The marriage of operations research and reinforcement learning: Integration of NEH into Q-learning algorithm for the permutation flowshop scheduling problem.** *Expert Systems With Applications, 255*, 124779. DOI: 10.1016/j.eswa.2024.124779.

Frozen implementation parameters:
- epsilon = 0.5
- alpha = 0.5
- gamma = 0.8
- native validation stopping rule = n × m episodes
- paper validation repetitions = R = 5 when reproducing paper-scale behavior

Core mechanism to reproduce:
- Q-learning action selects an unscheduled job;
- the selected job is inserted into all possible positions of the current partial permutation;
- the minimum-Cmax insertion is retained;
- knowledge-reinforcement reward augments the base 1/C reward;
- sparse state-action storage is allowed, but algorithmic semantics must be unchanged.

### Comparator B — QIG
Karimi-Mamaghan, M., Mohammadi, M., Pasdeloup, B., & Meyer, P. (2023 volume; online 2022). **Learning to select operators in meta-heuristics: An integration of Q-learning into the iterated greedy algorithm for the permutation flowshop scheduling problem.** *European Journal of Operational Research, 304*(3), 1296–1330. DOI: 10.1016/j.ejor.2022.03.054.

Frozen implementation parameters:
- tau = 0.7
- epsilon = 0.8
- beta = 0.996
- alpha = 0.6
- gamma = 0.8
- episode size E = 6
- local/global reward weight eta = 0.3
- perturbation actions d in {1,2,3}
- NEH initial solution
- insertion-neighborhood local search
- local search on the partial solution after destruction
- Fernandez-Viagas–Framinan FF tie-breaking in initial construction, reconstruction, and insertion local search
- Metropolis acceptance with the published constant-temperature formula

Native validation stopping rules:
- reproduce the paper's time-scale convention T = n*m*t/2 milliseconds for t in {60,90,120} where used;
- paper-scale validation may use published 30-run aggregate behavior, but 30 runs are **not** required in the final fair-comparison panel.

## 3. Frozen common instance subset

The external-comparator analysis official subset is the same **28-instance panel pre-specified before external-comparator analysis outcomes** in analyses 4–5: problem #1 and #10 from each of the 14 benchmark groups.

Taillard:
- 20×5: #1, #10
- 20×10: #1, #10
- 20×20: #1, #10
- 50×5: #1, #10
- 50×10: #1, #10
- 50×20: #1, #10
- 100×5: #1, #10
- 100×10: #1, #10
- 100×20: #1, #10
- 200×10: #1, #10
- 200×20: #1, #10

VFR hard-large:
- 100×20: #1, #10
- 100×40: #1, #10
- 100×60: #1, #10

No instance may be added, removed, or replaced based on external-comparator analysis outcomes.

## 4. Frozen replication rule

The **official fair-comparison panel uses R = 10 independent end-to-end runs per stochastic method and problem**.

This rule applies to:
- the external-comparator analysis re-run of the proposed data-mining-guided framework;
- Q-NEH;
- QIG.

Paper-native R values (Q-NEH: 5; QIG: 30) are used only for implementation validation and literature-behavior checks, not as the main comparative sample sizes.

### 4.1 Guided variants are separate methods, not a portfolio selector

The proposed framework contributes **10 distinct P+R guided methods** in external-comparator analysis:

- NEH — Elite-only
- NEH — Contrast
- NEH-TBKK2 — Elite-only
- NEH-TBKK2 — Contrast
- KK2-style-NEH — Elite-only
- KK2-style-NEH — Contrast
- FRB4-p1 — Elite-only
- FRB4-p1 — Contrast
- INEH-inspired — Elite-only
- INEH-inspired — Contrast

These 10 guided variants are **not** combined into a best-of-10 portfolio and no variant is selected ex post as “the proposed method.” Each guided variant is treated as a separate method and is compared independently against Q-NEH and QIG over the same frozen 28-problem panel and R=10 replication structure.

Accordingly, the official external-comparator analysis comparison contains **12 separately reported methods**: 10 guided variants + Q-NEH + QIG.

Any diagnostic field that records the minimum Cmax across the 10 guided variants is for run monitoring only and must not be used as an official external-comparator analysis performance measure, ranking, or claim.

### external-comparator analysis seed rule

Official external-comparator analysis seeds are generated prospectively and are independent of the ablation analysis–7 historical five-pool seeds.

For problem ordinal `k = 1,...,28` in the frozen panel and replication `r = 1,...,10`:

`seed(k,r) = 820260000 + 100*k + r`

The same integer seed label is supplied to each stochastic method for traceability. Because the algorithms consume randomness differently, this is not interpreted as a common-random-number variance-reduction design.

## 5. Frozen primary fairness rule — equal total end-to-end wall-clock budget

### 5.1 Why time rather than iterations

Iterations/episodes are not directly comparable across algorithms because one QIG iteration, one Q-NEH decision sequence, and one data-mining pipeline operation have different computational cost. Therefore, the primary fair-comparison budget is **wall-clock time on the same machine and execution configuration**, not an equal iteration count.

### 5.2 Proposed-framework budget includes offline cost

For each problem and replication, the proposed framework is timed from the start of random-pool generation until the guided solution is available.

The charged budget includes:
- random permutation pool generation;
- Cmax evaluation of the full random pool;
- Elite/Poor selection;
- P/R information mining;
- guided heuristic construction/search.

The following are excluded from algorithmic timing:
- benchmark-file loading;
- one-time JIT/compiler warm-up;
- result-file writing;
- ex-post QA and reference-UB lookup.

No offline mining/training cost is hidden or amortized in the primary comparison.

### 5.3 One conservative common budget per problem/replication

The framework contains five heuristic families and two mining modes, yielding the 10 separately reported guided methods defined in Section 4.1. To avoid giving an external comparator a smaller budget than any guided method, for each problem/replication define:

`B(k,r) = offline_pool_and_mining_time + max(guided_variant_time over the 10 P+R guided variants)`

where the 10 variants are:
- 5 families × {Elite-only, Contrast}
- P+R only, using the frozen 0.65/0.35 weights.

**Every one of the 10 guided methods is evaluated separately under this same common budget B(k,r).** No time from one guided method is added to another, because the 10 variants are alternative methods rather than sequential components of a portfolio.

Q-NEH and QIG each receive **exactly B(k,r) seconds** for their corresponding problem/replication.

This is deliberately conservative in favor of the external comparators because the full offline cost is charged to every guided method rather than amortized across variants. The 10 guided methods are not allowed to pool or exchange their solution information during external-comparator analysis.

### 5.4 Execution configuration

Primary timing comparison:
- same host/session;
- one algorithmic process at a time;
- single CPU core / one computational thread where controllable;
- no GPU;
- no parallel multi-start execution;
- JIT warm-up completed before timing begins;
- high-resolution monotonic timer (`perf_counter`).

## 6. Frozen proposed-framework semantics in external-comparator analysis

external-comparator analysis does not retune or alter the proposed framework.

Use:
- pool size S = 10000n
- Elite = 5%
- Poor = 10%
- top-P = 3n
- 4 position regions
- q = 4
- P/R weights = 0.65/0.35
- mining = Elite-only and Contrast
- families = NEH, NEH-TBKK2, KK2-style-NEH, FRB4-p1, INEH-inspired
- no adjacency information
- no native post-local-search

Historical-selection semantics remain unchanged:
- Ta50×10 and all VFR groups: deterministic Elite/Poor cutoff treatment;
- all other groups: historical NumPy quicksort cutoff treatment;
- top-P support selection follows the frozen historical argpartition semantics.

external-comparator analysis re-runs are new experiments and do not replace or modify any ablation analysis–7 result.

For official external-comparator analysis reporting, the 10 guided variants remain separate throughout the full pipeline. No best-of-variant selection is performed before or after evaluation.

## 7. Validation gate before the 28-problem production run

No official external-comparator analysis interpretation is allowed until both comparator implementations pass validation.

### Q-NEH validation
At minimum:
- Ta001 (20×5)
- Ta041 (50×10)
- Ta071 (100×10)
- Ta051 (50×20)

Check:
- valid permutations;
- independently recomputed Cmax;
- qualitative/quantitative behavior reasonably consistent with the paper's reported RLE levels under the paper-native n×m episode rule;
- no benchmark UB/BKS used by the search itself.

### QIG validation
At minimum:
- Ta001 (20×5)
- Ta041 (50×10)
- Ta071 (100×10)
- Ta051 (50×20)
- one VFR100×20 problem

Check:
- valid permutations;
- independently recomputed Cmax;
- behavior consistent with the paper's reported Taillard/VRF ARPD scale under a native published time scale;
- FF tie-breaking regression checks on controlled insertion cases;
- Q-table/state/action updates and epsilon decay exactly match the published equations;
- no UB/BKS information used by the search.

Validation results are diagnostic only and are not part of the final external-comparator analysis comparison table.

## 8. Frozen primary and secondary outputs

### Primary panel — native outputs under equal total budget
The primary panel reports all **12 methods separately**: the 10 guided variants, Q-NEH, and QIG.

For each method/problem:
- mean Cmax over R=10
- SD of Cmax
- best Cmax
- worst Cmax
- mean RPD using frozen reference-benchmark preparation reference UB
- best RPD
- mean wall-clock time actually consumed
- budget B(k,r) audit
- valid-permutation audit
- independent Cmax recomputation audit

No best-of-10 guided portfolio statistic is a primary external-comparator analysis result.

Primary statistical unit is the problem instance; analysis phase 9 owns formal inference.

### Secondary harmonized-polishing panel
A common deterministic objective-only insertion descent, maximum 10 passes, is applied **separately to the saved native final permutation of each of the 12 methods**.

Rules:
- each of the 10 guided variants keeps its own native permutation and receives its own common-LS result;
- Q-NEH and QIG likewise receive the identical common polishing routine;
- no guided variant is selected before polishing and no best-of-variant portfolio is formed after polishing;
- native permutations are retained unchanged for audit and the polishing result is stored separately;
- same polishing code for all methods;
- no P/R information in polishing;
- no tuning based on external-comparator analysis outcomes;
- this panel is explicitly secondary/diagnostic;
- common-LS time is not part of the primary native equal-budget comparison;
- primary claims use the native-output panel.

## 9. Frozen reference-quality rule

Use the reference-benchmark preparation frozen reference UBs and:

`RPD = 100 * (Cmax - ReferenceUB) / ReferenceUB`

These reference UBs are used only for ex-post evaluation, never during search.

No claim is made that the frozen references are globally current 2026 BKS values.

## 10. Frozen QA gate

external-comparator analysis cannot be interpreted until MASTER QA is GREEN.

Required checks:
- exactly 28 frozen problems;
- exactly R=10 runs per stochastic method/problem in the official panel;
- seed rule exact;
- no duplicate/missing runs;
- exact instance dimensions and identities;
- every returned sequence is a valid permutation;
- every Cmax independently recomputed and matched;
- comparator parameter audit exact;
- budget audit: comparator wall-clock <= allocated B(k,r) plus documented timer granularity/tolerance;
- reference UB audit exact against reference-benchmark preparation master;
- RPD recomputation exact;
- native and harmonized panels kept separate;
- all 10 guided variants retained and reported separately;
- no best-of-10 guided portfolio used as an official method;
- common LS applied method-wise to saved native permutations only;
- no validation-pilot rows mixed into official results.

## 11. Frozen manuscript framing

### Introduction / contribution statement
> The objective of this study is not to develop a state-of-the-art PFSP solver or to outperform highly optimized metaheuristics. Rather, the study investigates whether interpretable structural knowledge mined from solution populations can provide measurable and transferable guidance to otherwise controlled heuristic architectures.

### Comparator-method statement
> Accordingly, the external comparators are not introduced to support a state-of-the-art claim. They are included to position the proposed knowledge-guided framework against recent high-performing learning-assisted PFSP methods and to clarify the distinction between improving a solver for absolute solution quality and quantifying the contribution of mined structural information.

### Discussion statement
> The fact that a highly optimized search-based method such as QIG may attain lower Cmax values does not contradict the purpose of the present study. QIG is designed primarily as a competitive solver, whereas the present framework is deliberately controlled to isolate the incremental value of mined precedence and regional-position information.

### Reviewer-response statement
> We agree that recent external comparators are necessary to provide absolute-quality context. We therefore added Q-NEH and QIG as recent learning-assisted PFSP comparators on a pre-specified common subset under a common end-to-end computational budget. The purpose of this comparison is not to claim state-of-the-art superiority, but to position the solution quality of the proposed framework while preserving the study's primary objective: quantifying the contribution of interpretable mined structural information.

## 12. Interpretation rule

A result in which QIG or Q-NEH obtains lower Cmax than the proposed framework is scientifically acceptable and expected. The external-comparator analysis question is not "Did the proposed framework win?" but rather:

**How does each controlled data-mining-guided variant perform, individually, relative to recent learning-assisted PFSP solvers when every method is evaluated under the same transparent end-to-end computational budget?**

### Rev.1 freeze clarification

Rev.1 does not change any algorithm, parameter, seed, instance, or timing-budget execution rule. It clarifies only the **unit of method-wise reporting and comparison**:

- 10 guided variants are 10 separate methods;
- there is no best-of-10 portfolio selection;
- Q-NEH and QIG are compared with each guided method under the same B(k,r);
- the common-LS secondary panel is also method-wise.

Therefore, official runs already completed under the same execution code remain valid.

