# external-comparator analysis Protocol Rev.1 — Freeze Note

**Date:** 2026-09-11  
**Status:** FROZEN

This revision freezes the method-wise interpretation requested before continuation of external-comparator analysis.

## Frozen clarification

1. The 10 P+R guided variants are **10 separate methods**:
   - five heuristic families × two mining modes (Elite-only, Contrast).
2. No guided variant is chosen as a representative and no best-of-10 portfolio is formed.
3. Q-NEH and QIG are compared **independently with every guided method**.
4. The official comparison therefore contains **12 methods**.
5. The common fair budget remains unchanged:
   `B(k,r) = offline_pool_and_mining_time + max(guided_variant_time over the 10 guided variants)`.
6. The same `B(k,r)` is used for every guided method, Q-NEH, and QIG.
7. R=10 remains the stochastic replication count per problem/method.
8. The primary panel uses native outputs.
9. The secondary harmonized panel applies the same deterministic objective-only insertion descent (max 10 passes) **separately to the saved native permutation of every one of the 12 methods**.
10. No selection is performed before or after common LS.
11. Existing official runs remain valid because Rev.1 does not change algorithms, seeds, parameters, instances, or timing-budget execution semantics.
12. Any `framework_best_*` diagnostic value is monitoring-only and must not be used as an official result.

## Change control

After this freeze, changing the 12-method definition, fair-budget formula, R=10 rule, or method-wise common-LS semantics requires a new protocol revision. An algorithmic/parameter/seed/timing implementation change requires invalidation and rerun of affected official runs.
