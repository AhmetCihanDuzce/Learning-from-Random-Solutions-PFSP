# PFSP external-comparator analysis Comparator Working Package

This package implements the frozen external-comparator analysis comparator protocol.

## Current state
- comparator validation gate: **GREEN**;
- official production completed so far: **80/280 problem-replication runs**;
- protocol revision: **Rev.1 (2026-09-11)**;
- execution semantics are unchanged from the original pre-production freeze;
- Rev.1 clarifies that the 10 guided P+R variants are **10 separate methods**, not a best-of-10 portfolio;
- official reporting therefore contains **12 methods**: 10 guided variants + Q-NEH + QIG;
- every guided method, Q-NEH, and QIG is compared under the same per-problem/replication end-to-end budget `B(k,r)`;
- native outputs remain primary; a secondary common deterministic insertion-LS panel is method-wise and does not select among guided variants.

Any diagnostic `framework_best_*` fields already present in progress files are monitoring aids only and are prohibited from official external-comparator analysis ranking or claims.

See `PFSP_external_comparator_FROZEN_PROTOCOL.md` and `external_comparator_PROTOCOL_REV1_FREEZE_NOTE.md`.
