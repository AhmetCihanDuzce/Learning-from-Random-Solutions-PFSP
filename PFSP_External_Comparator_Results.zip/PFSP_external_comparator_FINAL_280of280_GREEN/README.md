# PFSP external-comparator analysis — FINAL 280/280 GREEN

This package freezes the completed external-comparator analysis external-comparator experiment and its secondary common-local-search panel.

## Completion
- Frozen problems: 28/28
- Native official stochastic runs: 280/280 (R=10 per problem)
- Official methods per run: 12 separately reported (10 guided variants + Q-NEH + QIG)
- Native method-runs: 3360
- Common-LS method-runs: 3360
- external-comparator analysis MASTER QA: GREEN
- Common-LS is a secondary method-wise panel and is not mixed with the native equal-budget primary panel.
- No best-of-10 guided portfolio is treated as an official method.
- Formal inference is deferred to analysis phase 9.

## QA highlights
- Seed mismatches: 0
- Missing / unexpected native run keys: 0 / 0
- Invalid native permutations: 0
- Independently recomputed native Cmax mismatches: 0
- reference-benchmark preparation reference-UB mismatches: 0
- Native RPD mismatches: 0
- Non-GREEN official native runs: 0
- Common-LS invalid permutations: 0
- Common-LS recomputed-Cmax mismatches: 0
- Common-LS worse-than-native cases: 0
- Common-LS passes > 10: 0
- Frozen implementation-hash mismatches: 0
- Common-LS primitive regression: 30/30 PASS

## Budget timing note
The largest observed Q-NEH and QIG wall-clock overruns beyond their allocated end-to-end budget were 0.095588296 s and 0.147558567 s, respectively. The final QA records a conservative 0.2 s episode-boundary completion tolerance and preserves the raw overruns explicitly.

## Reference provenance
The reference-benchmark preparation reference master in `reference/reference_benchmark_reference_ub_MASTER.csv` was recovered from the frozen `PFSP_reference_benchmark_UB_BKS_RPD_FINAL.zip` package and checksum-verified against its `reference_benchmark_SHA256SUMS.txt`. reference-benchmark preparation MASTER QA is GREEN. These UBs are frozen project references for ex-post RPD evaluation, not claims of globally current 2026 world-best values.

## Main folders
- `protocol/`: frozen Rev.1 protocol, seed manifest, and implementation freeze record
- `code/`: comparator runner, official runner, deterministic common-LS, and final QA builder
- `validation/`: frozen comparator validation outputs
- `reference/`: recovered and checksum-verified reference-benchmark preparation reference master
- `native_runs/`: 280 official native run JSON files
- `common_ls/`: 280 secondary common-LS JSON files
- `final/`: MASTER QA and compact analysis-ready CSV outputs
- `dependencies/`: original pure-Python single-instance PFSP package used by the runner
