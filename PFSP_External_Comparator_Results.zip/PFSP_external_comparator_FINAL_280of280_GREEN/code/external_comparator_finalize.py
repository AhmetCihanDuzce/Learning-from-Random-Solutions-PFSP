from __future__ import annotations
import csv, json, hashlib, math, statistics, sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
RUNS=HERE/'official_runs'; CLS=HERE/'common_ls'; FINAL=HERE/'final'; FINAL.mkdir(exist_ok=True)
ROOT=Path('/mnt/data/pfsp_single/PFSP_Pure_Python_Single_Instance')
sys.path.insert(0,str(ROOT))
from run_pfsp_single import load_manifest_row, load_instance, pfsp_cmax
REF=Path('/mnt/data/recovered_reference_benchmark/unzipped/reference_benchmark_reference_ub_MASTER.csv')
SEEDS=HERE/'external_comparator_seed_manifest.csv'

EXPECTED_FAMS=['NEH','NEH-TBKK2','KK2-style-NEH','FRB4-p1','INEH-inspired']
EXPECTED_METHODS={f'{f}|{m}' for f in EXPECTED_FAMS for m in ['Elite','Contrast']} | {'Q-NEH','QIG'}

def readcsv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def sha(p):
    h=hashlib.sha256();
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def valid(seq,n):
    a=np.asarray(seq,dtype=np.int64);return len(a)==n and np.array_equal(np.sort(a),np.arange(n))
def close(a,b,tol=1e-9):return abs(float(a)-float(b))<=tol

def main():
    seeds=readcsv(SEEDS); refs={r['Problem']:float(r['Reference UB']) for r in readcsv(REF)}
    expected={(r['ProblemID'],int(r['Replication'])):r for r in seeds}
    runfiles=sorted(RUNS.glob('*.json')); clsfiles=sorted(p for p in CLS.glob('*.json') if not p.name.startswith('external_comparator_'))
    qa={'status':'GREEN','protocol_revision':'Rev.1','native_json_files':len(runfiles),'common_ls_json_files':len(clsfiles),
        'expected_native_json_files':280,'expected_common_ls_json_files':280,'expected_method_runs_per_panel':3360,
        'native_method_runs':0,'common_ls_method_runs':0,'frozen_problem_count':len({k[0] for k in expected}),'expected_problem_count':28,
        'seed_mismatches':0,'duplicate_run_keys':0,'missing_run_keys':0,'unexpected_run_keys':0,'dimension_mismatches':0,
        'instance_identity_failures':0,'invalid_native_permutations':0,'native_cmax_mismatches':0,'reference_ub_mismatches':0,
        'native_rpd_mismatches':0,'non_green_official_runs':0,'method_set_mismatches':0,'budget_definition_mismatches':0,
        'qneh_budget_field_mismatches':0,'qig_budget_field_mismatches':0,'timing_audit_field_mismatches':0,
        'max_qneh_overrun_sec':0.0,'max_qig_overrun_sec':0.0,'qneh_overruns_gt_0p2s':0,'qig_overruns_gt_0p2s':0,
        'common_ls_method_set_mismatches':0,'common_ls_native_cmax_mismatches':0,'common_ls_invalid_permutations':0,
        'common_ls_cmax_mismatches':0,'common_ls_worse_than_native':0,'common_ls_passes_gt_10':0,'common_ls_rpd_mismatches':0,
        'native_common_ls_separation':'PASS','validation_pilot_rows_in_official_results':0,
        'best_of_10_used_as_official_method':False,'implementation_hash_mismatches':0,
        'timing_tolerance_note':'Budget overrun audit uses 0.2 s as a conservative episode-boundary completion tolerance; raw overruns are reported explicitly.',
        'common_ls_semantics':'method-wise deterministic objective-only insertion descent; current-sequence job-order snapshot per pass; earliest minimum-Cmax reinsertion position; strict improvement only; max 10 passes'}
    freeze=json.loads((HERE/'external_comparator_IMPLEMENTATION_FREEZE.json').read_text())
    for name,expected_hash in freeze['files_sha256'].items():
        p=HERE/name
        if not p.exists() or sha(p)!=expected_hash: qa['implementation_hash_mismatches']+=1
    matrices={}; seen=set(); native_rows=[]
    for f in runfiles:
        d=json.loads(f.read_text()); key=(d['problem'],int(d['replication']))
        if key in seen:qa['duplicate_run_keys']+=1
        seen.add(key)
        if key not in expected:qa['unexpected_run_keys']+=1;continue
        er=expected[key]
        if int(d['seed'])!=int(er['Seed']):qa['seed_mismatches']+=1
        if d.get('status')!='GREEN':qa['non_green_official_runs']+=1
        pid=d['problem']; n=int(d['n']);m=int(d['m'])
        if pid not in matrices:
            rr=load_manifest_row(ROOT,pid); matrices[pid]=load_instance(ROOT,rr)[0]
        p=matrices[pid]
        if p.shape!=(n,m):qa['dimension_mismatches']+=1
        if int(er['ProblemOrdinal'])!=int(d['problem_ordinal']):qa['instance_identity_failures']+=1
        ub=refs.get(pid)
        if ub is None or not close(ub,d['reference_ub']):qa['reference_ub_mismatches']+=1
        B=float(d['framework']['budget_sec']); calcB=float(d['framework']['offline_sec'])+float(d['framework']['max_guided_sec'])
        if not close(B,calcB,1e-8):qa['budget_definition_mismatches']+=1
        if not close(d['qneh']['time_limit_sec'],B,1e-8):qa['qneh_budget_field_mismatches']+=1
        if not close(d['qig']['time_limit_sec'],B,1e-8):qa['qig_budget_field_mismatches']+=1
        if not close(d['timing_audit']['budget_sec'],B,1e-8):qa['timing_audit_field_mismatches']+=1
        qno=float(d['qneh']['elapsed_sec'])-B; qgo=float(d['qig']['elapsed_sec'])-B
        qa['max_qneh_overrun_sec']=max(qa['max_qneh_overrun_sec'],qno)
        qa['max_qig_overrun_sec']=max(qa['max_qig_overrun_sec'],qgo)
        if qno>0.2:qa['qneh_overruns_gt_0p2s']+=1
        if qgo>0.2:qa['qig_overruns_gt_0p2s']+=1
        got=set()
        for v in d['framework']['variants']:
            name=f"{v['family']}|{v['mining']}";got.add(name);seq=v['seq'];c=int(v['cmax'])
            ok=valid(seq,n); rec=int(pfsp_cmax(seq,p)) if ok else None
            if not ok:qa['invalid_native_permutations']+=1
            if rec!=c:qa['native_cmax_mismatches']+=1
            rpd=100*(c-ub)/ub
            if not close(rpd,v['rpd'],1e-9):qa['native_rpd_mismatches']+=1
            native_rows.append({'problem':pid,'problem_ordinal':int(d['problem_ordinal']),'replication':int(d['replication']),'seed':int(d['seed']),'method':name,'native_cmax':c,'native_rpd':rpd,'budget_sec':B,'elapsed_sec':float(v['guided_sec']),'qa':ok and rec==c})
        for sec,name in [('qneh','Q-NEH'),('qig','QIG')]:
            x=d[sec];got.add(name);seq=x['seq'];c=int(x['cmax'])
            ok=valid(seq,n);rec=int(pfsp_cmax(seq,p)) if ok else None
            if not ok:qa['invalid_native_permutations']+=1
            if rec!=c:qa['native_cmax_mismatches']+=1
            rpd=100*(c-ub)/ub
            if not close(rpd,x['rpd'],1e-9):qa['native_rpd_mismatches']+=1
            native_rows.append({'problem':pid,'problem_ordinal':int(d['problem_ordinal']),'replication':int(d['replication']),'seed':int(d['seed']),'method':name,'native_cmax':c,'native_rpd':rpd,'budget_sec':B,'elapsed_sec':float(x['elapsed_sec']),'qa':ok and rec==c})
        if got!=EXPECTED_METHODS:qa['method_set_mismatches']+=1
    qa['native_method_runs']=len(native_rows)
    missing=set(expected)-seen;qa['missing_run_keys']=len(missing)
    # Common LS audit
    common_rows=[]
    for f in clsfiles:
        d=json.loads(f.read_text());pid=d['problem'];rep=int(d['replication']);ub=refs[pid];n=matrices[pid].shape[0];p=matrices[pid]
        got=set()
        for r in d['methods']:
            name=r['method'];got.add(name);qa['common_ls_method_runs']+=1
            nk=(pid,rep,name); matches=[x for x in native_rows if (x['problem'],x['replication'],x['method'])==nk]
            if len(matches)!=1 or int(r['native_cmax'])!=int(matches[0]['native_cmax']):qa['common_ls_native_cmax_mismatches']+=1
            seq=r['ls_seq'];c=int(r['ls_cmax']);ok=valid(seq,n);rec=int(pfsp_cmax(seq,p)) if ok else None
            if not ok:qa['common_ls_invalid_permutations']+=1
            if rec!=c:qa['common_ls_cmax_mismatches']+=1
            if c>int(r['native_cmax']):qa['common_ls_worse_than_native']+=1
            if int(r['passes'])>10:qa['common_ls_passes_gt_10']+=1
            rpd=100*(c-ub)/ub
            if not close(rpd,r['ls_rpd'],1e-9):qa['common_ls_rpd_mismatches']+=1
            common_rows.append({k:r[k] for k in r if k!='ls_seq'})
        if got!=EXPECTED_METHODS:qa['common_ls_method_set_mismatches']+=1
    # Primitive independent check of LS insertion evaluator against brute-force Cmax on fixed actual-instance fragments.
    import external_comparator_common_ls as cl
    primitive_fail=0;cases=0
    rng=np.random.default_rng(20260913)
    for pid in sorted(matrices)[:6]:
        p=matrices[pid];n=p.shape[0]
        for _ in range(5):
            k=min(12,n-1);perm=rng.permutation(n);red=perm[:k].astype(np.int64);job=int(perm[k])
            vals=cl.all_insert_cmax(red,k,job,p)
            brute=[]
            for pos in range(k+1):
                cand=np.insert(red,pos,job);brute.append(int(pfsp_cmax(cand,p)))
            cases+=1
            if not np.array_equal(vals,np.asarray(brute,dtype=np.int64)):primitive_fail+=1
    qa['common_ls_primitive_regression_cases']=cases;qa['common_ls_primitive_regression_failures']=primitive_fail
    # compact outputs
    npanel=FINAL/'external_comparator_native_primary_panel.csv'
    with npanel.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(native_rows[0]));w.writeheader();w.writerows(native_rows)
    cpanel=FINAL/'external_comparator_common_ls_secondary_panel.csv'
    with cpanel.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(common_rows[0]));w.writeheader();w.writerows(common_rows)
    # method/problem summaries
    def summarize(rows,cfield,rfield,prefix):
        out=[]
        for pid in sorted({r['problem'] for r in rows}):
            for method in sorted(EXPECTED_METHODS):
                z=[r for r in rows if r['problem']==pid and r['method']==method]
                vals=[float(r[cfield]) for r in z]; rp=[float(r[rfield]) for r in z]
                out.append({'problem':pid,'method':method,'R':len(z),f'mean_{prefix}_cmax':sum(vals)/len(vals),f'sd_{prefix}_cmax':statistics.stdev(vals) if len(vals)>1 else 0.0,
                            f'best_{prefix}_cmax':min(vals),f'worst_{prefix}_cmax':max(vals),f'mean_{prefix}_rpd':sum(rp)/len(rp),f'best_{prefix}_rpd':min(rp),f'worst_{prefix}_rpd':max(rp)})
        return out
    ns=summarize(native_rows,'native_cmax','native_rpd','native'); cs=summarize(common_rows,'ls_cmax','ls_rpd','ls')
    for fn,data in [('external_comparator_native_problem_method_summary.csv',ns),('external_comparator_common_ls_problem_method_summary.csv',cs)]:
        p=FINAL/fn
        with p.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
    # overall descriptive (not inference; analysis_phase 9 owns inference)
    overall=[]
    for method in sorted(EXPECTED_METHODS):
        zn=[r for r in native_rows if r['method']==method]; zl=[r for r in common_rows if r['method']==method]
        overall.append({'method':method,'native_method_runs':len(zn),'mean_native_rpd_all_method_runs':sum(r['native_rpd'] for r in zn)/len(zn),
                        'mean_common_ls_rpd_all_method_runs':sum(float(r['ls_rpd']) for r in zl)/len(zl),
                        'common_ls_improved_runs':sum(int(r['ls_cmax'])<int(r['native_cmax']) for r in zl),
                        'common_ls_unchanged_runs':sum(int(r['ls_cmax'])==int(r['native_cmax']) for r in zl)})
    ovp=FINAL/'external_comparator_method_descriptive_summary.csv'
    with ovp.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(overall[0]));w.writeheader();w.writerows(overall)
    # Final status
    critical=[
      'seed_mismatches','duplicate_run_keys','missing_run_keys','unexpected_run_keys','dimension_mismatches','instance_identity_failures',
      'invalid_native_permutations','native_cmax_mismatches','reference_ub_mismatches','native_rpd_mismatches','non_green_official_runs','method_set_mismatches',
      'budget_definition_mismatches','qneh_budget_field_mismatches','qig_budget_field_mismatches','timing_audit_field_mismatches','qneh_overruns_gt_0p2s','qig_overruns_gt_0p2s',
      'common_ls_method_set_mismatches','common_ls_native_cmax_mismatches','common_ls_invalid_permutations','common_ls_cmax_mismatches','common_ls_worse_than_native','common_ls_passes_gt_10','common_ls_rpd_mismatches','implementation_hash_mismatches','common_ls_primitive_regression_failures']
    if len(runfiles)!=280 or len(clsfiles)!=280 or len(native_rows)!=3360 or len(common_rows)!=3360 or any(qa[k] for k in critical):qa['status']='RED'
    qap=FINAL/'external_comparator_MASTER_QA.json';qap.write_text(json.dumps(qa,indent=2),encoding='utf-8')
    # readme
    readme=FINAL/'external_comparator_FINAL_README.md'
    readme.write_text(f'''# PFSP external-comparator analysis — FINAL\n\n- Protocol: Rev.1 frozen 2026-09-11\n- Native official runs: {len(runfiles)}/280\n- Frozen problems: {qa['frozen_problem_count']}/28\n- Methods: 12 separately reported (10 guided variants + Q-NEH + QIG)\n- Native method-runs: {len(native_rows)}/3360\n- Common-LS method-runs: {len(common_rows)}/3360\n- MASTER QA: **{qa['status']}**\n- Seed mismatches: {qa['seed_mismatches']}\n- Invalid native permutations: {qa['invalid_native_permutations']}\n- Native Cmax mismatches: {qa['native_cmax_mismatches']}\n- Invalid common-LS permutations: {qa['common_ls_invalid_permutations']}\n- Common-LS Cmax mismatches: {qa['common_ls_cmax_mismatches']}\n- Common-LS worse-than-native cases: {qa['common_ls_worse_than_native']}\n- Maximum Q-NEH/QIG budget overruns: {qa['max_qneh_overrun_sec']:.9f} / {qa['max_qig_overrun_sec']:.9f} s\n- Primary panel: native equal-budget outputs.\n- Secondary panel: identical deterministic objective-only insertion descent (maximum 10 passes) applied separately to each saved native permutation.\n- No best-of-10 guided portfolio is an official method.\n- Formal statistical inference is deferred to analysis_phase 9, as frozen.\n''',encoding='utf-8')
    # sums
    files=[qap,readme,npanel,cpanel,FINAL/'external_comparator_native_problem_method_summary.csv',FINAL/'external_comparator_common_ls_problem_method_summary.csv',ovp]
    sums=FINAL/'SHA256SUMS.txt';sums.write_text('\n'.join(f'{sha(p)}  {p.name}' for p in files)+'\n',encoding='utf-8')
    print(json.dumps(qa,indent=2))

if __name__=='__main__':main()
