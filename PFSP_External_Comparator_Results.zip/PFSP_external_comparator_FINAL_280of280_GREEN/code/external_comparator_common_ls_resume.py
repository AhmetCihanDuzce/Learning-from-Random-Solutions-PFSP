from pathlib import Path
import json, time, sys
import numpy as np
from numba import set_num_threads
import external_comparator_common_ls as s

HERE=s.HERE; RUNS=s.RUNS; OUTDIR=s.OUTDIR; ROOT=s.ROOT
set_num_threads(1)
# warmup
r=s.load_manifest_row(ROOT,'Ta20_5_1'); p,_=s.load_instance(ROOT,r); s.insertion_descent(np.arange(p.shape[0],dtype=np.int64),p,1)
matrices={}
missing=[]
for path in sorted(RUNS.glob('*.json')):
    if not (OUTDIR/path.name).exists(): missing.append(path)
print('missing',len(missing),[x.name for x in missing],flush=True)
for ix,path in enumerate(missing,1):
    d=json.loads(path.read_text()); pid=d['problem']; n=int(d['n']); ub=float(d['reference_ub'])
    if pid not in matrices:
        rr=s.load_manifest_row(ROOT,pid); matrices[pid]=s.load_instance(ROOT,rr)[0]
    p=matrices[pid]
    one={'problem':pid,'problem_ordinal':int(d['problem_ordinal']),'replication':int(d['replication']),'seed':int(d['seed']),'reference_ub':ub,'methods':[]}
    for method,seq0,c0 in s.method_records(d):
        seq=np.asarray(seq0,dtype=np.int64)
        native_valid=s.valid_perm(seq,n); native_rec=int(s.pfsp_cmax(seq,p)) if native_valid else None
        t0=time.perf_counter(); seq2,c2,moves,evals,passes=s.insertion_descent(seq.copy(),p,10); ls_sec=time.perf_counter()-t0
        ls_valid=s.valid_perm(seq2,n); ls_rec=int(s.pfsp_cmax(seq2,p)) if ls_valid else None
        rr={'problem':pid,'problem_ordinal':int(d['problem_ordinal']),'replication':int(d['replication']),'seed':int(d['seed']),
            'method':method,'native_cmax':int(c0),'native_rpd':100*(int(c0)-ub)/ub,'ls_cmax':int(c2),'ls_rpd':100*(int(c2)-ub)/ub,
            'delta_cmax':int(c2)-int(c0),'improvement_cmax':int(c0)-int(c2),'improvement_pct_native':100*(int(c0)-int(c2))/int(c0),
            'moves':int(moves),'evals':int(evals),'passes':int(passes),'ls_time_sec':ls_sec,
            'native_perm_valid':native_valid,'native_recomputed_cmax':native_rec,'ls_perm_valid':ls_valid,'ls_recomputed_cmax':ls_rec,
            'ls_seq':[int(x) for x in seq2]}
        one['methods'].append(rr)
    (OUTDIR/path.name).write_text(json.dumps(one,indent=2),encoding='utf-8')
    print(ix,'/',len(missing),path.name,flush=True)
print('done',flush=True)
