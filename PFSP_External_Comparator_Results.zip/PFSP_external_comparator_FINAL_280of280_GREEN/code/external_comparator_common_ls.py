from __future__ import annotations
import json, csv, time, hashlib, sys
from pathlib import Path
import numpy as np
from numba import njit, set_num_threads

HERE=Path(__file__).resolve().parent
ROOT=Path('/mnt/data/pfsp_single/PFSP_Pure_Python_Single_Instance')
sys.path.insert(0,str(ROOT))
from run_pfsp_single import load_manifest_row, load_instance, pfsp_cmax

OUTDIR=HERE/'common_ls'; OUTDIR.mkdir(exist_ok=True)
RUNS=HERE/'official_runs'

@njit(cache=True)
def cmax_seq(seq,p):
    m=p.shape[1]
    comp=np.zeros(m,np.int64)
    for ii in range(seq.shape[0]):
        jb=seq[ii]
        for j in range(m):
            left=comp[j-1] if j>0 else 0
            up=comp[j]
            comp[j]=(up if up>left else left)+p[jb,j]
    return comp[m-1]

@njit(cache=True)
def all_insert_cmax(seq,k,job,p):
    m=p.shape[1]
    e=np.zeros((k+1,m),np.int64)
    for i in range(1,k+1):
        jb=seq[i-1]
        for j in range(m):
            a=e[i-1,j]
            b=e[i,j-1] if j>0 else 0
            e[i,j]=(a if a>b else b)+p[jb,j]
    q=np.zeros((k+1,m),np.int64)
    for ii in range(k-1,-1,-1):
        jb=seq[ii]
        for jj in range(m-1,-1,-1):
            a=q[ii+1,jj]
            b=q[ii,jj+1] if jj<m-1 else 0
            q[ii,jj]=(a if a>b else b)+p[jb,jj]
    vals=np.empty(k+1,np.int64)
    for pos in range(k+1):
        prev=0; c=0
        for j in range(m):
            a=e[pos,j]
            f=(a if a>prev else prev)+p[job,j]
            prev=f
            v=f+q[pos,j]
            if v>c: c=v
        vals[pos]=c
    return vals

@njit(cache=True)
def insertion_pass_order(seq,p,job_order):
    n=seq.shape[0]
    current=cmax_seq(seq,p)
    moves=0; evals=0
    reduced=np.empty(n-1,np.int64)
    newseq=np.empty(n,np.int64)
    for tt in range(n):
        job=job_order[tt]
        idx=0
        while seq[idx]!=job: idx+=1
        q=0
        for i in range(n):
            if i!=idx:
                reduced[q]=seq[i]; q+=1
        vals=all_insert_cmax(reduced,n-1,job,p); evals+=n
        bp=0; bc=vals[0]
        for pos in range(1,n):
            if vals[pos] < bc:
                bc=vals[pos]; bp=pos
        if bc < current:
            for i in range(bp): newseq[i]=reduced[i]
            newseq[bp]=job
            for i in range(bp,n-1): newseq[i+1]=reduced[i]
            seq=newseq.copy(); current=bc; moves+=1
    return seq,current,moves,evals

@njit(cache=True)
def insertion_pass(seq,p):
    return insertion_pass_order(seq,p,seq.copy())

@njit(cache=True)
def insertion_descent(seq,p,max_passes=10):
    totalm=0; totale=0; passes=0; cur=cmax_seq(seq,p)
    for _ in range(max_passes):
        seq2,c,m,e=insertion_pass(seq,p)
        passes+=1; totalm+=m; totale+=e
        seq=seq2; cur=c
        if m==0: break
    return seq,cur,totalm,totale,passes

def valid_perm(seq,n):
    a=np.asarray(seq,dtype=np.int64)
    return len(a)==n and np.array_equal(np.sort(a),np.arange(n,dtype=np.int64))

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def method_records(d):
    for v in d['framework']['variants']:
        yield f"{v['family']}|{v['mining']}", v['seq'], int(v['cmax'])
    yield 'Q-NEH', d['qneh']['seq'], int(d['qneh']['cmax'])
    yield 'QIG', d['qig']['seq'], int(d['qig']['cmax'])

def main():
    set_num_threads(1)
    files=sorted(RUNS.glob('*.json'))
    assert len(files)==280, len(files)
    # warmup
    r=load_manifest_row(ROOT,'Ta20_5_1'); p,_=load_instance(ROOT,r)
    s=np.arange(p.shape[0],dtype=np.int64)
    insertion_descent(s,p,1)
    matrices={}
    rows=[]; run_outputs=[]
    t_all=time.perf_counter()
    qa={
      'status':'GREEN','native_run_json_files':len(files),'expected_native_runs':280,
      'expected_methods_per_run':12,'common_ls_method_runs':0,'expected_common_ls_method_runs':3360,
      'invalid_native_permutations':0,'native_cmax_mismatches':0,'invalid_ls_permutations':0,
      'ls_cmax_mismatches':0,'ls_worse_than_native':0,'missing_methods':0,'max_passes_exceeded':0,
      'method_names':[], 'algorithm':'deterministic objective-only insertion descent; current-sequence job order snapshot per pass; earliest minimum-Cmax reinsertion position; strict-improvement acceptance; max 10 passes',
      'threads':1
    }
    methods_seen=set()
    for fi,path in enumerate(files,1):
        d=json.loads(path.read_text())
        pid=d['problem']; n=int(d['n']); ub=float(d['reference_ub'])
        if pid not in matrices:
            rr=load_manifest_row(ROOT,pid); matrices[pid]=load_instance(ROOT,rr)[0]
        p=matrices[pid]
        recs=list(method_records(d))
        if len(recs)!=12: qa['missing_methods'] += abs(12-len(recs))
        one={'problem':pid,'problem_ordinal':int(d['problem_ordinal']),'replication':int(d['replication']),'seed':int(d['seed']),'reference_ub':ub,'methods':[]}
        for method,seq0,c0 in recs:
            methods_seen.add(method)
            seq=np.asarray(seq0,dtype=np.int64)
            native_valid=valid_perm(seq,n)
            native_rec=int(pfsp_cmax(seq,p)) if native_valid else None
            if not native_valid: qa['invalid_native_permutations']+=1
            if native_rec!=c0: qa['native_cmax_mismatches']+=1
            t0=time.perf_counter(); seq2,c2,moves,evals,passes=insertion_descent(seq.copy(),p,10); ls_sec=time.perf_counter()-t0
            ls_valid=valid_perm(seq2,n); ls_rec=int(pfsp_cmax(seq2,p)) if ls_valid else None
            if not ls_valid: qa['invalid_ls_permutations']+=1
            if ls_rec!=int(c2): qa['ls_cmax_mismatches']+=1
            if int(c2)>c0: qa['ls_worse_than_native']+=1
            if int(passes)>10: qa['max_passes_exceeded']+=1
            rpd0=100*(c0-ub)/ub; rpd2=100*(int(c2)-ub)/ub
            rr={'problem':pid,'problem_ordinal':int(d['problem_ordinal']),'replication':int(d['replication']),'seed':int(d['seed']),
                'method':method,'native_cmax':c0,'native_rpd':rpd0,'ls_cmax':int(c2),'ls_rpd':rpd2,
                'delta_cmax':int(c2)-c0,'improvement_cmax':c0-int(c2),'improvement_pct_native':100*(c0-int(c2))/c0,
                'moves':int(moves),'evals':int(evals),'passes':int(passes),'ls_time_sec':ls_sec,
                'native_perm_valid':native_valid,'native_recomputed_cmax':native_rec,'ls_perm_valid':ls_valid,'ls_recomputed_cmax':ls_rec,
                'ls_seq':[int(x) for x in seq2]}
            rows.append(rr); one['methods'].append(rr)
        op=OUTDIR/path.name
        op.write_text(json.dumps(one,indent=2),encoding='utf-8')
        run_outputs.append(op)
        if fi%20==0: print(f'{fi}/280',flush=True)
    qa['common_ls_method_runs']=len(rows)
    qa['method_names']=sorted(methods_seen)
    qa['elapsed_sec']=time.perf_counter()-t_all
    if any(qa[k] for k in ['invalid_native_permutations','native_cmax_mismatches','invalid_ls_permutations','ls_cmax_mismatches','ls_worse_than_native','missing_methods','max_passes_exceeded']): qa['status']='RED'
    if len(rows)!=3360 or len(methods_seen)!=12: qa['status']='RED'
    # csv without sequence for compactness
    csvp=OUTDIR/'external_comparator_common_ls_raw.csv'
    keys=[k for k in rows[0].keys() if k!='ls_seq']
    with csvp.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader();
        for r in rows: w.writerow({k:r[k] for k in keys})
    # aggregate by problem/method and method overall
    import statistics
    summ=[]
    for pid in sorted({r['problem'] for r in rows}):
        for method in sorted(methods_seen):
            z=[r for r in rows if r['problem']==pid and r['method']==method]
            if not z: continue
            vals=[r['ls_cmax'] for r in z]; rpds=[r['ls_rpd'] for r in z]; natives=[r['native_cmax'] for r in z]
            summ.append({'problem':pid,'method':method,'R':len(z),'mean_native_cmax':sum(natives)/len(natives),'mean_ls_cmax':sum(vals)/len(vals),
                         'sd_ls_cmax':statistics.stdev(vals) if len(vals)>1 else 0.0,'best_ls_cmax':min(vals),'worst_ls_cmax':max(vals),
                         'mean_ls_rpd':sum(rpds)/len(rpds),'best_ls_rpd':min(rpds),'mean_improvement_cmax':sum(r['improvement_cmax'] for r in z)/len(z),
                         'mean_ls_time_sec':sum(r['ls_time_sec'] for r in z)/len(z)})
    sp=OUTDIR/'external_comparator_common_ls_problem_method_summary.csv'
    with sp.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(summ[0])); w.writeheader(); w.writerows(summ)
    overall=[]
    for method in sorted(methods_seen):
        z=[r for r in rows if r['method']==method]
        overall.append({'method':method,'method_runs':len(z),'mean_native_rpd':sum(r['native_rpd'] for r in z)/len(z),
                        'mean_ls_rpd':sum(r['ls_rpd'] for r in z)/len(z),'mean_improvement_cmax':sum(r['improvement_cmax'] for r in z)/len(z),
                        'improved_runs':sum(r['ls_cmax']<r['native_cmax'] for r in z),'unchanged_runs':sum(r['ls_cmax']==r['native_cmax'] for r in z),
                        'max_passes_used':max(r['passes'] for r in z),'mean_ls_time_sec':sum(r['ls_time_sec'] for r in z)/len(z)})
    op=OUTDIR/'external_comparator_common_ls_method_overall_summary.csv'
    with op.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(overall[0])); w.writeheader(); w.writerows(overall)
    qa['outputs_sha256']={p.name:sha256(p) for p in [csvp,sp,op]}
    qap=OUTDIR/'external_comparator_COMMON_LS_QA.json'; qap.write_text(json.dumps(qa,indent=2),encoding='utf-8')
    print(json.dumps(qa,indent=2),flush=True)

if __name__=='__main__': main()
