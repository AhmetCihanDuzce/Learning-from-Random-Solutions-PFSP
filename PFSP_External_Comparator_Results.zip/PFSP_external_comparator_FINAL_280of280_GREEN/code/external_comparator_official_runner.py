from __future__ import annotations
import sys, csv, json, os, tempfile, time, hashlib
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/pfsp_single/PFSP_Pure_Python_Single_Instance')
sys.path.insert(0,str(ROOT))
from run_pfsp_single import (
    load_manifest_row, load_instance, generate_pool_to_memmap, cmax_memmap,
    selection_indices, mine_pr_rules, tpt_order, kk2_style_order,
    construct_info_neh, construct_info_frb4, validate_solution, pfsp_cmax, FAMILIES
)
sys.path.insert(0,str(Path(__file__).resolve().parent))
from external_comparator_comparators import qneh_time, qig, validate_permutation, cmax_numba, best_insert_ff

HERE=Path(__file__).resolve().parent
SEEDS=HERE/'external_comparator_seed_manifest.csv'
REF=Path('/mnt/data/PFSP_reference_benchmark_UB_BKS_RPD_FINAL/reference_benchmark_reference_ub_MASTER.csv')
OUT=HERE/'official_runs'; OUT.mkdir(exist_ok=True)
TMP=HERE/'tmp'; TMP.mkdir(exist_ok=True)

def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def get_seed_row(pid,rep):
    r=[x for x in read_csv(SEEDS) if x['ProblemID']==pid and int(x['Replication'])==int(rep)]
    if len(r)!=1: raise ValueError((pid,rep,len(r)))
    return r[0]

def ref_ub(pid):
    r=[x for x in read_csv(REF) if x['Problem']==pid]
    if len(r)!=1: raise ValueError(pid)
    return float(r[0]['Reference UB'])

def boundary_mode(pid):
    return 'deterministic' if (pid.startswith('Ta50_10_') or pid.startswith('VFR')) else 'numpy_quicksort'

def warmup():
    row=load_manifest_row(ROOT,'Ta20_5_1'); p,_=load_instance(ROOT,row)
    s=np.arange(5,dtype=np.int64); cmax_numba(s,p); best_insert_ff(s[:-1],int(s[-1]),p)

def framework_run(pid,rep,seed,p):
    n,m=p.shape; S=10000*n; elite_n=round(.05*S); poor_n=round(.10*S)
    regions=4; top_p=3*n; q_info=4
    mode=boundary_mode(pid)
    pool_file=TMP/f'{pid}_r{rep}_seed{seed}.uint16'
    if pool_file.exists(): pool_file.unlink()
    t0=time.perf_counter()
    pool=generate_pool_to_memmap(seed,S,n,pool_file,25000,False)
    cs=cmax_memmap(pool,p,50000,False)
    eidx,bidx=selection_indices(cs,elite_n,poor_n,mode)
    elite=np.asarray(pool[eidx,:],dtype=np.uint16)
    poor=np.asarray(pool[bidx,:],dtype=np.uint16)
    PE,RE,PC,RC=mine_pr_rules(elite,poor,n,regions,top_p)
    offline=time.perf_counter()-t0
    tpt=tpt_order(p); kk=kk2_style_order(p)
    specs=[
      ('NEH','Elite',lambda: construct_info_neh(tpt,p,PE,RE,0)),
      ('NEH-TBKK2','Elite',lambda: construct_info_neh(tpt,p,PE,RE,2)),
      ('KK2-style-NEH','Elite',lambda: construct_info_neh(kk,p,PE,RE,2)),
      ('FRB4-p1','Elite',lambda: construct_info_frb4(tpt,p,PE,RE,1,q_info,2)),
      ('INEH-inspired','Elite',lambda: construct_info_frb4(kk,p,PE,RE,1,q_info,2)),
      ('NEH','Contrast',lambda: construct_info_neh(tpt,p,PC,RC,0)),
      ('NEH-TBKK2','Contrast',lambda: construct_info_neh(tpt,p,PC,RC,2)),
      ('KK2-style-NEH','Contrast',lambda: construct_info_neh(kk,p,PC,RC,2)),
      ('FRB4-p1','Contrast',lambda: construct_info_frb4(tpt,p,PC,RC,1,q_info,2)),
      ('INEH-inspired','Contrast',lambda: construct_info_frb4(kk,p,PC,RC,1,q_info,2)),
    ]
    variants=[]; maxg=0.0
    for fam,mining,fn in specs:
        s0=time.perf_counter(); seq,c=fn(); sec=time.perf_counter()-s0
        validate_solution(seq,c,p,n); rec=pfsp_cmax(seq,p)
        maxg=max(maxg,sec)
        variants.append({'family':fam,'mining':mining,'cmax':int(c),'guided_sec':sec,
                         'seq':[int(x) for x in seq],'qa':bool(rec==c)})
    budget=offline+maxg
    pool_stats={'best':int(cs.min()),'mean':float(cs.mean()),'worst':int(cs.max()),
                'elite_mean':float(cs[eidx].mean()),'poor_mean':float(cs[bidx].mean())}
    del elite,poor,PE,RE,PC,RC,cs,pool
    try: pool_file.unlink()
    except FileNotFoundError: pass
    return {'offline_sec':offline,'max_guided_sec':maxg,'budget_sec':budget,'variants':variants,
            'pool_stats':pool_stats,'boundary_mode':mode,'pool_size':S}

def main(pid,rep):
    warmup()
    row=load_manifest_row(ROOT,pid); p,_=load_instance(ROOT,row); n,m=p.shape
    sr=get_seed_row(pid,rep); seed=int(sr['Seed']); ub=ref_ub(pid)
    fw=framework_run(pid,rep,seed,p); B=float(fw['budget_sec'])
    qr=qneh_time(p,seed,B)
    qg=qig(p,seed,B)
    # independent QA
    qnr=int(pfsp_cmax(qr['seq'],p)); qgr=int(pfsp_cmax(qg['seq'],p))
    qn_ok=validate_permutation(qr['seq'],n) and qnr==qr['cmax']
    qg_ok=validate_permutation(qg['seq'],n) and qgr==qg['cmax']
    for v in fw['variants']:
        v['rpd']=100*(v['cmax']-ub)/ub
    out={
      'status':'GREEN' if qn_ok and qg_ok and all(v['qa'] for v in fw['variants']) else 'RED',
      'problem':pid,'problem_ordinal':int(sr['ProblemOrdinal']),'replication':int(rep),'seed':seed,
      'n':n,'m':m,'reference_ub':ub,
      'framework':fw,
      'qneh':{k:v for k,v in qr.items() if k!='seq'} | {'seq':[int(x) for x in qr['seq']], 'qa':bool(qn_ok),'recomputed_cmax':qnr,'rpd':100*(qr['cmax']-ub)/ub},
      'qig':{k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in qg.items() if k!='seq'} | {'seq':[int(x) for x in qg['seq']], 'qa':bool(qg_ok),'recomputed_cmax':qgr,'rpd':100*(qg['cmax']-ub)/ub},
      'timing_audit':{
          'budget_sec':B,
          'qneh_elapsed_sec':float(qr['elapsed_sec']),
          'qneh_overrun_sec':float(qr['elapsed_sec']-B),
          'qig_elapsed_sec':float(qg['elapsed_sec']),
          'qig_overrun_sec':float(qg['elapsed_sec']-B),
          'framework_budget_definition':'offline_sec + max guided variant sec'
      }
    }
    path=OUT/f'{int(sr["ProblemOrdinal"]):02d}_{pid}_r{int(rep):02d}.json'
    path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print(json.dumps({'status':out['status'],'problem':pid,'rep':rep,'seed':seed,'budget_sec':B,
      'framework_best_cmax':min(v['cmax'] for v in fw['variants']),
      'framework_best_rpd':min(v['rpd'] for v in fw['variants']),
      'qneh_cmax':qr['cmax'],'qneh_rpd':out['qneh']['rpd'],'qneh_elapsed':qr['elapsed_sec'],'qneh_episodes':qr['episodes'],
      'qig_cmax':qg['cmax'],'qig_rpd':out['qig']['rpd'],'qig_elapsed':qg['elapsed_sec'],'qig_episodes':qg['episodes']},indent=2))

if __name__=='__main__':
    if len(sys.argv)<3: raise SystemExit('usage: external_comparator_official_runner.py ProblemID Rep')
    main(sys.argv[1],int(sys.argv[2]))
