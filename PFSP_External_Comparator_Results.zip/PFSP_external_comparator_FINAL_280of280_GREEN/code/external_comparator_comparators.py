from __future__ import annotations
import math, time
import numpy as np
from numba import njit

@njit(cache=True)
def cmax_numba(seq, p):
    m = p.shape[1]
    comp = np.zeros(m, dtype=np.int64)
    for jj in range(seq.shape[0]):
        job = int(seq[jj])
        for i in range(m):
            left = 0 if i == 0 else comp[i-1]
            if comp[i] < left:
                comp[i] = left
            comp[i] += p[job, i]
    return int(comp[m-1])

@njit(cache=True)
def _forward_backward(seq, p):
    k = seq.shape[0]
    m = p.shape[1]
    e = np.zeros((m, k+1), dtype=np.int64)
    q = np.zeros((m, k+1), dtype=np.int64)
    for j in range(k):
        job = int(seq[j])
        for i in range(m):
            left = 0 if i == 0 else e[i-1, j+1]
            above = e[i, j]
            if left > above:
                above = left
            e[i, j+1] = above + p[job, i]
    for j in range(k-1, -1, -1):
        job = int(seq[j])
        for i in range(m-1, -1, -1):
            down = 0 if i == m-1 else q[i+1, j]
            right = q[i, j+1]
            if down > right:
                right = down
            q[i, j] = right + p[job, i]
    return e, q

@njit(cache=True)
def best_insert_ff(seq, job, p):
    """Best insertion by Cmax, with Fernandez-Viagas/Framinan FF tie indicator.

    seq: 1d int64 array without `job`.
    Returns (best_pos, best_cmax, append_cmax, ff_score).
    The FF score implements the general form described in Fernandez-Viagas & Framinan (2019),
    Eq. (1), equivalent to the 2014 idle-time estimate for insertion ties.
    """
    k = seq.shape[0]
    m = p.shape[1]
    if k == 0:
        c = 0
        for i in range(m):
            c += p[job, i]
        return 0, int(c), int(c), 0.0
    e, q = _forward_backward(seq, p)
    best_c = np.int64(9223372036854775807)
    best_pos = 0
    best_ff = 1.0e300
    append_c = np.int64(0)
    f = np.zeros(m, dtype=np.int64)
    g = np.zeros(m, dtype=np.int64)
    for pos in range(k+1):
        # completion of inserted job on all machines
        for i in range(m):
            left = e[i, pos]
            prevm = 0 if i == 0 else f[i-1]
            if prevm > left:
                left = prevm
            f[i] = left + p[job, i]
        c = np.int64(0)
        for i in range(m):
            v = f[i] + q[i, pos]
            if v > c:
                c = v
        if pos == k:
            append_c = c
            ff = 0.0
            for i in range(m):
                ff += float(f[i] - e[i, k])
        else:
            oldjob = int(seq[pos])
            for i in range(m):
                left = f[i]
                prevm = 0 if i == 0 else g[i-1]
                if prevm > left:
                    left = prevm
                g[i] = left + p[oldjob, i]
            ff = 0.0
            # Eq.(1) simplifies to sum_i(g_i - e_i,pos+1)
            for i in range(m):
                ff += float(g[i] - e[i, pos+1])
        if c < best_c or (c == best_c and ff < best_ff - 1e-12):
            best_c = c
            best_pos = pos
            best_ff = ff
    return int(best_pos), int(best_c), int(append_c), float(best_ff)


def insert_at(seq: np.ndarray, job: int, pos: int) -> np.ndarray:
    out = np.empty(seq.size + 1, dtype=np.int64)
    out[:pos] = seq[:pos]
    out[pos] = int(job)
    out[pos+1:] = seq[pos:]
    return out


def remove_job(seq: np.ndarray, job: int) -> np.ndarray:
    idx = int(np.flatnonzero(seq == job)[0])
    out = np.empty(seq.size - 1, dtype=np.int64)
    out[:idx] = seq[:idx]
    out[idx:] = seq[idx+1:]
    return out


def neh_ff(p: np.ndarray) -> tuple[np.ndarray, int]:
    n = p.shape[0]
    totals = p.sum(axis=1)
    # stable descending TPT, job index as deterministic residual tie rule
    order = np.lexsort((np.arange(n), -totals))
    seq = np.empty(0, dtype=np.int64)
    c = 0
    for job in order:
        pos, c, _, _ = best_insert_ff(seq, int(job), p)
        seq = insert_at(seq, int(job), pos)
    return seq, int(c)


def insertion_local_search_ff(seq: np.ndarray, p: np.ndarray, rng: np.random.Generator, max_passes: int = 100) -> tuple[np.ndarray, int, int]:
    seq = np.asarray(seq, dtype=np.int64).copy()
    current = int(cmax_numba(seq, p))
    passes = 0
    for _ in range(max_passes):
        passes += 1
        improved = False
        jobs = seq.copy()
        rng.shuffle(jobs)
        for job in jobs:
            partial = remove_job(seq, int(job))
            pos, cand_c, _, _ = best_insert_ff(partial, int(job), p)
            seq = insert_at(partial, int(job), pos)
            if cand_c < current:
                improved = True
            current = int(cand_c)
        if not improved:
            break
    return seq, current, passes


def qneh(p: np.ndarray, seed: int, episodes: int | None = None, epsilon: float = 0.5, alpha: float = 0.5, gamma: float = 0.8):
    """Faithful paper-level Q-NEH reimplementation.

    The paper pseudocode advances state s_t -> s_{t+1}; here states are scheduling analyses t=0..n-1,
    and actions are unscheduled jobs. This matches Algorithm 3's state progression and keeps the Q table finite.
    Knowledge reinforcement uses best insertion over all current positions exactly as Eqs. (20)-(23).
    """
    n, m = p.shape
    if episodes is None:
        episodes = n*m
    rng = np.random.default_rng(seed)
    Q = np.zeros((n, n), dtype=np.float64)
    best_c = 2**63-1
    best_seq = None
    ep_bests = []
    t0 = time.perf_counter()
    for ep in range(int(episodes)):
        seq = np.empty(0, dtype=np.int64)
        remaining = np.arange(n, dtype=np.int64)
        for t in range(n):
            if rng.random() < epsilon:
                ridx = int(rng.integers(0, remaining.size))
                action = int(remaining[ridx])
            else:
                vals = Q[t, remaining]
                action = int(remaining[int(np.argmax(vals))])
            pos, bestins_c, append_c, _ = best_insert_ff(seq, action, p)
            next_seq = insert_at(seq, action, pos)
            # paper Eq.(16) base reward on direct action sequence; Eq.(21) adds knowledge reinforcement
            base_r = 1.0 / float(append_c)
            reinforce = (float(append_c) - float(bestins_c)) / float(append_c)
            reward = base_r + reinforce
            rem2 = remaining[remaining != action]
            nextmax = 0.0 if t == n-1 else float(np.max(Q[t+1, rem2]))
            Q[t, action] += alpha * (reward + gamma*nextmax - Q[t, action])
            seq = next_seq
            remaining = rem2
        c = int(cmax_numba(seq, p))
        ep_bests.append(c)
        if c < best_c:
            best_c = c
            best_seq = seq.copy()
    elapsed = time.perf_counter() - t0
    return {
        'algorithm':'Q-NEH','seed':int(seed),'episodes':int(episodes),'cmax':int(best_c),
        'seq':best_seq,'elapsed_sec':elapsed,'episode_final_cmax':ep_bests,
        'q_nonzero':int(np.count_nonzero(Q))
    }


def qig(p: np.ndarray, seed: int, time_limit_sec: float,
        tau: float = 0.7, epsilon: float = 0.8, beta: float = 0.996,
        alpha: float = 0.6, gamma: float = 0.8, E: int = 6, eta: float = 0.3,
        max_ls_passes: int = 100):
    """QIG (Karimi-Mamaghan et al.) with paper parameters and time-based stopping.

    Initial NEH, FF tie-breaking, insertion LS on full/partial solutions, destruction/reconstruction,
    Metropolis acceptance, two-state Q learning and epsilon decay follow Algorithms 2-3.
    """
    n, m = p.shape
    rng = np.random.default_rng(seed)
    start = time.perf_counter()
    seq, _ = neh_ff(p)
    seq, curr_c, init_passes = insertion_local_search_ff(seq, p, rng, max_ls_passes)
    best_seq = seq.copy(); best_c = int(curr_c)
    Q = np.zeros((2,3), dtype=np.float64)
    state = 0
    d = int(rng.integers(1,4))
    temp = float(tau) * float(p.sum()) / float(n*m*10.0)
    episodes = 0; iterations = 0; accepts = 0
    action_counts = np.zeros(3, dtype=np.int64)
    improvement_counts = np.zeros(3, dtype=np.int64)
    eps = float(epsilon)
    # As in Algorithm 2, stopping is evaluated at episode boundaries.
    while (time.perf_counter() - start) < time_limit_sec:
        Cprev = int(curr_c); Cbest_prev = int(best_c)
        C_ep = int(curr_c); Cbest_ep = int(best_c)
        used_d = d
        action_counts[d-1] += 1
        for _ in range(E):
            iterations += 1
            # destruction: random d jobs without replacement, in draw order
            idxs = rng.choice(seq.size, size=d, replace=False)
            removed = seq[idxs].copy()
            keepmask = np.ones(seq.size, dtype=bool); keepmask[idxs] = False
            partial = seq[keepmask].copy()
            partial, _, _ = insertion_local_search_ff(partial, p, rng, max_ls_passes)
            # construction with FF
            cand = partial
            for job in removed:
                pos, _, _, _ = best_insert_ff(cand, int(job), p)
                cand = insert_at(cand, int(job), pos)
            cand, cand_c, _ = insertion_local_search_ff(cand, p, rng, max_ls_passes)
            # Metropolis acceptance: exp((Ccurrent-Ccand)/Tp)
            accept = cand_c <= curr_c
            if not accept and temp > 0.0:
                prob = math.exp((float(curr_c)-float(cand_c))/temp)
                accept = rng.random() < prob
            if accept:
                seq = cand; curr_c = int(cand_c); accepts += 1
                if curr_c < C_ep:
                    C_ep = curr_c
            if cand_c < best_c:
                best_c = int(cand_c); best_seq = cand.copy(); Cbest_ep = best_c
            if (time.perf_counter() - start) >= time_limit_sec:
                # avoid large avoidable overshoot while retaining episode semantics as closely as possible
                break
        # reward Eqs. 10-12
        rlocal = max(Cprev - C_ep, 0) / float(Cprev)
        rglobal = max(Cbest_prev - best_c, 0) / float(Cbest_prev)
        reward = eta*rlocal + (1.0-eta)*rglobal
        new_state = 1 if best_c < Cbest_prev else 0
        Q[state, used_d-1] += alpha * (reward + gamma*float(np.max(Q[new_state])) - Q[state, used_d-1])
        if new_state == 1:
            improvement_counts[used_d-1] += 1
        eps *= beta
        if rng.random() >= eps:
            d = int(np.argmax(Q[new_state])) + 1
        else:
            d = int(rng.integers(1,4))
        state = new_state
        episodes += 1
    elapsed = time.perf_counter() - start
    return {
        'algorithm':'QIG','seed':int(seed),'time_limit_sec':float(time_limit_sec),
        'cmax':int(best_c),'seq':best_seq,'elapsed_sec':elapsed,
        'episodes':episodes,'iterations':iterations,'epsilon_final':eps,
        'q_table':Q.copy(),'action_counts':action_counts.copy(),'improvement_counts':improvement_counts.copy(),
        'accepts':accepts,'init_ls_passes':init_passes,'temperature':temp
    }


def validate_permutation(seq: np.ndarray, n: int) -> bool:
    if seq is None or len(seq) != n: return False
    return np.array_equal(np.sort(np.asarray(seq, dtype=np.int64)), np.arange(n,dtype=np.int64))

def qneh_time(p: np.ndarray, seed: int, time_limit_sec: float,
              epsilon: float = 0.5, alpha: float = 0.5, gamma: float = 0.8):
    """Time-budget version of Q-NEH for the external-comparator analysis fair-comparison panel.

    The same learning/insertion semantics as qneh() are used. Time is checked at episode
    boundaries; at least one complete permutation is produced. The final episode is allowed
    to finish so the method never returns a partial schedule; elapsed time and overrun are audited.
    """
    n, m = p.shape
    rng = np.random.default_rng(seed)
    Q = np.zeros((n, n), dtype=np.float64)
    best_c = 2**63-1; best_seq = None; episodes = 0
    t0 = time.perf_counter()
    while episodes == 0 or (time.perf_counter() - t0) < float(time_limit_sec):
        seq = np.empty(0, dtype=np.int64)
        remaining = np.arange(n, dtype=np.int64)
        for t in range(n):
            if rng.random() < epsilon:
                ridx = int(rng.integers(0, remaining.size)); action = int(remaining[ridx])
            else:
                action = int(remaining[int(np.argmax(Q[t, remaining]))])
            pos, bestins_c, append_c, _ = best_insert_ff(seq, action, p)
            next_seq = insert_at(seq, action, pos)
            reward = 1.0/float(append_c) + (float(append_c)-float(bestins_c))/float(append_c)
            rem2 = remaining[remaining != action]
            nextmax = 0.0 if t == n-1 else float(np.max(Q[t+1, rem2]))
            Q[t,action] += alpha*(reward + gamma*nextmax - Q[t,action])
            seq = next_seq; remaining = rem2
        c = int(cmax_numba(seq,p)); episodes += 1
        if c < best_c:
            best_c = c; best_seq = seq.copy()
    elapsed = time.perf_counter()-t0
    return {'algorithm':'Q-NEH','seed':int(seed),'time_limit_sec':float(time_limit_sec),
            'cmax':int(best_c),'seq':best_seq,'elapsed_sec':elapsed,'episodes':episodes,
            'overrun_sec':max(0.0,elapsed-float(time_limit_sec)),'q_nonzero':int(np.count_nonzero(Q))}
