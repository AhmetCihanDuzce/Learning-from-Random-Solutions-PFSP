# PFSP external-comparator analysis — FINAL

- Protocol: Rev.1 frozen 2026-09-11
- Native official runs: 280/280
- Frozen problems: 28/28
- Methods: 12 separately reported (10 guided variants + Q-NEH + QIG)
- Native method-runs: 3360/3360
- Common-LS method-runs: 3360/3360
- MASTER QA: **GREEN**
- Seed mismatches: 0
- Invalid native permutations: 0
- Native Cmax mismatches: 0
- Invalid common-LS permutations: 0
- Common-LS Cmax mismatches: 0
- Common-LS worse-than-native cases: 0
- Maximum Q-NEH/QIG budget overruns: 0.095588296 / 0.147558567 s
- Primary panel: native equal-budget outputs.
- Secondary panel: identical deterministic objective-only insertion descent (maximum 10 passes) applied separately to each saved native permutation.
- No best-of-10 guided portfolio is an official method.
- Formal statistical inference is deferred to analysis phase 9, as frozen.
