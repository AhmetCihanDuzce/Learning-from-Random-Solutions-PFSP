# external-comparator analysis Progress Checkpoint — 280/280 native runs

- Date: 2026-09-13
- Completed native runs: 280/280
- Complete problems: 28/28
- Partial problem: Ta200_20_10, R=10/10
- Progress QA: GREEN
- Seed mismatches: 0
- Non-GREEN official runs: 0
- Common deterministic insertion LS: NOT YET APPLIED

## Ta200_20_10 — Rep 10

- seed=820262810
- reference UB=11288.0
- budget_sec=476.3456915700008
- QIG Cmax=11323, RPD=0.3100637845499646%, elapsed=476.3902497449999 s
- Q-NEH Cmax=11636, RPD=3.0829199149539335%, elapsed=476.3467215569981 s
- Best guided variant: INEH-inspired–Contrast, Cmax=11671, RPD=3.392983699503898%
- run status=GREEN
- 12-method run-level QA: GREEN

This checkpoint contains exactly 280 completed native official-run JSON files. No common-LS has been applied and no best-of-10 guided portfolio is treated as an official method.
